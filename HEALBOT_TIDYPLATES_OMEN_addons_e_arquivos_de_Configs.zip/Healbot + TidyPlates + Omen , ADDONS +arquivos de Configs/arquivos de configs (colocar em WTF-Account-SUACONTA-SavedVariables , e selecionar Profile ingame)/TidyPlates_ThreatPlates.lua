
ThreatPlatesDB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["char"] = {
		["Muuzlol - Icecrown"] = {
			["welcome"] = true,
			["spec"] = {
				["primary"] = false,
			},
			["specInfo"] = {
				{
					12, -- [1]
					5, -- [2]
					54, -- [3]
				}, -- [1]
				{
					nil, -- [1]
					54, -- [2]
					17, -- [3]
				}, -- [2]
			},
			["specName"] = {
				"Holy", -- [1]
				"Protection", -- [2]
				"Retribution", -- [3]
			},
		},
	},
	["profileKeys"] = {
		["Muuzlol - Icecrown"] = "O MELHOR TP",
	},
	["profiles"] = {
		["Icecrown"] = {
			["nameplate"] = {
				["toggle"] = {
					["Totem"] = true,
				},
				["scale"] = {
					["Elite"] = 1,
					["Boss"] = 1,
					["Neutral"] = 1,
				},
			},
			["allowClass"] = true,
			["uniqueSettings"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				nil, -- [4]
				nil, -- [5]
				nil, -- [6]
				nil, -- [7]
				nil, -- [8]
				nil, -- [9]
				nil, -- [10]
				nil, -- [11]
				nil, -- [12]
				nil, -- [13]
				nil, -- [14]
				nil, -- [15]
				nil, -- [16]
				nil, -- [17]
				nil, -- [18]
				nil, -- [19]
				nil, -- [20]
				nil, -- [21]
				nil, -- [22]
				nil, -- [23]
				nil, -- [24]
				nil, -- [25]
				nil, -- [26]
				nil, -- [27]
				nil, -- [28]
				nil, -- [29]
				nil, -- [30]
				{
				}, -- [31]
				{
				}, -- [32]
				{
				}, -- [33]
				nil, -- [34]
				nil, -- [35]
				nil, -- [36]
				{
				}, -- [37]
				nil, -- [38]
				{
				}, -- [39]
				{
				}, -- [40]
				{
				}, -- [41]
				nil, -- [42]
				nil, -- [43]
				nil, -- [44]
				nil, -- [45]
				nil, -- [46]
				{
				}, -- [47]
				{
				}, -- [48]
				{
				}, -- [49]
				["list"] = {
					"Shadow Fiend", -- [1]
					"Spirit Wolf", -- [2]
					"Ebon Gargoyle", -- [3]
					"Water Elemental", -- [4]
					"Treant", -- [5]
					"Viper", -- [6]
					"Venomous Snake", -- [7]
					"Army of the Dead Ghoul", -- [8]
					"Shadowy Apparition", -- [9]
					"Shambling Horror", -- [10]
					"Web Wrap", -- [11]
					"Immortal Guardian", -- [12]
					"Marked Immortal Guardian", -- [13]
					"Empowered Adherent", -- [14]
					"Deformed Fanatic", -- [15]
					"Reanimated Adherent", -- [16]
					"Reanimated Fanatic", -- [17]
					"Bone Spike", -- [18]
					"Onyxian Whelp", -- [19]
					"Gas Cloud", -- [20]
					"Volatile Ooze", -- [21]
					"Darnavan", -- [22]
					"Val'kyr Shadowguard", -- [23]
					"Kinetic Bomb", -- [24]
					"Lich King", -- [25]
					"Raging Spirit", -- [26]
					"Drudge Ghoul", -- [27]
					"Living Inferno", -- [28]
					"Living Ember", -- [29]
					"Fanged Pit Viper", -- [30]
					"", -- [31]
					"", -- [32]
					"", -- [33]
					"", -- [34]
					"", -- [35]
					"", -- [36]
					"", -- [37]
					"", -- [38]
					"", -- [39]
					"", -- [40]
					"", -- [41]
					"", -- [42]
					"", -- [43]
					"", -- [44]
					"", -- [45]
					"", -- [46]
					"", -- [47]
					"", -- [48]
					"", -- [49]
					"", -- [50]
				},
			},
			["friendlyNameOnly"] = true,
			["text"] = {
				["amount"] = false,
				["full"] = true,
			},
			["settings"] = {
				["tank"] = {
					["threatcolor"] = {
						["MEDIUM"] = {
							["g"] = 0.4823529411764706,
							["b"] = 0.2901960784313725,
						},
						["HIGH"] = {
							["r"] = 1,
							["g"] = 0,
							["b"] = 0.8,
						},
					},
				},
				["highlight"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["eliteicon"] = {
					["show"] = false,
				},
				["spellicon"] = {
					["x"] = -32,
					["scale"] = 30,
					["anchor"] = "LEFT",
					["y"] = -8,
				},
				["spelltext"] = {
					["align"] = "LEFT",
					["width"] = 125,
					["flags"] = "THICKOUTLINE",
					["height"] = 40,
				},
				["level"] = {
					["flags"] = "THICKOUTLINE",
					["size"] = 9,
				},
				["normal"] = {
					["threatcolor"] = {
						["MEDIUM"] = {
							["g"] = 0.4901960784313725,
							["b"] = 0.2705882352941176,
						},
						["LOW"] = {
							["g"] = 0.01568627450980392,
							["b"] = 0,
						},
						["HIGH"] = {
							["b"] = 0.8235294117647058,
						},
					},
				},
				["healthbar"] = {
					["height"] = 20,
					["width"] = 105,
				},
				["healthborder"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["threatborder"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["skullicon"] = {
					["show"] = false,
				},
				["castnostop"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["castbar"] = {
					["width"] = 105,
				},
				["castborder"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["name"] = {
					["y"] = 17,
					["flags"] = "THICKOUTLINE",
					["size"] = 12,
				},
				["customtext"] = {
					["flags"] = "THICKOUTLINE",
					["size"] = 14,
				},
				["frame"] = {
					["height"] = 40,
					["width"] = 109,
				},
				["dps"] = {
					["threatcolor"] = {
						["MEDIUM"] = {
							["g"] = 0.5019607843137255,
							["b"] = 0.3450980392156863,
						},
						["LOW"] = {
							["r"] = 1,
							["g"] = 0,
						},
						["HIGH"] = {
							["b"] = 0.9686274509803922,
						},
					},
				},
				["raidicon"] = {
					["y"] = 26,
					["scale"] = 25,
					["anchor"] = "TOP",
					["hpColor"] = false,
				},
			},
			["friendlyClass"] = true,
			["blizzFade"] = {
				["amount"] = -0.53,
			},
			["totemSettings"] = {
				["hideHealthbar"] = true,
			},
			["friendlyClickThrough"] = true,
			["threat"] = {
				["nonCombat"] = false,
				["tank"] = {
					["scale"] = {
						["MEDIUM"] = 1,
						["LOW"] = 1,
						["HIGH"] = 1,
					},
					["alpha"] = {
						["MEDIUM"] = 1,
						["HIGH"] = 1,
					},
				},
				["scaleType"] = {
					["Normal"] = 0,
					["Boss"] = 0,
				},
				["dps"] = {
					["scale"] = {
						["MEDIUM"] = 1,
						["LOW"] = 1,
						["HIGH"] = 1,
					},
				},
			},
		},
		["Default"] = {
			["nameplate"] = {
				["toggle"] = {
					["Totem"] = true,
				},
				["scale"] = {
					["Elite"] = 1,
					["Boss"] = 1,
					["Neutral"] = 1,
				},
			},
			["friendlyClass"] = true,
			["uniqueSettings"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				nil, -- [4]
				nil, -- [5]
				nil, -- [6]
				nil, -- [7]
				nil, -- [8]
				nil, -- [9]
				nil, -- [10]
				nil, -- [11]
				nil, -- [12]
				nil, -- [13]
				nil, -- [14]
				nil, -- [15]
				nil, -- [16]
				nil, -- [17]
				nil, -- [18]
				nil, -- [19]
				nil, -- [20]
				nil, -- [21]
				nil, -- [22]
				nil, -- [23]
				nil, -- [24]
				nil, -- [25]
				nil, -- [26]
				nil, -- [27]
				nil, -- [28]
				nil, -- [29]
				nil, -- [30]
				{
				}, -- [31]
				{
				}, -- [32]
				{
				}, -- [33]
				nil, -- [34]
				nil, -- [35]
				nil, -- [36]
				{
				}, -- [37]
				nil, -- [38]
				{
				}, -- [39]
				{
				}, -- [40]
				{
				}, -- [41]
				nil, -- [42]
				nil, -- [43]
				nil, -- [44]
				nil, -- [45]
				nil, -- [46]
				{
				}, -- [47]
				{
				}, -- [48]
				{
				}, -- [49]
				["list"] = {
					"Shadow Fiend", -- [1]
					"Spirit Wolf", -- [2]
					"Ebon Gargoyle", -- [3]
					"Water Elemental", -- [4]
					"Treant", -- [5]
					"Viper", -- [6]
					"Venomous Snake", -- [7]
					"Army of the Dead Ghoul", -- [8]
					"Shadowy Apparition", -- [9]
					"Shambling Horror", -- [10]
					"Web Wrap", -- [11]
					"Immortal Guardian", -- [12]
					"Marked Immortal Guardian", -- [13]
					"Empowered Adherent", -- [14]
					"Deformed Fanatic", -- [15]
					"Reanimated Adherent", -- [16]
					"Reanimated Fanatic", -- [17]
					"Bone Spike", -- [18]
					"Onyxian Whelp", -- [19]
					"Gas Cloud", -- [20]
					"Volatile Ooze", -- [21]
					"Darnavan", -- [22]
					"Val'kyr Shadowguard", -- [23]
					"Kinetic Bomb", -- [24]
					"Lich King", -- [25]
					"Raging Spirit", -- [26]
					"Drudge Ghoul", -- [27]
					"Living Inferno", -- [28]
					"Living Ember", -- [29]
					"Fanged Pit Viper", -- [30]
					"", -- [31]
					"", -- [32]
					"", -- [33]
					"", -- [34]
					"", -- [35]
					"", -- [36]
					"", -- [37]
					"", -- [38]
					"", -- [39]
					"", -- [40]
					"", -- [41]
					"", -- [42]
					"", -- [43]
					"", -- [44]
					"", -- [45]
					"", -- [46]
					"", -- [47]
					"", -- [48]
					"", -- [49]
					"", -- [50]
				},
			},
			["friendlyNameOnly"] = true,
			["text"] = {
				["amount"] = false,
				["full"] = true,
			},
			["settings"] = {
				["tank"] = {
					["threatcolor"] = {
						["MEDIUM"] = {
							["g"] = 0.4823529411764706,
							["b"] = 0.2901960784313725,
						},
						["HIGH"] = {
							["r"] = 1,
							["g"] = 0,
							["b"] = 0.8,
						},
					},
				},
				["highlight"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["eliteicon"] = {
					["show"] = false,
				},
				["spellicon"] = {
					["y"] = -8,
					["x"] = -32,
					["anchor"] = "LEFT",
					["scale"] = 30,
				},
				["spelltext"] = {
					["align"] = "LEFT",
					["width"] = 125,
					["height"] = 40,
					["flags"] = "THICKOUTLINE",
				},
				["level"] = {
					["flags"] = "THICKOUTLINE",
					["size"] = 9,
				},
				["normal"] = {
					["threatcolor"] = {
						["MEDIUM"] = {
							["g"] = 0.4901960784313725,
							["b"] = 0.2705882352941176,
						},
						["LOW"] = {
							["g"] = 0.01568627450980392,
							["b"] = 0,
						},
						["HIGH"] = {
							["b"] = 0.8235294117647058,
						},
					},
				},
				["healthbar"] = {
					["height"] = 20,
					["width"] = 105,
				},
				["healthborder"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["threatborder"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["skullicon"] = {
					["show"] = false,
				},
				["castnostop"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["castbar"] = {
					["width"] = 105,
				},
				["castborder"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["name"] = {
					["y"] = 17,
					["flags"] = "THICKOUTLINE",
					["size"] = 12,
				},
				["customtext"] = {
					["flags"] = "THICKOUTLINE",
					["size"] = 14,
				},
				["frame"] = {
					["height"] = 40,
					["width"] = 109,
				},
				["dps"] = {
					["threatcolor"] = {
						["MEDIUM"] = {
							["g"] = 0.5019607843137255,
							["b"] = 0.3450980392156863,
						},
						["LOW"] = {
							["g"] = 0,
							["r"] = 1,
						},
						["HIGH"] = {
							["b"] = 0.9686274509803922,
						},
					},
				},
				["raidicon"] = {
					["y"] = 26,
					["scale"] = 25,
					["anchor"] = "TOP",
					["hpColor"] = false,
				},
			},
			["blizzFade"] = {
				["amount"] = -0.53,
			},
			["totemSettings"] = {
				["hideHealthbar"] = true,
			},
			["allowClass"] = true,
			["friendlyClickThrough"] = true,
			["threat"] = {
				["nonCombat"] = false,
				["tank"] = {
					["scale"] = {
						["MEDIUM"] = 1,
						["LOW"] = 1,
						["HIGH"] = 1,
					},
					["alpha"] = {
						["MEDIUM"] = 1,
						["HIGH"] = 1,
					},
				},
				["dps"] = {
					["scale"] = {
						["MEDIUM"] = 1,
						["LOW"] = 1,
						["HIGH"] = 1,
					},
				},
				["scaleType"] = {
					["Normal"] = 0,
					["Boss"] = 0,
				},
			},
		},
		["PALADIN"] = {
			["nameplate"] = {
				["toggle"] = {
					["Totem"] = true,
				},
				["scale"] = {
					["Elite"] = 1,
					["Boss"] = 1,
					["Neutral"] = 1,
				},
			},
			["allowClass"] = true,
			["uniqueSettings"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				nil, -- [4]
				nil, -- [5]
				nil, -- [6]
				nil, -- [7]
				nil, -- [8]
				nil, -- [9]
				nil, -- [10]
				nil, -- [11]
				nil, -- [12]
				nil, -- [13]
				nil, -- [14]
				nil, -- [15]
				nil, -- [16]
				nil, -- [17]
				nil, -- [18]
				nil, -- [19]
				nil, -- [20]
				nil, -- [21]
				nil, -- [22]
				nil, -- [23]
				nil, -- [24]
				nil, -- [25]
				nil, -- [26]
				nil, -- [27]
				nil, -- [28]
				nil, -- [29]
				nil, -- [30]
				{
				}, -- [31]
				{
				}, -- [32]
				{
				}, -- [33]
				nil, -- [34]
				nil, -- [35]
				nil, -- [36]
				{
				}, -- [37]
				nil, -- [38]
				{
				}, -- [39]
				{
				}, -- [40]
				{
				}, -- [41]
				nil, -- [42]
				nil, -- [43]
				nil, -- [44]
				nil, -- [45]
				nil, -- [46]
				{
				}, -- [47]
				{
				}, -- [48]
				{
				}, -- [49]
				["list"] = {
					"Shadow Fiend", -- [1]
					"Spirit Wolf", -- [2]
					"Ebon Gargoyle", -- [3]
					"Water Elemental", -- [4]
					"Treant", -- [5]
					"Viper", -- [6]
					"Venomous Snake", -- [7]
					"Army of the Dead Ghoul", -- [8]
					"Shadowy Apparition", -- [9]
					"Shambling Horror", -- [10]
					"Web Wrap", -- [11]
					"Immortal Guardian", -- [12]
					"Marked Immortal Guardian", -- [13]
					"Empowered Adherent", -- [14]
					"Deformed Fanatic", -- [15]
					"Reanimated Adherent", -- [16]
					"Reanimated Fanatic", -- [17]
					"Bone Spike", -- [18]
					"Onyxian Whelp", -- [19]
					"Gas Cloud", -- [20]
					"Volatile Ooze", -- [21]
					"Darnavan", -- [22]
					"Val'kyr Shadowguard", -- [23]
					"Kinetic Bomb", -- [24]
					"Lich King", -- [25]
					"Raging Spirit", -- [26]
					"Drudge Ghoul", -- [27]
					"Living Inferno", -- [28]
					"Living Ember", -- [29]
					"Fanged Pit Viper", -- [30]
					"", -- [31]
					"", -- [32]
					"", -- [33]
					"", -- [34]
					"", -- [35]
					"", -- [36]
					"", -- [37]
					"", -- [38]
					"", -- [39]
					"", -- [40]
					"", -- [41]
					"", -- [42]
					"", -- [43]
					"", -- [44]
					"", -- [45]
					"", -- [46]
					"", -- [47]
					"", -- [48]
					"", -- [49]
					"", -- [50]
				},
			},
			["friendlyNameOnly"] = true,
			["text"] = {
				["amount"] = false,
				["full"] = true,
			},
			["settings"] = {
				["tank"] = {
					["threatcolor"] = {
						["MEDIUM"] = {
							["g"] = 0.4823529411764706,
							["b"] = 0.2901960784313725,
						},
						["HIGH"] = {
							["r"] = 1,
							["g"] = 0,
							["b"] = 0.8,
						},
					},
				},
				["highlight"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["eliteicon"] = {
					["show"] = false,
				},
				["spellicon"] = {
					["x"] = -32,
					["scale"] = 30,
					["anchor"] = "LEFT",
					["y"] = -8,
				},
				["spelltext"] = {
					["align"] = "LEFT",
					["width"] = 125,
					["flags"] = "THICKOUTLINE",
					["height"] = 40,
				},
				["level"] = {
					["flags"] = "THICKOUTLINE",
					["size"] = 9,
				},
				["normal"] = {
					["threatcolor"] = {
						["MEDIUM"] = {
							["g"] = 0.4901960784313725,
							["b"] = 0.2705882352941176,
						},
						["LOW"] = {
							["g"] = 0.01568627450980392,
							["b"] = 0,
						},
						["HIGH"] = {
							["b"] = 0.8235294117647058,
						},
					},
				},
				["healthbar"] = {
					["height"] = 20,
					["width"] = 105,
				},
				["healthborder"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["threatborder"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["skullicon"] = {
					["show"] = false,
				},
				["castnostop"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["castbar"] = {
					["width"] = 105,
				},
				["castborder"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["name"] = {
					["y"] = 17,
					["flags"] = "THICKOUTLINE",
					["size"] = 12,
				},
				["customtext"] = {
					["flags"] = "THICKOUTLINE",
					["size"] = 14,
				},
				["frame"] = {
					["height"] = 40,
					["width"] = 109,
				},
				["dps"] = {
					["threatcolor"] = {
						["MEDIUM"] = {
							["g"] = 0.5019607843137255,
							["b"] = 0.3450980392156863,
						},
						["LOW"] = {
							["r"] = 1,
							["g"] = 0,
						},
						["HIGH"] = {
							["b"] = 0.9686274509803922,
						},
					},
				},
				["raidicon"] = {
					["y"] = 26,
					["scale"] = 25,
					["anchor"] = "TOP",
					["hpColor"] = false,
				},
			},
			["friendlyClass"] = true,
			["blizzFade"] = {
				["amount"] = -0.53,
			},
			["totemSettings"] = {
				["hideHealthbar"] = true,
			},
			["friendlyClickThrough"] = true,
			["threat"] = {
				["nonCombat"] = false,
				["tank"] = {
					["scale"] = {
						["MEDIUM"] = 1,
						["LOW"] = 1,
						["HIGH"] = 1,
					},
					["alpha"] = {
						["MEDIUM"] = 1,
						["HIGH"] = 1,
					},
				},
				["scaleType"] = {
					["Normal"] = 0,
					["Boss"] = 0,
				},
				["dps"] = {
					["scale"] = {
						["MEDIUM"] = 1,
						["LOW"] = 1,
						["HIGH"] = 1,
					},
				},
			},
		},
		["O MELHOR TP"] = {
			["nameplate"] = {
				["toggle"] = {
					["Totem"] = true,
				},
				["scale"] = {
					["Elite"] = 1,
					["Boss"] = 1,
					["Neutral"] = 1,
				},
			},
			["allowClass"] = true,
			["uniqueSettings"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				nil, -- [4]
				nil, -- [5]
				nil, -- [6]
				nil, -- [7]
				nil, -- [8]
				nil, -- [9]
				nil, -- [10]
				nil, -- [11]
				nil, -- [12]
				nil, -- [13]
				nil, -- [14]
				nil, -- [15]
				nil, -- [16]
				nil, -- [17]
				nil, -- [18]
				nil, -- [19]
				nil, -- [20]
				nil, -- [21]
				nil, -- [22]
				nil, -- [23]
				nil, -- [24]
				nil, -- [25]
				nil, -- [26]
				nil, -- [27]
				nil, -- [28]
				nil, -- [29]
				nil, -- [30]
				{
				}, -- [31]
				{
				}, -- [32]
				{
				}, -- [33]
				nil, -- [34]
				nil, -- [35]
				nil, -- [36]
				{
				}, -- [37]
				nil, -- [38]
				{
				}, -- [39]
				{
				}, -- [40]
				{
				}, -- [41]
				nil, -- [42]
				nil, -- [43]
				nil, -- [44]
				nil, -- [45]
				nil, -- [46]
				{
				}, -- [47]
				{
				}, -- [48]
				{
				}, -- [49]
				["list"] = {
					"Shadow Fiend", -- [1]
					"Spirit Wolf", -- [2]
					"Ebon Gargoyle", -- [3]
					"Water Elemental", -- [4]
					"Treant", -- [5]
					"Viper", -- [6]
					"Venomous Snake", -- [7]
					"Army of the Dead Ghoul", -- [8]
					"Shadowy Apparition", -- [9]
					"Shambling Horror", -- [10]
					"Web Wrap", -- [11]
					"Immortal Guardian", -- [12]
					"Marked Immortal Guardian", -- [13]
					"Empowered Adherent", -- [14]
					"Deformed Fanatic", -- [15]
					"Reanimated Adherent", -- [16]
					"Reanimated Fanatic", -- [17]
					"Bone Spike", -- [18]
					"Onyxian Whelp", -- [19]
					"Gas Cloud", -- [20]
					"Volatile Ooze", -- [21]
					"Darnavan", -- [22]
					"Val'kyr Shadowguard", -- [23]
					"Kinetic Bomb", -- [24]
					"Lich King", -- [25]
					"Raging Spirit", -- [26]
					"Drudge Ghoul", -- [27]
					"Living Inferno", -- [28]
					"Living Ember", -- [29]
					"Fanged Pit Viper", -- [30]
					"", -- [31]
					"", -- [32]
					"", -- [33]
					"", -- [34]
					"", -- [35]
					"", -- [36]
					"", -- [37]
					"", -- [38]
					"", -- [39]
					"", -- [40]
					"", -- [41]
					"", -- [42]
					"", -- [43]
					"", -- [44]
					"", -- [45]
					"", -- [46]
					"", -- [47]
					"", -- [48]
					"", -- [49]
					"", -- [50]
				},
			},
			["friendlyNameOnly"] = true,
			["threat"] = {
				["nonCombat"] = false,
				["tank"] = {
					["scale"] = {
						["MEDIUM"] = 1,
						["LOW"] = 1,
						["HIGH"] = 1,
					},
					["alpha"] = {
						["MEDIUM"] = 1,
						["HIGH"] = 1,
					},
				},
				["scaleType"] = {
					["Normal"] = 0,
					["Boss"] = 0,
				},
				["dps"] = {
					["scale"] = {
						["MEDIUM"] = 1,
						["LOW"] = 1,
						["HIGH"] = 1,
					},
				},
			},
			["cache"] = {
			},
			["settings"] = {
				["tank"] = {
					["threatcolor"] = {
						["MEDIUM"] = {
							["g"] = 0.4823529411764706,
							["b"] = 0.2901960784313725,
						},
						["HIGH"] = {
							["r"] = 1,
							["g"] = 0,
							["b"] = 0.8,
						},
					},
				},
				["highlight"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["eliteicon"] = {
					["show"] = false,
				},
				["spellicon"] = {
					["x"] = -32,
					["scale"] = 30,
					["anchor"] = "LEFT",
					["y"] = -8,
				},
				["spelltext"] = {
					["align"] = "LEFT",
					["width"] = 125,
					["flags"] = "THICKOUTLINE",
					["height"] = 40,
				},
				["level"] = {
					["flags"] = "THICKOUTLINE",
					["size"] = 9,
				},
				["normal"] = {
					["threatcolor"] = {
						["MEDIUM"] = {
							["g"] = 0.4901960784313725,
							["b"] = 0.2705882352941176,
						},
						["LOW"] = {
							["g"] = 0.01568627450980392,
							["b"] = 0,
						},
						["HIGH"] = {
							["b"] = 0.8235294117647058,
						},
					},
				},
				["healthbar"] = {
					["height"] = 20,
					["width"] = 105,
				},
				["healthborder"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["threatborder"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["skullicon"] = {
					["show"] = false,
				},
				["castnostop"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["castbar"] = {
					["width"] = 105,
				},
				["castborder"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["name"] = {
					["y"] = 17,
					["flags"] = "THICKOUTLINE",
					["size"] = 12,
				},
				["customtext"] = {
					["flags"] = "THICKOUTLINE",
					["size"] = 14,
				},
				["frame"] = {
					["height"] = 40,
					["width"] = 109,
				},
				["dps"] = {
					["threatcolor"] = {
						["MEDIUM"] = {
							["g"] = 0.5019607843137255,
							["b"] = 0.3450980392156863,
						},
						["LOW"] = {
							["r"] = 1,
							["g"] = 0,
						},
						["HIGH"] = {
							["b"] = 0.9686274509803922,
						},
					},
				},
				["raidicon"] = {
					["y"] = 26,
					["scale"] = 25,
					["anchor"] = "TOP",
					["hpColor"] = false,
				},
			},
			["friendlyClass"] = true,
			["text"] = {
				["amount"] = false,
				["full"] = true,
			},
			["blizzFade"] = {
				["amount"] = -0.53,
			},
			["totemSettings"] = {
				["hideHealthbar"] = true,
			},
			["friendlyClickThrough"] = true,
		},
		["Muuzlol - Icecrown"] = {
			["nameplate"] = {
				["toggle"] = {
					["Totem"] = true,
				},
				["scale"] = {
					["Elite"] = 1,
					["Boss"] = 1,
					["Neutral"] = 1,
				},
			},
			["allowClass"] = true,
			["uniqueSettings"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				nil, -- [4]
				nil, -- [5]
				nil, -- [6]
				nil, -- [7]
				nil, -- [8]
				nil, -- [9]
				nil, -- [10]
				nil, -- [11]
				nil, -- [12]
				nil, -- [13]
				nil, -- [14]
				nil, -- [15]
				nil, -- [16]
				nil, -- [17]
				nil, -- [18]
				nil, -- [19]
				nil, -- [20]
				nil, -- [21]
				nil, -- [22]
				nil, -- [23]
				nil, -- [24]
				nil, -- [25]
				nil, -- [26]
				nil, -- [27]
				nil, -- [28]
				nil, -- [29]
				nil, -- [30]
				{
				}, -- [31]
				{
				}, -- [32]
				{
				}, -- [33]
				nil, -- [34]
				nil, -- [35]
				nil, -- [36]
				{
				}, -- [37]
				nil, -- [38]
				{
				}, -- [39]
				{
				}, -- [40]
				{
				}, -- [41]
				nil, -- [42]
				nil, -- [43]
				nil, -- [44]
				nil, -- [45]
				nil, -- [46]
				{
				}, -- [47]
				{
				}, -- [48]
				{
				}, -- [49]
				["list"] = {
					"Shadow Fiend", -- [1]
					"Spirit Wolf", -- [2]
					"Ebon Gargoyle", -- [3]
					"Water Elemental", -- [4]
					"Treant", -- [5]
					"Viper", -- [6]
					"Venomous Snake", -- [7]
					"Army of the Dead Ghoul", -- [8]
					"Shadowy Apparition", -- [9]
					"Shambling Horror", -- [10]
					"Web Wrap", -- [11]
					"Immortal Guardian", -- [12]
					"Marked Immortal Guardian", -- [13]
					"Empowered Adherent", -- [14]
					"Deformed Fanatic", -- [15]
					"Reanimated Adherent", -- [16]
					"Reanimated Fanatic", -- [17]
					"Bone Spike", -- [18]
					"Onyxian Whelp", -- [19]
					"Gas Cloud", -- [20]
					"Volatile Ooze", -- [21]
					"Darnavan", -- [22]
					"Val'kyr Shadowguard", -- [23]
					"Kinetic Bomb", -- [24]
					"Lich King", -- [25]
					"Raging Spirit", -- [26]
					"Drudge Ghoul", -- [27]
					"Living Inferno", -- [28]
					"Living Ember", -- [29]
					"Fanged Pit Viper", -- [30]
					"", -- [31]
					"", -- [32]
					"", -- [33]
					"", -- [34]
					"", -- [35]
					"", -- [36]
					"", -- [37]
					"", -- [38]
					"", -- [39]
					"", -- [40]
					"", -- [41]
					"", -- [42]
					"", -- [43]
					"", -- [44]
					"", -- [45]
					"", -- [46]
					"", -- [47]
					"", -- [48]
					"", -- [49]
					"", -- [50]
				},
			},
			["friendlyNameOnly"] = true,
			["text"] = {
				["amount"] = false,
				["full"] = true,
			},
			["settings"] = {
				["tank"] = {
					["threatcolor"] = {
						["MEDIUM"] = {
							["g"] = 0.4823529411764706,
							["b"] = 0.2901960784313725,
						},
						["HIGH"] = {
							["r"] = 1,
							["g"] = 0,
							["b"] = 0.8,
						},
					},
				},
				["highlight"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["eliteicon"] = {
					["show"] = false,
				},
				["spellicon"] = {
					["x"] = -32,
					["scale"] = 30,
					["anchor"] = "LEFT",
					["y"] = -8,
				},
				["spelltext"] = {
					["align"] = "LEFT",
					["width"] = 125,
					["flags"] = "THICKOUTLINE",
					["height"] = 40,
				},
				["level"] = {
					["flags"] = "THICKOUTLINE",
					["size"] = 9,
				},
				["normal"] = {
					["threatcolor"] = {
						["MEDIUM"] = {
							["g"] = 0.4901960784313725,
							["b"] = 0.2705882352941176,
						},
						["LOW"] = {
							["g"] = 0.01568627450980392,
							["b"] = 0,
						},
						["HIGH"] = {
							["b"] = 0.8235294117647058,
						},
					},
				},
				["healthbar"] = {
					["height"] = 20,
					["width"] = 105,
				},
				["healthborder"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["threatborder"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["skullicon"] = {
					["show"] = false,
				},
				["castnostop"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["castbar"] = {
					["width"] = 105,
				},
				["castborder"] = {
					["height"] = 74,
					["width"] = 230,
				},
				["name"] = {
					["y"] = 17,
					["flags"] = "THICKOUTLINE",
					["size"] = 12,
				},
				["customtext"] = {
					["flags"] = "THICKOUTLINE",
					["size"] = 14,
				},
				["frame"] = {
					["height"] = 40,
					["width"] = 109,
				},
				["dps"] = {
					["threatcolor"] = {
						["MEDIUM"] = {
							["g"] = 0.5019607843137255,
							["b"] = 0.3450980392156863,
						},
						["LOW"] = {
							["r"] = 1,
							["g"] = 0,
						},
						["HIGH"] = {
							["b"] = 0.9686274509803922,
						},
					},
				},
				["raidicon"] = {
					["y"] = 26,
					["scale"] = 25,
					["anchor"] = "TOP",
					["hpColor"] = false,
				},
			},
			["friendlyClass"] = true,
			["blizzFade"] = {
				["amount"] = -0.53,
			},
			["totemSettings"] = {
				["hideHealthbar"] = true,
			},
			["friendlyClickThrough"] = true,
			["threat"] = {
				["nonCombat"] = false,
				["tank"] = {
					["scale"] = {
						["MEDIUM"] = 1,
						["LOW"] = 1,
						["HIGH"] = 1,
					},
					["alpha"] = {
						["MEDIUM"] = 1,
						["HIGH"] = 1,
					},
				},
				["scaleType"] = {
					["Normal"] = 0,
					["Boss"] = 0,
				},
				["dps"] = {
					["scale"] = {
						["MEDIUM"] = 1,
						["LOW"] = 1,
						["HIGH"] = 1,
					},
				},
			},
		},
	},
}
