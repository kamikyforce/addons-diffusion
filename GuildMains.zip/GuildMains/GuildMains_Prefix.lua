----------------------------------------
-- Guild Mains, (c) 2009 John Stephen, wobbleworks.com
-- All rights reserved, unauthorized redistribution is prohibited
----------------------------------------

GuildMains =
{
	AddonName = "GuildMains",
	AddonColorCode = "|cff22aa22",
	AddonPath = "Interface\\Addons\\GuildMains\\",
}

MCAddon = GuildMains

function MCAddon:New(pMethodTable, ...)
	local vObject
	
	if type(pMethodTable) ~= "table" then
		error("table expected")
	end
	
	if pMethodTable.New then
		vObject = pMethodTable:New(...)
	else
		vObject = {}
	end
	
	vObject.Inherit = self.Inherit
	
	vObject:Inherit(pMethodTable, ...)
	
	return vObject
end

function MCAddon:Inherit(pMethodTable, ...)
	for vKey, vValue in pairs(pMethodTable) do
		if self[vKey] then
			if not self.Inherited then
				self.Inherited = {}
			end
			
			self.Inherited[vKey] = self[vKey]
		end
		
		self[vKey] = vValue
	end
	
	if pMethodTable.Construct then
		pMethodTable.Construct(self, ...)
	end
end

function MCAddon:DuplicateTable(pTable, pRecurse, pDestTable)
	if not pTable then
		return nil
	end
	
	local vTable
	
	if pDestTable then
		if type(pDestTable) ~= "table" then
			error("table expected for pDestTable")
		end
		
		vTable = pDestTable
	else
		vTable = {}
	end
	
	if pRecurse then
		for vKey, vValue in pairs(pTable) do
			if type(vValue) == "table" then
				vTable[vKey] = self:DuplicateTable(vValue, true)
			else
				vTable[vKey] = vValue
			end
		end
	else
		self:CopyTable(vTable, pTable)
	end
	
	return vTable
end

function MCAddon:CopyTable(pDestTable, pTable)
	for vKey, vValue in pairs(pTable) do
		pDestTable[vKey] = vValue
	end
end
