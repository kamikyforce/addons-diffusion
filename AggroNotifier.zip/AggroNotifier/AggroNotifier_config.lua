-- Config storage property
AggroNotifier_Config = {};

-- Constants
local DRAGGER_FRAME_Y_OFFSET = -20;
local DRAGGER_FRAME_Y_OFFSET_PET = -50;

-- Config property defaults
local configDefaultDesiredFadeTimeMilliseconds = 2.50 * 1000;
local configDefaultDesiredExtraTargetSearchDepth = 0;
local configDefaultRefreshAggroTextOnEveryNewAggro = true;
local configDefaultAlwaysSearchForAggro = true;
local configDefaultIncludePvpTagInEnemyName = true;
local configDefaultAddonEnabled = true;
local configDefaultSoloEnabledForMobs = true;
local configDefaultSoloEnabledForPvp = true;
local configDefaultGainAggroColor = { 1.00, 0.00, 0.00, 1.00 };
local configDefaultLoseAggroColor = { 0.00, 1.00, 0.00, 1.00 };
local configDefaultGainAggroColorPet = { 1.00, 0.22, 0.00, 1.00 };
local configDefaultLoseAggroColorPet = { 0.00, 1.00, 0.29, 1.00 };
local configDefaultAggroTextLocationOffsets = { 0, DRAGGER_FRAME_Y_OFFSET, "CENTER", "CENTER" };
local configDefaultAggroTextLocationOffsetsPet = { 0, DRAGGER_FRAME_Y_OFFSET_PET, "CENTER", "CENTER" };
local configDefaultDesiredAggroTextFontSize = AggroNotifier_MAX_NON_DISTORTED_FONT_SIZE; -- AggroNotifier_MAX_NON_DISTORTED_FONT_SIZE is the max font height allowed before you have to resort to SetTextHeight, which distorts the text.
local configDefaultDesiredAggroTextFontSizePet = 24;
local configDefaultPreventFadeoutOnAggroGain = false;
local configDefaultDisableBuiltinVisuals = false;
local configDefaultDisableModIntegrationPlayer = false;
local configDefaultDisableModIntegrationPet = false;
local configDefaultPlaySoundOnAggroGain = false;
AggroNotifier_configDefaultTimeDelayBetweenAggroSearches = 0.1;
AggroNotifier_configDefaultTimeDelayBetweenTextFadeUpdates = 0.05;

local configDefaultIntegrateWithSct = false;
local configDefaultSctShowAsCrit = true;
local configDefaultSctFrameToOutputTo = 1; -- 0 is the messages frame, 1 is frame 1 (SCT's default), and 2 is frame 2.

local configDefaultIntegrateWithMik = false;
local configDefaultMikFrameToOutputTo = "Notification"; -- Use MikSBT.IterateScrollAreas() to see all available options.
local configDefaultMikShowAsSticky = true;
local configDefaultMikUseAggroNotifierFontSize = true;

-- Set up key/default pairings for our config properties. The first value in each subarray is the name of the config property in the config file (the key).
-- The second value is the desired default for that property.
local configDefaultsArray = {
        -- Set up the key/default pairings for normal config stuff. 
        {"desiredFadeTimeMilliseconds", configDefaultDesiredFadeTimeMilliseconds},
        {"desiredExtraTargetSearchDepth", configDefaultDesiredExtraTargetSearchDepth},
        {"desiredAggroText", AGGRO_NOTIFIER_NORMAL_AGGRO_TEXT},
        {"desiredGenericAggroText", AGGRO_NOTIFIER_GENERIC_AGGRO_TEXT},
        {"desiredRefreshAggroTextOnEveryNewAggro", configDefaultRefreshAggroTextOnEveryNewAggro},
        {"desiredAlwaysSearchForAggro", configDefaultAlwaysSearchForAggro},
        {"desiredIncludePvpTagInEnemyName", configDefaultIncludePvpTagInEnemyName},
        {"addonEnabled", configDefaultAddonEnabled},
        {"soloEnabledForMobs", configDefaultSoloEnabledForMobs},
        {"soloEnabledForPvp", configDefaultSoloEnabledForPvp},
        {"gainAggroColor", configDefaultGainAggroColor},
        {"loseAggroColor", configDefaultLoseAggroColor},
        {"desiredAggroTextFontSize", configDefaultDesiredAggroTextFontSize},
        {"desiredAggroTextLocationOffsets", configDefaultAggroTextLocationOffsets},
        {"preventFadeoutOnAggroGain", configDefaultPreventFadeoutOnAggroGain},
        {"disableBuiltinVisuals", configDefaultDisableBuiltinVisuals},
        {"disableModIntegrationPlayer", configDefaultDisableModIntegrationPlayer},
        {"playSoundOnAggroGain", configDefaultPlaySoundOnAggroGain},
        {"timeDelayBetweenAggroSearches", AggroNotifier_configDefaultTimeDelayBetweenAggroSearches},
        -- Do the same for our pet config stuff.
        {"desiredFadeTimeMillisecondsPet", configDefaultDesiredFadeTimeMilliseconds},
        {"desiredExtraTargetSearchDepthPet", configDefaultDesiredExtraTargetSearchDepth},
        {"desiredAggroTextPet", AGGRO_NOTIFIER_NORMAL_PET_AGGRO_TEXT},
        {"desiredGenericAggroTextPet", AGGRO_NOTIFIER_GENERIC_PET_AGGRO_TEXT},
        {"desiredRefreshAggroTextOnEveryNewAggroPet", configDefaultRefreshAggroTextOnEveryNewAggro},
        {"desiredAlwaysSearchForAggroPet", configDefaultAlwaysSearchForAggro},
        {"desiredIncludePvpTagInEnemyNamePet", configDefaultIncludePvpTagInEnemyName},
        {"addonEnabledPet", configDefaultAddonEnabled},
        {"soloEnabledForMobsPet", configDefaultSoloEnabledForMobs},
        {"soloEnabledForPvpPet", configDefaultSoloEnabledForPvp},
        {"gainAggroColorPet", configDefaultGainAggroColorPet},
        {"loseAggroColorPet", configDefaultLoseAggroColorPet},
        {"desiredAggroTextFontSizePet", configDefaultDesiredAggroTextFontSizePet},
        {"desiredAggroTextLocationOffsetsPet", configDefaultAggroTextLocationOffsetsPet},
        {"preventFadeoutOnAggroGainPet", configDefaultPreventFadeoutOnAggroGain},
        {"disableBuiltinVisualsPet", configDefaultDisableBuiltinVisuals},
        {"disableModIntegrationPet", configDefaultDisableModIntegrationPet},
        {"playSoundOnAggroGainPet", configDefaultPlaySoundOnAggroGain},
        {"timeDelayBetweenAggroSearchesPet", AggroNotifier_configDefaultTimeDelayBetweenAggroSearches},
        -- Do the same for our addon integration stuff.
        {"integrateWithSct", configDefaultIntegrateWithSct},
        {"sctShowAsCrit", configDefaultSctShowAsCrit},
        {"sctFrameToOutputTo", configDefaultSctFrameToOutputTo},
        {"integrateWithMik", configDefaultIntegrateWithMik},
        {"mikFrameToOutputTo", configDefaultMikFrameToOutputTo},
        {"mikShowAsSticky", configDefaultMikShowAsSticky},
        {"mikUseAggroNotifierFontSize", configDefaultMikUseAggroNotifierFontSize},
    };

-- Script-built frame stuff
local maxAllowedFadeTimeMilliseconds = 10 * 1000;
local maxAllowedExtraTargetSearchDepth = 2;
local AggroNotifier_OptionsFrameContainer;
-- Script-built frame stuff for player
local AggroNotifier_OptionsSubFrameAppearance;
local AggroNotifier_OptionsSubFrameBehavior;
local AggroNotifier_OptionsGenericAggroTextEditBox;
local AggroNotifier_OptionsAggroTextEditBox;
local AggroNotifier_OptionsIncludePvpInEnemyNameCheckbox;
local AggroNotifier_OptionsFadeTimeSlider;
local AggroNotifier_OptionsExtraTargetSearchDepthSlider;
local AggroNotifier_OptionsRefreshAggroTextCheckbox;
local AggroNotifier_OptionsAlwaysSearchForAggroCheckbox;
local AggroNotifier_OptionsAddonEnabledCheckbox;
local AggroNotifier_OptionsSoloEnabledForMobsCheckbox;
local AggroNotifier_OptionsSoloEnabledForPvpCheckbox;
local AggroNotifier_OptionsGainAggroColorButton;
local AggroNotifier_OptionsLoseAggroColorButton;
local AggroNotifier_OptionsFontSizeSlider;
local AggroNotifier_OptionsResetAggroTextAnchorButton;
local AggroNotifier_OptionsShowAggroTextAnchorButton;
local AggroNotifier_OptionsPreventFadeoutCheckbox;
local AggroNotifier_OptionsDisableBuiltinVisuals;
local AggroNotifier_OptionsDisableModIntegration;
local AggroNotifier_OptionsPlaySoundCheckbox;
local AggroNotifier_OptionsTimeDelayBetweenAggroSearchesSlider;
-- Script-built frame stuff for pet
local AggroNotifier_PetOptionsSubFrameAppearance;
local AggroNotifier_PetOptionsSubFrameBehavior;
local AggroNotifier_PetOptionsGenericAggroTextEditBox;
local AggroNotifier_PetOptionsAggroTextEditBox;
local AggroNotifier_PetOptionsIncludePvpInEnemyNameCheckbox;
local AggroNotifier_PetOptionsFadeTimeSlider;
local AggroNotifier_PetOptionsExtraTargetSearchDepthSlider;
local AggroNotifier_PetOptionsRefreshAggroTextCheckbox;
local AggroNotifier_PetOptionsAlwaysSearchForAggroCheckbox;
local AggroNotifier_PetOptionsAddonEnabledCheckbox;
local AggroNotifier_PetOptionsSoloEnabledForMobsCheckbox;
local AggroNotifier_PetOptionsSoloEnabledForPvpCheckbox;
local AggroNotifier_PetOptionsGainAggroColorButton;
local AggroNotifier_PetOptionsLoseAggroColorButton;
local AggroNotifier_PetOptionsFontSizeSlider;
local AggroNotifier_PetOptionsResetAggroTextAnchorButton;
local AggroNotifier_PetOptionsShowAggroTextAnchorButton;
local AggroNotifier_PetOptionsPreventFadeoutCheckbox;
local AggroNotifier_PetOptionsDisableBuiltinVisuals;
local AggroNotifier_PetOptionsDisableModIntegration;
local AggroNotifier_PetOptionsPlaySoundCheckbox;
local AggroNotifier_PetOptionsTimeDelayBetweenAggroSearchesSlider;
-- Script-built frame stuff for mod integration
local AggroNotifier_OtherModOptionsSubFrame;
local AggroNotifier_OtherModOptionsSctDisabledTitle;
local AggroNotifier_OtherModOptionsIntegrateWithSctCheckbox;
local AggroNotifier_OtherModOptionsSctShowAsCritCheckbox;
local AggroNotifier_OtherModOptionsSctFrameToOutputToDropDown;
local AggroNotifier_OtherModOptionsSctTestButton;
local AggroNotifier_OtherModOptionsMikDisabledTitle;
local AggroNotifier_OtherModOptionsIntegrateWithMikCheckbox;
local AggroNotifier_OtherModOptionsMikShowAsStickyCheckbox;
local AggroNotifier_OtherModOptionsMikFrameToOutputToDropDown;
local AggroNotifier_OtherModOptionsMikUseAggroNotifierFontSizeCheckbox;
local AggroNotifier_OtherModOptionsMikTestButton;


-- Runtime-only properties - player
local allowAggroTextRefreshForFontSizeSlider = false;
local optionsFrameActive = false;
local appearanceOptionsSubFrameLoaded = false;
-- Runtime-only properties - pet
local allowPetAggroTextRefreshForFontSizeSlider = false;
local petOptionsFrameActive = false;
local petAppearanceOptionsSubFrameLoaded = false;

local AggroNotifier_EventAndUpdateFrame = CreateFrame("Frame", "AggroNotifier_EventAndUpdateFrame", UIParent);

-- Initial load function, called by the automatic execution code at the end of this file.
function AggroNotifier_Load()
    -- Set the functions that will be called when events or update ticks occur.
    AggroNotifier_EventAndUpdateFrame:SetScript("OnEvent", AggroNotifier_GeneralEventHandler);
    AggroNotifier_EventAndUpdateFrame:SetScript("OnUpdate", AggroNotifier_ProcessUpdate);
    
    -- Register for a few events so that we can load the addon properly and keep track of whether the player's in combat or not.
    AggroNotifier_EventAndUpdateFrame:RegisterEvent("ADDON_LOADED");
    AggroNotifier_EventAndUpdateFrame:RegisterEvent("VARIABLES_LOADED");
    AggroNotifier_EventAndUpdateFrame:RegisterEvent("PLAYER_REGEN_DISABLED");
    AggroNotifier_EventAndUpdateFrame:RegisterEvent("PLAYER_REGEN_ENABLED");
end

-- Config loading function. Called when the addon is finished loading (via the ADDON_LOADED event), this is responsible for 
-- making sure the config file is loaded and initialized properly, then sets up various widgets that rely on the config file settings.
function AggroNotifier_LoadConfig()
    -- Load all the stored values from our config. Initialize config properties to defaults if they're not already saved.
    -- Do this by running through each key/default pair from our config defaults array and set the default if necessary.
    local emptyOrCorruptConfig = false;
    if (AggroNotifier_Config["desiredAggroTextFontSize"] == nil or AggroNotifier_Config["desiredAggroTextFontSize"] <= 0) then
        DEFAULT_CHAT_FRAME:AddMessage(AGGRO_NOTIFIER_CONFIG_FILE_SETTING_DEFAULTS_MESSAGE);
        emptyOrCorruptConfig = true;
    end
    
    for i, configKeyDefaultPair in ipairs(configDefaultsArray) do
        local key = configKeyDefaultPair[1];
        local default = configKeyDefaultPair[2];
        
        if (emptyOrCorruptConfig or AggroNotifier_Config[key] == nil) then
            AggroNotifier_Config[key] = default;
        end
    end
    
    -- Generate our options panes.
    AggroNotifier_GenerateOptionsFrame();
    
    -- Initialize the aggro text frame draggers now that the config file has been loaded.
    AggroNotifier_InitializeAggroFrameDraggers();
    
    -- Initialize the aggro text itself now that the config file has been loaded.
    AggroNotifier_InitializeAllAggroText();
    
    -- Setup our options frames and attach them to blizzard's addon-options frame.
    AggroNotifier_OptionsFrameContainer.name = AGGRO_NOTIFIER_ADDON_NAME; -- Set the title of our options container frame.
    AggroNotifier_OptionsFrameContainer.okay = AggroNotifier_UpdateOptionsFrame; -- Link the ok button to our options frame update function.
    AggroNotifier_OptionsFrameContainer.cancel = AggroNotifier_CancelOptionsFrame; -- Link the cancel button to our options frame cancel function.
    AggroNotifier_OptionsFrameContainer.default = AggroNotifier_SetDefaultsOnOptionsFrame; -- Link the default button to our options frame's "set defaults" function.

    AggroNotifier_OptionsSubFrameAppearance.name = AGGRO_NOTIFIER_OPTIONS_FRAME_LABEL_APPEARANCE;
    AggroNotifier_OptionsSubFrameAppearance.parent = AGGRO_NOTIFIER_ADDON_NAME; -- By setting the parent variable this will show up as a subframe of our main options container.
    AggroNotifier_OptionsSubFrameAppearance.default = AggroNotifier_SetDefaultsOnOptionsFrame;
    
    AggroNotifier_OptionsSubFrameBehavior.name = AGGRO_NOTIFIER_OPTIONS_FRAME_LABEL_BEHAVIOR;
    AggroNotifier_OptionsSubFrameBehavior.parent = AGGRO_NOTIFIER_ADDON_NAME;
    AggroNotifier_OptionsSubFrameBehavior.default = AggroNotifier_SetDefaultsOnOptionsFrame;
    
    AggroNotifier_PetOptionsSubFrameAppearance.name = AGGRO_NOTIFIER_OPTIONS_FRAME_LABEL_APPEARANCE_PET;
    AggroNotifier_PetOptionsSubFrameAppearance.parent = AGGRO_NOTIFIER_ADDON_NAME;
    AggroNotifier_PetOptionsSubFrameAppearance.default = AggroNotifier_SetDefaultsOnOptionsFrame;
    
    AggroNotifier_PetOptionsSubFrameBehavior.name = AGGRO_NOTIFIER_OPTIONS_FRAME_LABEL_BEHAVIOR_PET;
    AggroNotifier_PetOptionsSubFrameBehavior.parent = AGGRO_NOTIFIER_ADDON_NAME;
    AggroNotifier_PetOptionsSubFrameBehavior.default = AggroNotifier_SetDefaultsOnOptionsFrame;
    
    AggroNotifier_OtherModOptionsSubFrame.name = AGGRO_NOTIFIER_OPTIONS_FRAME_LABEL_OTHER_ADDON_INTEGRATION;
    AggroNotifier_OtherModOptionsSubFrame.parent = AGGRO_NOTIFIER_ADDON_NAME;
    AggroNotifier_OtherModOptionsSubFrame.default = AggroNotifier_SetDefaultsOnOptionsFrame;
    
    InterfaceOptions_AddCategory(AggroNotifier_OptionsFrameContainer);
    InterfaceOptions_AddCategory(AggroNotifier_OptionsSubFrameAppearance);
    InterfaceOptions_AddCategory(AggroNotifier_OptionsSubFrameBehavior);
    InterfaceOptions_AddCategory(AggroNotifier_PetOptionsSubFrameAppearance);
    InterfaceOptions_AddCategory(AggroNotifier_PetOptionsSubFrameBehavior);
    InterfaceOptions_AddCategory(AggroNotifier_OtherModOptionsSubFrame);
    
    DEFAULT_CHAT_FRAME:AddMessage("AggroNotifier Loaded");
end

-- Sets up the aggro text frame draggers for the first time.
function AggroNotifier_InitializeAggroFrameDraggers()
    -- Set a few properties on the frame draggers so the helper functions know what to do.
    AggroNotifier_AggroFrameDragger.isPet = false;
    AggroNotifier_AggroFrameDraggerPet.isPet = true;

    AggroNotifier_AggroFrameDragger.locationOffsetsConfigPropertyName = "desiredAggroTextLocationOffsets";
    AggroNotifier_AggroFrameDraggerPet.locationOffsetsConfigPropertyName = "desiredAggroTextLocationOffsetsPet";

    AggroNotifier_AggroFrame.textObject = AggroNotifier_AggroText;
    AggroNotifier_AggroFramePet.textObject = AggroNotifier_AggroTextPet;
    AggroNotifier_AggroFrameDragger.textFrame = AggroNotifier_AggroFrame;
    AggroNotifier_AggroFrameDraggerPet.textFrame = AggroNotifier_AggroFramePet;

    -- Initialize the regular and pet frame draggers.   
    AggroNotifier_AggroFrameDragger:SetWidth(210);
    AggroNotifier_AggroFrameDragger:SetHeight(22);
    AggroNotifier_InitializeDraggerFrameObject(AggroNotifier_AggroFrameDragger, AGGRO_NOTIFIER_DRAG_AGGRO_TEXT);
    AggroNotifier_AggroFrameDraggerPet:SetWidth(230);
    AggroNotifier_AggroFrameDraggerPet:SetHeight(22);
    AggroNotifier_InitializeDraggerFrameObject(AggroNotifier_AggroFrameDraggerPet, AGGRO_NOTIFIER_DRAG_AGGRO_TEXT_PET);
end

-- Helper function for AggroNotifier_InitializeAggroFrameDraggers() that initializes the specified frame dragger.
function AggroNotifier_InitializeDraggerFrameObject(draggerFrame, frameText)
    -- Setup the aggro frame dragger bits. Start with the frame dragger text.
    draggerFrame.text = draggerFrame:CreateFontString(nil, "ARTWORK", "GameFontNormal");
    draggerFrame.text:SetText(frameText);
    draggerFrame.text:SetPoint("LEFT", 8, 0);
    
    -- Reset the frame dragger width based on the text width (with room left over for the button).  
    draggerFrame:SetWidth(draggerFrame.text:GetStringWidth() + 40);
    
    -- Setup the frame dragger close box.
    draggerFrame.closeButton = CreateFrame("Button", nil, draggerFrame, "UIPanelCloseButton");
    draggerFrame.closeButton:SetWidth(20);
    draggerFrame.closeButton:SetHeight(20);
    draggerFrame.closeButton:SetPoint("RIGHT", -2, 0);
    
    -- Set the dragging behavior.
    draggerFrame:SetMovable(true);
    draggerFrame:EnableMouse(true);
    draggerFrame:SetToplevel(true);
    draggerFrame:SetClampedToScreen(true);
    draggerFrame:SetScript("OnMouseDown",
       function() 
           this:StartMoving();
           this.isBeingDragged = true;
       end);
    draggerFrame:SetScript("OnMouseUp",
        function()
            this.isBeingDragged = false;
            this:StopMovingOrSizing();
            
            -- Set the new dragger location in the config file.
            local anchorPoint, relativeTo, relativePoint, xOffset, yOffset = this:GetPoint();
            AggroNotifier_SetAggroTextLocationConfigProperty(this, xOffset, yOffset, anchorPoint, relativePoint);

            -- Update the onscreen widgets based on the new location.            
            AggroNotifier_SetAggroFrameDraggerToDesiredLocation(this);
            AggroNotifier_SetAggroTextFrameToDraggerLocation(this);
            AggroNotifier_RefreshAggroText(this.textFrame.textObject, false, true);
        end);
    draggerFrame:SetScript("OnUpdate",
        function()
            if (AggroNotifier_ForceBoolean(this.isBeingDragged)) then
                AggroNotifier_SetAggroTextFrameToDraggerLocation(this);
                AggroNotifier_RefreshAggroText(this.textFrame.textObject, false, true);
            end
        end);
    
    -- Hide the frame dragger.
    draggerFrame:Hide();
    
    -- Initialize the aggro text frame and dragger location.
    AggroNotifier_SetAggroFrameDraggerToDesiredLocation(draggerFrame);
    AggroNotifier_SetAggroTextFrameToDraggerLocation(draggerFrame);
end

-- This creates and sets up the object widgets that go in the various options panes.
function AggroNotifier_GenerateOptionsFrame()
    -- Create the options container frame.
    AggroNotifier_OptionsFrameContainer = CreateFrame("Frame", "AggroNotifier_OptionsFrameContainer", UIParent);
    AggroNotifier_OptionsFrameContainer:SetWidth(400);
    AggroNotifier_OptionsFrameContainer:SetHeight(410);
    AggroNotifier_OptionsFrameContainer:SetFrameStrata("DIALOG");
    AggroNotifier_OptionsFrameContainer:SetScript("OnShow", AggroNotifier_PopulateOptionsFrame);
    
    -- Add title and help text to the container frame.
    local optionsContainerFrameTitle = AggroNotifier_OptionsFrameContainer:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
    optionsContainerFrameTitle:SetPoint("TOPLEFT", 16, -16);
    optionsContainerFrameTitle:SetText(AGGRO_NOTIFIER_OPTIONS_TITLE);
    
    local optionsContainerFrameHelp = AggroNotifier_OptionsFrameContainer:CreateFontString(nil, "ARTWORK", "GameFontNormal");
    optionsContainerFrameHelp:SetPoint("TOPLEFT", optionsContainerFrameTitle, "BOTTOMLEFT", 0, -20);
    optionsContainerFrameHelp:SetWidth(360);
    optionsContainerFrameHelp:SetJustifyH("LEFT");
    optionsContainerFrameHelp:SetText(AGGRO_NOTIFIER_OPTIONS_CONTAINER_FRAME_HELP);
    
    -- Call some helper functions to generate the options subframes.
    AggroNotifier_GenerateOptionsSubframeAppearancePlayer();
    AggroNotifier_GenerateOptionsSubframeBehaviorPlayer();
    AggroNotifier_GenerateOptionsSubframeAppearancePet();
    AggroNotifier_GenerateOptionsSubframeBehaviorPet();
    AggroNotifier_GenerateOptionsSubframeModIntegration();    
end

-- Helper function for AggroNotifier_GenerateOptionsFrame() that generates the appearance (player) options subframe
function AggroNotifier_GenerateOptionsSubframeAppearancePlayer()
    -- Create the player appearance options subframe.
    AggroNotifier_OptionsSubFrameAppearance = CreateFrame("Frame", "AggroNotifier_OptionsSubFrameAppearance");
    AggroNotifier_OptionsSubFrameAppearance:SetScript("OnShow", 
        function()
            AggroNotifier_PopulateOptionsFrame();
            -- Due to some weird bug with the edit box, we need to force-set and force-insert the edit box text the first time this pane is explicitly loaded, otherwise the edit box will appear empty.
            if (not appearanceOptionsSubFrameLoaded) then
                appearanceOptionsSubFrameLoaded = true;
                AggroNotifier_OptionsAggroTextEditBox:SetText("");
                AggroNotifier_OptionsAggroTextEditBox:Insert(tostring(AggroNotifier_Config.desiredAggroText));
                AggroNotifier_OptionsGenericAggroTextEditBox:SetText("");
                AggroNotifier_OptionsGenericAggroTextEditBox:Insert(tostring(AggroNotifier_Config.desiredGenericAggroText));
            end
        end);
        
    -- Add the player appearance option subframe widgets.
    -- Appearance frame title
    local optionsSubFrameAppearanceTitle = AggroNotifier_OptionsSubFrameAppearance:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
    optionsSubFrameAppearanceTitle:SetPoint("TOPLEFT", 16, -16);
    optionsSubFrameAppearanceTitle:SetText(AGGRO_NOTIFIER_OPTIONS_TITLE_APPEARANCE);
    
    -- Desired aggro text box
    AggroNotifier_OptionsAggroTextEditBox = AggroNotifier_CreateTextEditBox(AggroNotifier_OptionsSubFrameAppearance, optionsSubFrameAppearanceTitle, 0, -10,
            AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_OPTION_TITLE, AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_OPTION_DESCRIPTION, "AggroNotifier_OptionsAggroTextEditBox", nil);
    
    -- Include PvP in enemy name checkbox
    AggroNotifier_OptionsIncludePvpInEnemyNameCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_OptionsSubFrameAppearance, AggroNotifier_OptionsAggroTextEditBox, 0, -3, 
            AGGRO_NOTIFIER_INCLUDE_PVP_TAG_OPTION_TEXT, "AggroNotifier_OptionsIncludePvpInEnemyNameCheckbox", AGGRO_NOTIFIER_PLAYER_TOOLTIP_INCLUDE_PVP_IN_ENEMY_NAME);
    
    -- Generic aggro text box
    AggroNotifier_OptionsGenericAggroTextEditBox = AggroNotifier_CreateTextEditBox(AggroNotifier_OptionsSubFrameAppearance, AggroNotifier_OptionsIncludePvpInEnemyNameCheckbox, -5, -7,
            AGGRO_NOTIFIER_GENERIC_AGGRO_TEXT_OPTION_TITLE, AGGRO_NOTIFIER_GENERIC_AGGRO_TEXT_OPTION_DESCRIPTION, "AggroNotifier_OptionsGenericAggroTextEditBox", nil);
    
    -- Show Anchor button
    local showAnchorOnClickFunction = function()
               AggroNotifier_SetAggroFrameDraggerToDesiredLocation(AggroNotifier_AggroFrameDragger);
               AggroNotifier_SetAggroTextFrameToDraggerLocation(AggroNotifier_AggroFrameDragger);
               AggroNotifier_AggroFrameDragger:Show();
               AggroNotifier_RefreshAggroText(AggroNotifier_AggroText, false, true);
            end;
    AggroNotifier_OptionsShowAggroTextAnchorButton = AggroNotifier_CreateButton(AggroNotifier_OptionsSubFrameAppearance, AggroNotifier_OptionsGenericAggroTextEditBox, 0, -10, 
            AGGRO_NOTIFIER_SHOW_ANCHOR_BUTTON_OPTION_TEXT, showAnchorOnClickFunction, "AggroNotifier_OptionsShowAggroTextAnchorButton", nil);
    
    -- Reset Anchor button
    local resetAnchorOnClickFunction = function()
               AggroNotifier_SetAggroTextLocationConfigProperty(AggroNotifier_AggroFrameDragger, configDefaultAggroTextLocationOffsets[1], configDefaultAggroTextLocationOffsets[2], 
                    configDefaultAggroTextLocationOffsets[3], configDefaultAggroTextLocationOffsets[4]);
               AggroNotifier_SetAggroFrameDraggerToDesiredLocation(AggroNotifier_AggroFrameDragger);
               AggroNotifier_SetAggroTextFrameToDraggerLocation(AggroNotifier_AggroFrameDragger);
               AggroNotifier_RefreshAggroText(AggroNotifier_AggroText, false, true);
            end;
    AggroNotifier_OptionsResetAggroTextAnchorButton = AggroNotifier_CreateButton(AggroNotifier_OptionsSubFrameAppearance, AggroNotifier_OptionsShowAggroTextAnchorButton, 10, 0, 
            AGGRO_NOTIFIER_RESET_ANCHOR_BUTTON_OPTION_TEXT, resetAnchorOnClickFunction, "AggroNotifier_OptionsResetAggroTextAnchorButton", nil);
    AggroNotifier_OptionsResetAggroTextAnchorButton:SetPoint("TOPLEFT", AggroNotifier_OptionsShowAggroTextAnchorButton, "TOPRIGHT", 10, 0);                
    
    -- Fade time slider
    local fadeTimeSliderOnValueChangedFunction = function(self, value)
                local valueInSeconds = value / 1000.0;
                AggroNotifier_OptionsFadeTimeSliderText:SetText(AGGRO_NOTIFIER_FADE_TIME_OPTION_TEXT.." "..valueInSeconds);
            end;
    AggroNotifier_OptionsFadeTimeSlider = AggroNotifier_CreateSlider(AggroNotifier_OptionsSubFrameAppearance, AggroNotifier_OptionsShowAggroTextAnchorButton, 0, -20, 
            AGGRO_NOTIFIER_FADE_TIME_OPTION_TEXT, "0.0", "10.0", 0, maxAllowedFadeTimeMilliseconds, 100, fadeTimeSliderOnValueChangedFunction, "AggroNotifier_OptionsFadeTimeSlider", 
            AGGRO_NOTIFIER_PLAYER_TOOLTIP_AGGRO_TEXT_FADE_TIME);
        
    -- Gain Aggro color picker button
    AggroNotifier_OptionsGainAggroColorButton = AggroNotifier_CreateColorPickerButton(AggroNotifier_OptionsSubFrameAppearance, AggroNotifier_OptionsFadeTimeSlider, 
            0, -15, AGGRO_NOTIFIER_GAIN_AGGRO_COLOR_OPTION_TEXT, "AggroNotifier_OptionsGainAggroColorButton", AGGRO_NOTIFIER_PLAYER_TOOLTIP_GAIN_AGGRO_COLOR, AggroNotifier_AggroText);
    
    -- Lose Aggro color picker button
    AggroNotifier_OptionsLoseAggroColorButton = AggroNotifier_CreateColorPickerButton(AggroNotifier_OptionsSubFrameAppearance, AggroNotifier_OptionsGainAggroColorButton, 
            0, -10, AGGRO_NOTIFIER_LOSE_AGGRO_COLOR_OPTION_TEXT, "AggroNotifier_OptionsLoseAggroColorButton", AGGRO_NOTIFIER_PLAYER_TOOLTIP_LOSE_AGGRO_COLOR, AggroNotifier_AggroText);
    
    -- Desired font size
    local fontSizeSliderOnValueChangedFunction = function(self, value)
                AggroNotifier_OptionsFontSizeSliderText:SetText(AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_FONT_SIZE_OPTION_TITLE.." "..value);
                if (allowAggroTextRefreshForFontSizeSlider) then
                    AggroNotifier_SetAggroFontHeight(AggroNotifier_AggroText, value);
                    AggroNotifier_RefreshAggroText(AggroNotifier_AggroText, false, true);
                end
            end;
    AggroNotifier_OptionsFontSizeSlider = AggroNotifier_CreateSlider(AggroNotifier_OptionsSubFrameAppearance, AggroNotifier_OptionsLoseAggroColorButton, 0, -20, 
            AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_FONT_SIZE_OPTION_TITLE, "4", "60", 4, 60, 1, fontSizeSliderOnValueChangedFunction, "AggroNotifier_OptionsFontSizeSlider", 
            AGGRO_NOTIFIER_PLAYER_TOOLTIP_AGGRO_TEXT_FONT_SIZE);
end

-- Helper function for AggroNotifier_GenerateOptionsFrame() that generates the behavior (player) options subframe
function AggroNotifier_GenerateOptionsSubframeBehaviorPlayer()
    -- Create the player behavior options subframe.
    AggroNotifier_OptionsSubFrameBehavior = CreateFrame("Frame", "AggroNotifier_OptionsSubFrameBehavior");
    AggroNotifier_OptionsSubFrameBehavior:SetScript("OnShow", AggroNotifier_PopulateOptionsFrame);
    
    -- Add the player behavior option subframe widgets.
    -- Behavior frame title
    local optionsSubFrameBehaviorTitle = AggroNotifier_OptionsSubFrameBehavior:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
    optionsSubFrameBehaviorTitle:SetPoint("TOPLEFT", 16, -16);
    optionsSubFrameBehaviorTitle:SetText(AGGRO_NOTIFIER_OPTIONS_TITLE_BEHAVIOR);
    
    -- Enabled checkbox
    AggroNotifier_OptionsAddonEnabledCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_OptionsSubFrameBehavior, optionsSubFrameBehaviorTitle, 0, -10, 
            AGGRO_NOTIFIER_ADDON_ENABLED_OPTION_TEXT, "AggroNotifier_OptionsAddonEnabledCheckbox", AGGRO_NOTIFIER_PLAYER_TOOLTIP_ENABLE_ADDON);
    AggroNotifier_OptionsAddonEnabledCheckbox:SetScript("OnClick", 
        function(self)
            local isChecked = AggroNotifier_ForceBoolean(AggroNotifier_OptionsAddonEnabledCheckbox:GetChecked());
            if (isChecked) then
                AggroNotifier_OptionsSoloEnabledForMobsCheckbox:Enable();
                AggroNotifier_OptionsSoloEnabledForPvpCheckbox:Enable();
            else
                AggroNotifier_OptionsSoloEnabledForMobsCheckbox:Disable();
                AggroNotifier_OptionsSoloEnabledForPvpCheckbox:Disable();
            end
        end);
    
    -- Enabled while soloing (mobs) checkbox
    AggroNotifier_OptionsSoloEnabledForMobsCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_OptionsSubFrameBehavior, AggroNotifier_OptionsAddonEnabledCheckbox, 20, 5, 
            AGGRO_NOTIFIER_ENABLED_SOLO_MOB_OPTION_TEXT, "AggroNotifier_OptionsSoloEnabledForMobsCheckbox", AGGRO_NOTIFIER_PLAYER_TOOLTIP_ENABLE_PVE_WHILE_SOLO);
    
    -- Enabled while soloing (pvp) checkbox
    AggroNotifier_OptionsSoloEnabledForPvpCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_OptionsSubFrameBehavior, AggroNotifier_OptionsSoloEnabledForMobsCheckbox, 0, 5, 
            AGGRO_NOTIFIER_ENABLED_SOLO_PVP_OPTION_TEXT, "AggroNotifier_OptionsSoloEnabledForPvpCheckbox", AGGRO_NOTIFIER_PLAYER_TOOLTIP_ENABLE_PVP_WHILE_SOLO);
    
    -- Disable AggroNotifier builtin visuals
    AggroNotifier_OptionsDisableBuiltinVisuals = AggroNotifier_CreateCheckbox(AggroNotifier_OptionsSubFrameBehavior, AggroNotifier_OptionsSoloEnabledForPvpCheckbox, -20, 5, 
            AGGRO_NOTIFIER_DISABLE_BUILTIN_VISUALS_OPTION_TEXT, "AggroNotifier_OptionsDisableBuiltinVisuals", AGGRO_NOTIFIER_PLAYER_TOOLTIP_DISABLE_BUILTIN_VISUALS);
    
    -- Disable mod integration
    AggroNotifier_OptionsDisableModIntegration = AggroNotifier_CreateCheckbox(AggroNotifier_OptionsSubFrameBehavior, AggroNotifier_OptionsDisableBuiltinVisuals, 0, 5, 
            AGGRO_NOTIFIER_DISABLE_MOD_INTEGRATION_PLAYER_OPTION_TEXT, "AggroNotifier_OptionsDisableModIntegration", AGGRO_NOTIFIER_PLAYER_TOOLTIP_DISABLE_MOD_INTEGRATION);
    
    -- Play sound on aggro gain checkbox
    AggroNotifier_OptionsPlaySoundCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_OptionsSubFrameBehavior, AggroNotifier_OptionsDisableModIntegration, 0, 5, 
            AGGRO_NOTIFIER_PLAY_SOUND_ON_AGGRO_GAIN_OPTION_TEXT, "AggroNotifier_OptionsPlaySoundCheckbox", AGGRO_NOTIFIER_PLAYER_TOOLTIP_PLAY_SOUND);
            
    -- Reload aggro text on each new aggro checkbox
    AggroNotifier_OptionsRefreshAggroTextCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_OptionsSubFrameBehavior, AggroNotifier_OptionsPlaySoundCheckbox, 0, -10, 
            AGGRO_NOTIFIER_REFRESH_AGGRO_TEXT_ON_EVERY_NEW_AGGRO_OPTION_TEXT, "AggroNotifier_OptionsRefreshAggroTextCheckbox", AGGRO_NOTIFIER_PLAYER_TOOLTIP_REFRESH_AGGRO_TEXT_EVERY_NEW_AGGRO);
    
    -- Always search for aggro checkbox
    AggroNotifier_OptionsAlwaysSearchForAggroCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_OptionsSubFrameBehavior, AggroNotifier_OptionsRefreshAggroTextCheckbox, 0, 5, 
            AGGRO_NOTIFIER_ALWAYS_SEARCH_FOR_AGGRO_OPTION_TEXT, "AggroNotifier_OptionsAlwaysSearchForAggroCheckbox", AGGRO_NOTIFIER_PLAYER_TOOLTIP_SEARCH_FOR_AGGRO_OUT_OF_COMBAT);
            
    -- Prevent notification fadeout on aggro gain checkbox
    AggroNotifier_OptionsPreventFadeoutCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_OptionsSubFrameBehavior, AggroNotifier_OptionsAlwaysSearchForAggroCheckbox, 0, 5, 
            AGGRO_NOTIFIER_PREVENT_FADEOUT_ON_AGGRO_GAIN_OPTION_TEXT, "AggroNotifier_OptionsPreventFadeoutCheckbox", AGGRO_NOTIFIER_PLAYER_TOOLTIP_PREVENT_FADEOUT);
            
    -- Extra target search depth slider
    local searchDepthSliderOnValueChangedFunction = function(self, value)
                AggroNotifier_OptionsExtraTargetSearchDepthSliderText:SetText(AGGRO_NOTIFIER_EXTRA_TARGET_SEARCH_DEPTH_OPTION_TEXT.." "..value);
            end;
    AggroNotifier_OptionsExtraTargetSearchDepthSlider = AggroNotifier_CreateSlider(AggroNotifier_OptionsSubFrameBehavior, AggroNotifier_OptionsPreventFadeoutCheckbox, 0, -25, 
            AGGRO_NOTIFIER_EXTRA_TARGET_SEARCH_DEPTH_OPTION_TEXT, "0", "2", 0, maxAllowedExtraTargetSearchDepth, 1, searchDepthSliderOnValueChangedFunction, 
            "AggroNotifier_OptionsExtraTargetSearchDepthSlider", AGGRO_NOTIFIER_PLAYER_TOOLTIP_TARGET_OF_TARGET_SEARCH_DEPTH);
            
    -- Time delay between searches slider
    local timeDelaySliderOnValueChangedFunction = function(self, value)
                local formattedValue = string.format("%.2f", value);
                AggroNotifier_OptionsTimeDelayBetweenAggroSearchesSliderText:SetText(AGGRO_NOTIFIER_TIME_DELAY_BETWEEN_AGGRO_SEARCHES_OPTION_TEXT.." "..formattedValue);
            end;
    AggroNotifier_OptionsTimeDelayBetweenAggroSearchesSlider = AggroNotifier_CreateSlider(AggroNotifier_OptionsSubFrameBehavior, AggroNotifier_OptionsExtraTargetSearchDepthSlider, 0, -25, 
            AGGRO_NOTIFIER_TIME_DELAY_BETWEEN_AGGRO_SEARCHES_OPTION_TEXT, "0.0", "1.0", 0, 1.0, 0.05, timeDelaySliderOnValueChangedFunction, 
            "AggroNotifier_OptionsTimeDelayBetweenAggroSearchesSlider", AGGRO_NOTIFIER_PLAYER_TOOLTIP_TIME_DELAY_BETWEEN_AGGRO_SEARCHES);
end

-- Helper function for AggroNotifier_GenerateOptionsFrame() that generates the appearance (pet) options subframe
function AggroNotifier_GenerateOptionsSubframeAppearancePet()
    -- Create the pet appearance options subframe.
    AggroNotifier_PetOptionsSubFrameAppearance = CreateFrame("Frame", "AggroNotifier_PetOptionsSubFrameAppearance");
    AggroNotifier_PetOptionsSubFrameAppearance:SetScript("OnShow", 
        function()
            AggroNotifier_PopulateOptionsFrame();
            -- Due to some weird bug with the edit box, we need to force-set and force-insert the edit box text the first time this pane is explicitly loaded, otherwise the edit box will appear empty.
            if (not petAppearanceOptionsSubFrameLoaded) then
                petAppearanceOptionsSubFrameLoaded = true;
                AggroNotifier_PetOptionsAggroTextEditBox:SetText("");
                AggroNotifier_PetOptionsAggroTextEditBox:Insert(tostring(AggroNotifier_Config.desiredAggroTextPet));
                AggroNotifier_PetOptionsGenericAggroTextEditBox:SetText("");
                AggroNotifier_PetOptionsGenericAggroTextEditBox:Insert(tostring(AggroNotifier_Config.desiredGenericAggroTextPet));
            end
        end);
        
    -- Add the pet appearance option subframe widgets.
    -- Appearance frame title
    local optionsSubFrameAppearanceTitle = AggroNotifier_PetOptionsSubFrameAppearance:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
    optionsSubFrameAppearanceTitle:SetPoint("TOPLEFT", 16, -16);
    optionsSubFrameAppearanceTitle:SetText(AGGRO_NOTIFIER_OPTIONS_TITLE_APPEARANCE_PET);
    
    -- Desired aggro text box
    AggroNotifier_PetOptionsAggroTextEditBox = AggroNotifier_CreateTextEditBox(AggroNotifier_PetOptionsSubFrameAppearance, optionsSubFrameAppearanceTitle, 0, -10,
            AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_OPTION_TITLE_PET, AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_OPTION_DESCRIPTION_PET, "AggroNotifier_PetOptionsAggroTextEditBox", nil);
    
    -- Include PvP in enemy name checkbox
    AggroNotifier_PetOptionsIncludePvpInEnemyNameCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_PetOptionsSubFrameAppearance, AggroNotifier_PetOptionsAggroTextEditBox, 0, -3, 
            AGGRO_NOTIFIER_INCLUDE_PVP_TAG_OPTION_TEXT_PET, "AggroNotifier_PetOptionsIncludePvpInEnemyNameCheckbox", AGGRO_NOTIFIER_PET_TOOLTIP_INCLUDE_PVP_IN_ENEMY_NAME);
    
    -- Generic aggro text box
    AggroNotifier_PetOptionsGenericAggroTextEditBox = AggroNotifier_CreateTextEditBox(AggroNotifier_PetOptionsSubFrameAppearance, AggroNotifier_PetOptionsIncludePvpInEnemyNameCheckbox, -5, -7,
            AGGRO_NOTIFIER_GENERIC_AGGRO_TEXT_OPTION_TITLE_PET, AGGRO_NOTIFIER_GENERIC_AGGRO_TEXT_OPTION_DESCRIPTION_PET, "AggroNotifier_PetOptionsGenericAggroTextEditBox", nil);
    
    -- Show Anchor button
    local showAnchorOnClickFunction = function()
               AggroNotifier_SetAggroFrameDraggerToDesiredLocation(AggroNotifier_AggroFrameDraggerPet);
               AggroNotifier_SetAggroTextFrameToDraggerLocation(AggroNotifier_AggroFrameDraggerPet);
               AggroNotifier_AggroFrameDraggerPet:Show();
               AggroNotifier_RefreshAggroText(AggroNotifier_AggroTextPet, false, true);
            end;
    AggroNotifier_PetOptionsShowAggroTextAnchorButton = AggroNotifier_CreateButton(AggroNotifier_PetOptionsSubFrameAppearance, AggroNotifier_PetOptionsGenericAggroTextEditBox, 0, -10, 
            AGGRO_NOTIFIER_SHOW_ANCHOR_BUTTON_OPTION_TEXT_PET, showAnchorOnClickFunction, "AggroNotifier_PetOptionsShowAggroTextAnchorButton", nil);
    
    -- Reset Anchor button
    local resetAnchorOnClickFunction = function()
               AggroNotifier_SetAggroTextLocationConfigProperty(AggroNotifier_AggroFrameDraggerPet, configDefaultAggroTextLocationOffsetsPet[1], configDefaultAggroTextLocationOffsetsPet[2], 
                    configDefaultAggroTextLocationOffsetsPet[3], configDefaultAggroTextLocationOffsetsPet[4]);
               AggroNotifier_SetAggroFrameDraggerToDesiredLocation(AggroNotifier_AggroFrameDraggerPet);
               AggroNotifier_SetAggroTextFrameToDraggerLocation(AggroNotifier_AggroFrameDraggerPet);
               AggroNotifier_RefreshAggroText(AggroNotifier_AggroTextPet, false, true);
            end;
    AggroNotifier_PetOptionsResetAggroTextAnchorButton = AggroNotifier_CreateButton(AggroNotifier_PetOptionsSubFrameAppearance, AggroNotifier_PetOptionsShowAggroTextAnchorButton, 10, 0, 
            AGGRO_NOTIFIER_RESET_ANCHOR_BUTTON_OPTION_TEXT_PET, resetAnchorOnClickFunction, "AggroNotifier_PetOptionsResetAggroTextAnchorButton", nil);
    AggroNotifier_PetOptionsResetAggroTextAnchorButton:SetPoint("TOPLEFT", AggroNotifier_PetOptionsShowAggroTextAnchorButton, "TOPRIGHT", 10, 0);                
    
    -- Fade time slider
    local fadeTimeSliderOnValueChangedFunction = function(self, value)
                local valueInSeconds = value / 1000.0;
                AggroNotifier_PetOptionsFadeTimeSliderText:SetText(AGGRO_NOTIFIER_FADE_TIME_OPTION_TEXT_PET.." "..valueInSeconds);
            end;
    AggroNotifier_PetOptionsFadeTimeSlider = AggroNotifier_CreateSlider(AggroNotifier_PetOptionsSubFrameAppearance, AggroNotifier_PetOptionsShowAggroTextAnchorButton, 0, -20, 
            AGGRO_NOTIFIER_FADE_TIME_OPTION_TEXT_PET, "0.0", "10.0", 0, maxAllowedFadeTimeMilliseconds, 100, fadeTimeSliderOnValueChangedFunction, "AggroNotifier_PetOptionsFadeTimeSlider", 
            AGGRO_NOTIFIER_PET_TOOLTIP_AGGRO_TEXT_FADE_TIME);
        
    -- Gain Aggro color picker button
    AggroNotifier_PetOptionsGainAggroColorButton = AggroNotifier_CreateColorPickerButton(AggroNotifier_PetOptionsSubFrameAppearance, AggroNotifier_PetOptionsFadeTimeSlider, 
            0, -15, AGGRO_NOTIFIER_GAIN_AGGRO_COLOR_OPTION_TEXT_PET, "AggroNotifier_PetOptionsGainAggroColorButton", AGGRO_NOTIFIER_PET_TOOLTIP_GAIN_AGGRO_COLOR, AggroNotifier_AggroTextPet);
    
    -- Lose Aggro color picker button
    AggroNotifier_PetOptionsLoseAggroColorButton = AggroNotifier_CreateColorPickerButton(AggroNotifier_PetOptionsSubFrameAppearance, AggroNotifier_PetOptionsGainAggroColorButton, 
            0, -10, AGGRO_NOTIFIER_LOSE_AGGRO_COLOR_OPTION_TEXT_PET, "AggroNotifier_PetOptionsLoseAggroColorButton", AGGRO_NOTIFIER_PET_TOOLTIP_LOSE_AGGRO_COLOR, AggroNotifier_AggroTextPet);
    
    -- Desired font size
    local fontSizeSliderOnValueChangedFunction = function(self, value)
                AggroNotifier_PetOptionsFontSizeSliderText:SetText(AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_FONT_SIZE_OPTION_TITLE_PET.." "..value);
                if (allowPetAggroTextRefreshForFontSizeSlider) then
                    AggroNotifier_SetAggroFontHeight(AggroNotifier_AggroTextPet, value);
                    AggroNotifier_RefreshAggroText(AggroNotifier_AggroTextPet, false, true);
                end
            end;
    AggroNotifier_PetOptionsFontSizeSlider = AggroNotifier_CreateSlider(AggroNotifier_PetOptionsSubFrameAppearance, AggroNotifier_PetOptionsLoseAggroColorButton, 0, -20, 
            AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_FONT_SIZE_OPTION_TITLE_PET, "4", "60", 4, 60, 1, fontSizeSliderOnValueChangedFunction, "AggroNotifier_PetOptionsFontSizeSlider", 
            AGGRO_NOTIFIER_PET_TOOLTIP_AGGRO_TEXT_FONT_SIZE);
end

-- Helper function for AggroNotifier_GenerateOptionsFrame() that generates the behavior (pet) options subframe
function AggroNotifier_GenerateOptionsSubframeBehaviorPet()
    -- Create the pet behavior options subframe.
    AggroNotifier_PetOptionsSubFrameBehavior = CreateFrame("Frame", "AggroNotifier_PetOptionsSubFrameBehavior");
    AggroNotifier_PetOptionsSubFrameBehavior:SetScript("OnShow", AggroNotifier_PopulateOptionsFrame);
    
    -- Add the pet behavior option subframe widgets.
    -- Behavior frame title
    local optionsSubFrameBehaviorTitle = AggroNotifier_PetOptionsSubFrameBehavior:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
    optionsSubFrameBehaviorTitle:SetPoint("TOPLEFT", 16, -16);
    optionsSubFrameBehaviorTitle:SetText(AGGRO_NOTIFIER_OPTIONS_TITLE_BEHAVIOR_PET);
    
    -- Enabled checkbox
    AggroNotifier_PetOptionsAddonEnabledCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_PetOptionsSubFrameBehavior, optionsSubFrameBehaviorTitle, 0, -10, 
            AGGRO_NOTIFIER_ADDON_ENABLED_OPTION_TEXT_PET, "AggroNotifier_PetOptionsAddonEnabledCheckbox", AGGRO_NOTIFIER_PET_TOOLTIP_ENABLE_ADDON);
    AggroNotifier_PetOptionsAddonEnabledCheckbox:SetScript("OnClick", 
        function(self)
            local isChecked = AggroNotifier_ForceBoolean(AggroNotifier_PetOptionsAddonEnabledCheckbox:GetChecked());
            if (isChecked) then
                AggroNotifier_PetOptionsSoloEnabledForMobsCheckbox:Enable();
                AggroNotifier_PetOptionsSoloEnabledForPvpCheckbox:Enable();
            else
                AggroNotifier_PetOptionsSoloEnabledForMobsCheckbox:Disable();
                AggroNotifier_PetOptionsSoloEnabledForPvpCheckbox:Disable();
            end
        end);
    
    -- Enabled while soloing (mobs) checkbox
    AggroNotifier_PetOptionsSoloEnabledForMobsCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_PetOptionsSubFrameBehavior, AggroNotifier_PetOptionsAddonEnabledCheckbox, 20, 5, 
            AGGRO_NOTIFIER_ENABLED_SOLO_MOB_OPTION_TEXT_PET, "AggroNotifier_PetOptionsSoloEnabledForMobsCheckbox", AGGRO_NOTIFIER_PET_TOOLTIP_ENABLE_PVE_WHILE_SOLO);
    
    -- Enabled while soloing (pvp) checkbox
    AggroNotifier_PetOptionsSoloEnabledForPvpCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_PetOptionsSubFrameBehavior, AggroNotifier_PetOptionsSoloEnabledForMobsCheckbox, 0, 5, 
            AGGRO_NOTIFIER_ENABLED_SOLO_PVP_OPTION_TEXT_PET, "AggroNotifier_PetOptionsSoloEnabledForPvpCheckbox", AGGRO_NOTIFIER_PET_TOOLTIP_ENABLE_PVP_WHILE_SOLO);
    
    -- Disable AggroNotifier builtin visuals
    AggroNotifier_PetOptionsDisableBuiltinVisuals = AggroNotifier_CreateCheckbox(AggroNotifier_PetOptionsSubFrameBehavior, AggroNotifier_PetOptionsSoloEnabledForPvpCheckbox, -20, 5, 
            AGGRO_NOTIFIER_DISABLE_BUILTIN_VISUALS_OPTION_TEXT_PET, "AggroNotifier_PetOptionsDisableBuiltinVisuals", AGGRO_NOTIFIER_PET_TOOLTIP_DISABLE_BUILTIN_VISUALS);
    
    -- Disable mod integration
    AggroNotifier_PetOptionsDisableModIntegration = AggroNotifier_CreateCheckbox(AggroNotifier_PetOptionsSubFrameBehavior, AggroNotifier_PetOptionsDisableBuiltinVisuals, 0, 5, 
            AGGRO_NOTIFIER_DISABLE_MOD_INTEGRATION_PET_OPTION_TEXT, "AggroNotifier_PetOptionsDisableModIntegration", AGGRO_NOTIFIER_PET_TOOLTIP_DISABLE_MOD_INTEGRATION);
            
    -- Play sound on aggro gain checkbox
    AggroNotifier_PetOptionsPlaySoundCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_PetOptionsSubFrameBehavior, AggroNotifier_PetOptionsDisableModIntegration, 0, 5, 
            AGGRO_NOTIFIER_PLAY_SOUND_ON_AGGRO_GAIN_OPTION_TEXT_PET, "AggroNotifier_PetOptionsPlaySoundCheckbox", AGGRO_NOTIFIER_PET_TOOLTIP_PLAY_SOUND);
            
    -- Reload aggro text on each new aggro checkbox
    AggroNotifier_PetOptionsRefreshAggroTextCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_PetOptionsSubFrameBehavior, AggroNotifier_PetOptionsPlaySoundCheckbox, 0, -10, 
            AGGRO_NOTIFIER_REFRESH_AGGRO_TEXT_ON_EVERY_NEW_AGGRO_OPTION_TEXT_PET, "AggroNotifier_PetOptionsRefreshAggroTextCheckbox", AGGRO_NOTIFIER_PET_TOOLTIP_REFRESH_AGGRO_TEXT_EVERY_NEW_AGGRO);
    
    -- Always search for aggro checkbox
    AggroNotifier_PetOptionsAlwaysSearchForAggroCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_PetOptionsSubFrameBehavior, AggroNotifier_PetOptionsRefreshAggroTextCheckbox, 0, 5, 
            AGGRO_NOTIFIER_ALWAYS_SEARCH_FOR_AGGRO_OPTION_TEXT_PET, "AggroNotifier_PetOptionsAlwaysSearchForAggroCheckbox", AGGRO_NOTIFIER_PET_TOOLTIP_SEARCH_FOR_AGGRO_OUT_OF_COMBAT);
            
    -- Prevent notification fadeout on aggro gain checkbox
    AggroNotifier_PetOptionsPreventFadeoutCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_PetOptionsSubFrameBehavior, AggroNotifier_PetOptionsAlwaysSearchForAggroCheckbox, 0, 5, 
            AGGRO_NOTIFIER_PREVENT_FADEOUT_ON_AGGRO_GAIN_OPTION_TEXT_PET, "AggroNotifier_PetOptionsPreventFadeoutCheckbox", AGGRO_NOTIFIER_PET_TOOLTIP_PREVENT_FADEOUT);
            
    -- Extra target search depth slider
    local searchDepthSliderOnValueChangedFunction = function(self, value)
                AggroNotifier_PetOptionsExtraTargetSearchDepthSliderText:SetText(AGGRO_NOTIFIER_EXTRA_TARGET_SEARCH_DEPTH_OPTION_TEXT_PET.." "..value);
            end;
    AggroNotifier_PetOptionsExtraTargetSearchDepthSlider = AggroNotifier_CreateSlider(AggroNotifier_PetOptionsSubFrameBehavior, AggroNotifier_PetOptionsPreventFadeoutCheckbox, 0, -25, 
            AGGRO_NOTIFIER_EXTRA_TARGET_SEARCH_DEPTH_OPTION_TEXT_PET, "0", "2", 0, maxAllowedExtraTargetSearchDepth, 1, searchDepthSliderOnValueChangedFunction, 
            "AggroNotifier_PetOptionsExtraTargetSearchDepthSlider", AGGRO_NOTIFIER_PET_TOOLTIP_TARGET_OF_TARGET_SEARCH_DEPTH);
            
    -- Time delay between searches slider
    local timeDelaySliderOnValueChangedFunction = function(self, value)
                local formattedValue = string.format("%.2f", value);
                AggroNotifier_PetOptionsTimeDelayBetweenAggroSearchesSliderText:SetText(AGGRO_NOTIFIER_TIME_DELAY_BETWEEN_AGGRO_SEARCHES_OPTION_TEXT_PET.." "..formattedValue);
            end;
    AggroNotifier_PetOptionsTimeDelayBetweenAggroSearchesSlider = AggroNotifier_CreateSlider(AggroNotifier_PetOptionsSubFrameBehavior, AggroNotifier_PetOptionsExtraTargetSearchDepthSlider, 0, -25, 
            AGGRO_NOTIFIER_TIME_DELAY_BETWEEN_AGGRO_SEARCHES_OPTION_TEXT_PET, "0.0", "1.0", 0, 1.0, 0.05, timeDelaySliderOnValueChangedFunction, 
            "AggroNotifier_PetOptionsTimeDelayBetweenAggroSearchesSlider", AGGRO_NOTIFIER_PET_TOOLTIP_TIME_DELAY_BETWEEN_AGGRO_SEARCHES);
end

-- Helper function for AggroNotifier_GenerateOptionsFrame() that generates the other addon integration options subframe
function AggroNotifier_GenerateOptionsSubframeModIntegration()
    -- Create the mod integration options subframe.
    AggroNotifier_OtherModOptionsSubFrame = CreateFrame("Frame", "AggroNotifier_OtherModOptionsSubFrame");
    AggroNotifier_OtherModOptionsSubFrame:SetScript("OnShow", AggroNotifier_PopulateOptionsFrame);
    
    -- Add the mod integration option subframe widgets.
    -- SCT integration frame title
    local optionsSubFrameSctIntegrationTitle = AggroNotifier_OtherModOptionsSubFrame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
    optionsSubFrameSctIntegrationTitle:SetPoint("TOPLEFT", 16, -16);
    optionsSubFrameSctIntegrationTitle:SetText(AGGRO_NOTIFIER_OPTIONS_TITLE_INTEGRATE_WITH_SCT);
    
    -- Warning for if we can't find SCT.
    AggroNotifier_OtherModOptionsSctDisabledTitle = AggroNotifier_OtherModOptionsSubFrame:CreateFontString(nil, "ARTWORK", "GameFontNormal");
    AggroNotifier_OtherModOptionsSctDisabledTitle:SetPoint("TOPLEFT", optionsSubFrameSctIntegrationTitle, "BOTTOMLEFT", 0, -5);
    AggroNotifier_OtherModOptionsSctDisabledTitle:SetText(AGGRO_NOTIFIER_OPTIONS_SUBTITLE_CANNOT_FIND_SCT);
    AggroNotifier_OtherModOptionsSctDisabledTitle:SetVertexColor(1.00, 0.00, 0.00, 1.00);
        
    if (AggroNotifier_IsSctModAvailable()) then
        AggroNotifier_OtherModOptionsSctDisabledTitle:Hide();
    end
    
    -- SCT integration enabled checkbox
    AggroNotifier_OtherModOptionsIntegrateWithSctCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_OtherModOptionsSubFrame, AggroNotifier_OtherModOptionsSctDisabledTitle, 0, 0, 
            AGGRO_NOTIFIER_INTEGRATE_WITH_SCT_OPTION_TEXT, "AggroNotifier_OtherModOptionsIntegrateWithSctCheckbox", AGGRO_NOTIFIER_TOOLTIP_INTEGRATE_WITH_SCT);
    AggroNotifier_OtherModOptionsIntegrateWithSctCheckbox:SetScript("OnClick", 
        function(self)
            local isChecked = AggroNotifier_ForceBoolean(AggroNotifier_OtherModOptionsIntegrateWithSctCheckbox:GetChecked());
            if (isChecked) then
                AggroNotifier_OtherModOptionsSctShowAsCritCheckbox:Enable();
                UIDropDownMenu_EnableDropDown(AggroNotifier_OtherModOptionsSctFrameToOutputToDropDown);
                AggroNotifier_OtherModOptionsSctTestButton:Enable();
            else
                AggroNotifier_OtherModOptionsSctShowAsCritCheckbox:Disable();
                UIDropDownMenu_DisableDropDown(AggroNotifier_OtherModOptionsSctFrameToOutputToDropDown);
                AggroNotifier_OtherModOptionsSctTestButton:Disable();
            end
        end);
        
    -- Show SCT messages as crits checkbox
    AggroNotifier_OtherModOptionsSctShowAsCritCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_OtherModOptionsSubFrame, AggroNotifier_OtherModOptionsIntegrateWithSctCheckbox, 20, 5, 
            AGGRO_NOTIFIER_SHOW_SCT_AS_CRIT_OPTION_TEXT, "AggroNotifier_OtherModOptionsSctShowAsCritCheckbox", AGGRO_NOTIFIER_TOOLTIP_SHOW_SCT_AS_CRIT);
    
    -- SCT frame to output to dropdown
    local sctFrameOutputOptionsArray = {
        {1, "SCT Frame 1"},
        {2, "SCT Frame 2"},
        {0, "SCT Messages Frame"}
    };
    AggroNotifier_OtherModOptionsSctFrameToOutputToDropDown = AggroNotifier_CreateDropDown(AggroNotifier_OtherModOptionsSubFrame, AggroNotifier_OtherModOptionsSctShowAsCritCheckbox, 
            0, -5, AGGRO_NOTIFIER_SCT_FRAME_TO_USE_OPTION_TEXT, sctFrameOutputOptionsArray, AggroNotifier_Config.sctFrameToOutputTo, 140,
            nil, "AggroNotifier_OtherModOptionsSctFrameToOutputToDropDown", AGGRO_NOTIFIER_TOOLTIP_SCT_FRAME_TO_USE);

    -- Test SCT integration button
    local sctTestButtonOnClickFunction = function()
                AggroNotifier_SendMessageToSct(AggroNotifier_AggroText, 
                    AggroNotifier_ForceBoolean(AggroNotifier_OtherModOptionsSctShowAsCritCheckbox:GetChecked()), 
                    UIDropDownMenu_GetSelectedValue(AggroNotifier_OtherModOptionsSctFrameToOutputToDropDown),
                    true);
            end;
    AggroNotifier_OtherModOptionsSctTestButton = AggroNotifier_CreateButton(AggroNotifier_OtherModOptionsSubFrame, AggroNotifier_OtherModOptionsSctFrameToOutputToDropDown, 0, -5, 
            AGGRO_NOTIFIER_SCT_TEST_BUTTON_TEXT, sctTestButtonOnClickFunction, "AggroNotifier_OtherModOptionsSctTestButton", nil);

    -- Mik integration frame title
    local optionsSubFrameMikIntegrationTitle = AggroNotifier_OtherModOptionsSubFrame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
    optionsSubFrameMikIntegrationTitle:SetPoint("TOPLEFT", AggroNotifier_OtherModOptionsSctTestButton, "BOTTOMLEFT", 0, -20);
    optionsSubFrameMikIntegrationTitle:SetText(AGGRO_NOTIFIER_OPTIONS_TITLE_INTEGRATE_WITH_MIK);
    
    -- Warning for if we can't find Mik or if it's disabled.
    AggroNotifier_OtherModOptionsMikDisabledTitle = AggroNotifier_OtherModOptionsSubFrame:CreateFontString(nil, "ARTWORK", "GameFontNormal");
    AggroNotifier_OtherModOptionsMikDisabledTitle:SetPoint("TOPLEFT", optionsSubFrameMikIntegrationTitle, "BOTTOMLEFT", 0, -5);
    AggroNotifier_OtherModOptionsMikDisabledTitle:SetText(AGGRO_NOTIFIER_OPTIONS_SUBTITLE_CANNOT_FIND_MIK);
    AggroNotifier_OtherModOptionsMikDisabledTitle:SetVertexColor(1.00, 0.00, 0.00, 1.00);
        
    if (AggroNotifier_IsMikModAvailable()) then
        AggroNotifier_OtherModOptionsMikDisabledTitle:Hide();
    end
    
    -- Mik integration enabled checkbox
    AggroNotifier_OtherModOptionsIntegrateWithMikCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_OtherModOptionsSubFrame, AggroNotifier_OtherModOptionsMikDisabledTitle, 0, 0, 
            AGGRO_NOTIFIER_INTEGRATE_WITH_MIK_OPTION_TEXT, "AggroNotifier_OtherModOptionsIntegrateWithMikCheckbox", AGGRO_NOTIFIER_TOOLTIP_INTEGRATE_WITH_MIK);
    AggroNotifier_OtherModOptionsIntegrateWithMikCheckbox:SetScript("OnClick", 
        function(self)
            local isChecked = AggroNotifier_ForceBoolean(AggroNotifier_OtherModOptionsIntegrateWithMikCheckbox:GetChecked());
            if (isChecked) then
                AggroNotifier_OtherModOptionsMikShowAsStickyCheckbox:Enable();
                AggroNotifier_OtherModOptionsMikUseAggroNotifierFontSizeCheckbox:Enable();
                UIDropDownMenu_EnableDropDown(AggroNotifier_OtherModOptionsMikFrameToOutputToDropDown);
                AggroNotifier_OtherModOptionsMikTestButton:Enable();
            else
                AggroNotifier_OtherModOptionsMikShowAsStickyCheckbox:Disable();
                AggroNotifier_OtherModOptionsMikUseAggroNotifierFontSizeCheckbox:Disable();
                UIDropDownMenu_DisableDropDown(AggroNotifier_OtherModOptionsMikFrameToOutputToDropDown);
                AggroNotifier_OtherModOptionsMikTestButton:Disable();
            end
        end);
    
    -- Show Mik messages as sticky checkbox
    AggroNotifier_OtherModOptionsMikShowAsStickyCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_OtherModOptionsSubFrame, AggroNotifier_OtherModOptionsIntegrateWithMikCheckbox, 20, 5, 
            AGGRO_NOTIFIER_SHOW_MIK_AS_STICKY_OPTION_TEXT, "AggroNotifier_OtherModOptionsMikShowAsStickyCheckbox", AGGRO_NOTIFIER_TOOLTIP_SHOW_MIK_AS_STICKY);
            
    -- Use AggroNotifier font size checkbox
    AggroNotifier_OtherModOptionsMikUseAggroNotifierFontSizeCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_OtherModOptionsSubFrame, AggroNotifier_OtherModOptionsMikShowAsStickyCheckbox, 0, 5, 
            AGGRO_NOTIFIER_USE_AGGRO_NOTIFIER_FONT_SIZE_MIK, "AggroNotifier_OtherModOptionsMikUseAggroNotifierFontSizeCheckbox", AGGRO_NOTIFIER_TOOLTIP_USE_AGGRO_NOTIFIER_FONT_SIZE_MIK);
            
    -- Mik frame to output to dropdown
    local currentMikFrameToOutputTo = AggroNotifier_Config.mikFrameToOutputTo;
    local mikFrameOutputOptionsArray = {
        {currentMikFrameToOutputTo, currentMikFrameToOutputTo}
    };
    local i = 0;
    if (MikSBT ~= nil and MikSBT.IterateScrollAreas ~= nil) then
        for scrollAreaKey, scrollAreaName in MikSBT.IterateScrollAreas() do
            i = i + 1;   
            mikFrameOutputOptionsArray[i] = {scrollAreaKey, scrollAreaName};
        end
    end
    local dropDownWidth = 140;
    if (i >= 5) then
       dropDownWidth = 180;
    end
    AggroNotifier_OtherModOptionsMikFrameToOutputToDropDown = AggroNotifier_CreateDropDown(AggroNotifier_OtherModOptionsSubFrame, AggroNotifier_OtherModOptionsMikUseAggroNotifierFontSizeCheckbox, 
            0, -5, AGGRO_NOTIFIER_MIK_FRAME_TO_USE_OPTION_TEXT, mikFrameOutputOptionsArray, currentMikFrameToOutputTo, dropDownWidth,
            nil, "AggroNotifier_OtherModOptionsMikFrameToOutputToDropDown", AGGRO_NOTIFIER_TOOLTIP_MIK_FRAME_TO_USE);
            
    -- Test Mik integration button
    local mikTestButtonOnClickFunction = function()
                AggroNotifier_SendMessageToMik(AggroNotifier_AggroText, 
                    AggroNotifier_ForceBoolean(AggroNotifier_OtherModOptionsMikShowAsStickyCheckbox:GetChecked()), 
                    AggroNotifier_ForceBoolean(AggroNotifier_OtherModOptionsMikUseAggroNotifierFontSizeCheckbox:GetChecked()), 
                    UIDropDownMenu_GetSelectedValue(AggroNotifier_OtherModOptionsMikFrameToOutputToDropDown),
                    true);
            end;
    AggroNotifier_OtherModOptionsMikTestButton = AggroNotifier_CreateButton(AggroNotifier_OtherModOptionsSubFrame, AggroNotifier_OtherModOptionsMikFrameToOutputToDropDown, 0, -5, 
            AGGRO_NOTIFIER_MIK_TEST_BUTTON_TEXT, mikTestButtonOnClickFunction, "AggroNotifier_OtherModOptionsMikTestButton", nil);
end

-- Helper function that creates and returns a text edit box widget based on the given arguments.
function AggroNotifier_CreateTextEditBox(ownerFrame, relativeLocationObject, xOffset, yOffset, titleString, descriptionString, editBoxObjectName, tooltipTextString)
    local titleObject = ownerFrame:CreateFontString(nil, "ARTWORK", "GameFontNormal");
    titleObject:SetPoint("TOPLEFT", relativeLocationObject, "BOTTOMLEFT", xOffset, yOffset);
    titleObject:SetText(titleString);
    local descriptionObject = ownerFrame:CreateFontString(nil, "ARTWORK", "GameFontRedSmall");
    descriptionObject:SetTextColor(1.0, 1.0, 1.0);
    descriptionObject:SetPoint("TOPLEFT", titleObject, "BOTTOMLEFT", 0, -2);
    descriptionObject:SetWidth(360);
    descriptionObject:SetJustifyH("LEFT");
    descriptionObject:SetText(descriptionString);
    
    local editBoxObject = CreateFrame("EditBox", editBoxObjectName, ownerFrame, "InputBoxTemplate");
    editBoxObject:SetWidth(250);
    editBoxObject:SetHeight(16);
    editBoxObject:SetPoint("TOPLEFT", descriptionObject, "BOTTOMLEFT", 5, -7);
    editBoxObject:SetFontObject("GameFontWhite");
    editBoxObject:SetAutoFocus(false);
    
    if (tooltipTextString ~= nil) then
        AggroNotifier_AttachTooltip(editBoxObject, tooltipTextString);
    end
    
    return editBoxObject;
end

-- Helper function that creates and returns a checkbox widget based on the given arguments.
function AggroNotifier_CreateCheckbox(ownerFrame, relativeLocationObject, xOffset, yOffset, titleString, checkboxObjectName, tooltipTextString)
    local checkboxObject = CreateFrame("CheckButton", checkboxObjectName, ownerFrame, "OptionsCheckButtonTemplate");
    checkboxObject:SetPoint("TOPLEFT", relativeLocationObject, "BOTTOMLEFT", xOffset, yOffset);
    local checkboxTextObject = getglobal(checkboxObject:GetName().."Text");
    checkboxTextObject:SetFontObject("GameFontNormal");
    checkboxTextObject:SetText(titleString);
    if (tooltipTextString ~= nil) then
        AggroNotifier_AttachTooltip(checkboxObject, tooltipTextString);
    end
    return checkboxObject;
end

-- Helper function that creates and returns a button widget based on the given arguments.
function AggroNotifier_CreateButton(ownerFrame, relativeLocationObject, xOffset, yOffset, buttonTextString, onClickFunction, buttonObjectName, tooltipTextString)
    local buttonObject = CreateFrame("Button", buttonObjectName, ownerFrame, "UIPanelButtonTemplate");
    buttonObject:SetHeight(22);
    buttonObject:SetPoint("TOPLEFT", relativeLocationObject, "BOTTOMLEFT", xOffset, yOffset);
    buttonObject:SetText(buttonTextString);
    buttonObject:SetWidth(buttonObject:GetTextWidth() + 30);
    buttonObject:SetScript("OnClick", onClickFunction);
    
    if (tooltipTextString ~= nil) then
        AggroNotifier_AttachTooltip(buttonObject, tooltipTextString);
    end
    
    return buttonObject;
end

-- Helper function that creates and returns a slider widget based on the given arguments.
function AggroNotifier_CreateSlider(ownerFrame, relativeLocationObject, xOffset, yOffset, sliderTextString, minValueText, maxValueText, minValue, maxValue, stepValue, 
            onValueChangedFunction, sliderObjectName, tooltipTextString)
    local sliderObject = CreateFrame("Slider", sliderObjectName, ownerFrame, "OptionsSliderTemplate");
    sliderObject:SetWidth(335);
    sliderObject:SetHeight(16);
    sliderObject:SetPoint("TOPLEFT", relativeLocationObject, "BOTTOMLEFT", xOffset, yOffset);
    local sliderTextObject = getglobal(sliderObject:GetName().."Text");
    sliderTextObject:SetFontObject("GameFontNormal");
    sliderTextObject:SetText(sliderTextString);
    local sliderLowObject = getglobal(sliderObject:GetName().."Low");
    sliderLowObject:SetText(minValueText);
    local sliderHighObject = getglobal(sliderObject:GetName().."High");
    sliderHighObject:SetText(maxValueText);
    sliderObject:SetMinMaxValues(minValue, maxValue);
    sliderObject:SetValueStep(stepValue);
    sliderObject:SetScript("OnValueChanged", onValueChangedFunction);
        
    if (tooltipTextString ~= nil) then
        AggroNotifier_AttachTooltip(sliderObject, tooltipTextString);
    end
        
    return sliderObject;
end

-- Helper function that creates and returns a drop-down widget based on the given arguments.
function AggroNotifier_CreateDropDown(ownerFrame, relativeLocationObject, xOffset, yOffset, dropDownLabel, dropDownOptionsArray, defaultValue, 
            dropDownWidth, onValueChangedFunction, dropDownObjectName, tooltipTextString)
    -- Create the drop down widget and a label/title element to go along with it.
    local dropDownObject = CreateFrame("Frame", dropDownObjectName, ownerFrame, "UIDropDownMenuTemplate");
    local dropDownTitle = dropDownObject:CreateFontString(nil, "ARTWORK", "GameFontNormal");
    dropDownTitle:SetText(dropDownLabel);

    dropDownTitle:SetPoint("TOPLEFT", relativeLocationObject, "BOTTOMLEFT", xOffset, yOffset);    
    dropDownObject:SetPoint("TOPLEFT", dropDownTitle, "BOTTOMLEFT", -20, -5);
    
    dropDownObject.titleFrame = dropDownTitle;
    
    local dropDownItemInitializerFunction = function()
        level = 1; -- Drop down menus can have sub menus. The value of "level" determines the drop down sub menu tier. Our drop downs will always be 1-leveled.
 
        -- Run through each item in the drop down options array and add it to the drop down.
        for i, dropDownOptionPair in ipairs(dropDownOptionsArray) do
            local optionValue = dropDownOptionPair[1];
            local optionText = dropDownOptionPair[2];

            local info = UIDropDownMenu_CreateInfo();
            
            info.text = optionText; --The text of the menu item.
            info.value = optionValue; -- The value of the menu item.
            info.func = function()
                UIDropDownMenu_SetSelectedValue(this.owner, this.value);
                
                if (onValueChangedFunction ~= nil) then
                    onValueChangedFunction(this, this.value);
                end
            end
                        
            info.owner = this:GetParent(); -- Binds the drop down menu as the parent of the menu item. This is very important for dynamic drop down menus.
            info.checked = nil;
            info.icon = nil; -- We can use this to set an icon for the drop down menu item to accompany the text.
            UIDropDownMenu_AddButton(info, level); --Adds the new button to the drop down menu specified in the UIDropDownMenu_Initialise function. In this case, it's MyDropDownMenu
        end
    end
    
    UIDropDownMenu_SetWidth(dropDownObject, dropDownWidth);
    UIDropDownMenu_SetButtonWidth(dropDownObject, dropDownWidth);
    UIDropDownMenu_Initialize(dropDownObject, dropDownItemInitializerFunction);
    if (defaultValue ~= nil) then
        UIDropDownMenu_SetSelectedValue(dropDownObject, defaultValue, false);
    end
        
    if (tooltipTextString ~= nil) then
        AggroNotifier_AttachTooltip(getglobal(dropDownObject:GetName().."Button"), tooltipTextString);
    end
        
    return dropDownObject;
end

-- Helper function that creates and returns a color picker widget based on the given arguments.
function AggroNotifier_CreateColorPickerButton(ownerFrame, relativeLocationObject, xOffset, yOffset, colorPickerTitleString, colorPickerObjectName, tooltipTextString, refreshAggroTextObject)
    local colorPickerObject = CreateFrame("Button", colorPickerObjectName, ownerFrame);
    colorPickerObject:SetPoint("TOPLEFT", relativeLocationObject, "BOTTOMLEFT", xOffset, yOffset);
    
    colorPickerObject:SetWidth(20);
    colorPickerObject:SetHeight(20);

    colorPickerObject.texture = colorPickerObject:CreateTexture();
    colorPickerObject.texture:SetPoint("TOPLEFT", 0, 0);
    colorPickerObject.texture:SetPoint("BOTTOMRIGHT", 0, 0);
    colorPickerObject.texture:SetTexture("Interface\\ChatFrame\\ChatFrameColorSwatch");
    colorPickerObject:SetNormalTexture(colorPickerObject.texture);

    colorPickerObject.borderTop = colorPickerObject:CreateTexture(nil,"BACKGROUND");
    colorPickerObject.borderTop:SetPoint("TOPLEFT", 1, -1);
    colorPickerObject.borderTop:SetPoint("TOPRIGHT", -1, -1);
    colorPickerObject.borderTop:SetHeight(2);
    colorPickerObject.borderTop:SetTexture(1.00, 1.00, 1.00, 1.00);
    colorPickerObject.borderRight = colorPickerObject:CreateTexture(nil,"BACKGROUND");
    colorPickerObject.borderRight:SetPoint("TOPRIGHT", -1, -1);
    colorPickerObject.borderRight:SetPoint("BOTTOMRIGHT", -1, 1);
    colorPickerObject.borderRight:SetWidth(2);
    colorPickerObject.borderRight:SetTexture(1.00, 1.00, 1.00, 1.00);
    colorPickerObject.borderBottom = colorPickerObject:CreateTexture(nil,"BACKGROUND");
    colorPickerObject.borderBottom:SetPoint("BOTTOMLEFT", 1, 1);
    colorPickerObject.borderBottom:SetPoint("BOTTOMRIGHT", -1, 1);
    colorPickerObject.borderBottom:SetHeight(2);
    colorPickerObject.borderBottom:SetTexture(1.00, 1.00, 1.00, 1.00);
    colorPickerObject.borderLeft = colorPickerObject:CreateTexture(nil,"BACKGROUND");
    colorPickerObject.borderLeft:SetPoint("TOPLEFT", 1, -1);
    colorPickerObject.borderLeft:SetPoint("BOTTOMLEFT", 1, 1);
    colorPickerObject.borderLeft:SetWidth(2);
    colorPickerObject.borderLeft:SetTexture(1.00, 1.00, 1.00, 1.00);

    colorPickerObject.text = colorPickerObject:CreateFontString(nil,"ARTWORK","GameFontNormal");
    colorPickerObject.text:SetPoint("LEFT", colorPickerObject, "RIGHT", 5, 0);
    colorPickerObject.text:SetText(colorPickerTitleString);

    colorPickerObject.refreshAggroTextObject = refreshAggroTextObject;
    
    local colorPickerOnClickFunction = function(previousValue,...)
                local r, g, b, a;
                if (previousValue) then
                    -- The player hit cancel. Reset the button's color to its previous values.
                    r, g, b, a  = unpack(previousValue);
                else
                    -- The player hit ok. We want to update the button to the new color values from the color picker.
                    r, g, b = ColorPickerFrame:GetColorRGB();
                    a = (1 - OpacitySliderFrame:GetValue());
                end
            
                ColorPickerFrame.frame.texture:SetVertexColor(r, g, b, a);
                
                -- Refresh the aggro text object this color picker is associated with if applicable.
                if (ColorPickerFrame.frame.refreshAggroTextObject ~= nil) then
                     ColorPickerFrame.frame.refreshAggroTextObject.runtimeInfo.temporaryColorOverride = {r, g, b, a};
                     AggroNotifier_RefreshAggroText(ColorPickerFrame.frame.refreshAggroTextObject, false, true);
                end
            end
    
    colorPickerObject:SetScript("OnClick",
        function(self, button)
            local r, g, b, a = self.texture:GetVertexColor();
            
            ColorPickerFrame.frame = self;
            ColorPickerFrame.func = colorPickerOnClickFunction;
            ColorPickerFrame.cancelFunc = colorPickerOnClickFunction;
            ColorPickerFrame.opacityFunc = colorPickerOnClickFunction;
            ColorPickerFrame.hasOpacity = true;
            ColorPickerFrame.opacity = (1 - a);
            ColorPickerFrame.previousValues = { r, g, b, a };
        
            OpacitySliderFrame:SetValue(1 - a);
            ColorPickerFrame:SetColorRGB(r, g, b);
            ColorPickerFrame:Show();
        end);
    colorPickerObject:SetScript("OnEnter",
        function(self)
            self.borderTop:SetTexture(1.00, 0.82, 0.00, 1.00);
            self.borderRight:SetTexture(1.00, 0.82, 0.00, 1.00);
            self.borderBottom:SetTexture(1.00, 0.82, 0.00, 1.00);
            self.borderLeft:SetTexture(1.00, 0.82, 0.00, 1.00);
        end);
    colorPickerObject:SetScript("OnLeave",
        function(self)
            self.borderTop:SetTexture(1.00, 1.00, 1.00, 1.00);
            self.borderRight:SetTexture(1.00, 1.00, 1.00, 1.00);
            self.borderBottom:SetTexture(1.00, 1.00, 1.00, 1.00);
            self.borderLeft:SetTexture(1.00, 1.00, 1.00, 1.00);
        end);
    
    if (tooltipTextString ~= nil) then
        AggroNotifier_AttachTooltip(colorPickerObject, tooltipTextString);
    end
    
    return colorPickerObject;
end

-- Helper function that attaches the given tooltip text to the given owning widget object. The tooltip will be shown when the widget is moused over.
function AggroNotifier_AttachTooltip(owningObject, tooltipTextString)
    -- Set the tooltip text on the owning object so it can be accessed by the scripts.
    owningObject.tooltipText = tooltipTextString;
    -- Set scripts on the owning object to show/hide the tooltip as necessary.
    owningObject:SetScript("OnEnter",
        function()
            GameTooltip:SetOwner(owningObject, "ANCHOR_TOPLEFT");
            GameTooltip:SetText(this.tooltipText, 1, .82, 0, 1, true);
            GameTooltip:Show();
        end);
    owningObject:SetScript("OnLeave",
        function()
            GameTooltip:Hide();
        end);
end

-- This function is called when the options frame is shown. It loads all the options widgets with the current config property values.
function AggroNotifier_PopulateOptionsFrame()
    -- We don't want to reset the option values when we switch between option subpanes, so only set the values if we're just coming in for the first time.
    if (not optionsFrameActive) then
        optionsFrameActive = true;
        
        -- Set the options frames' widgets to have the current values stored in the config file.
        
        -- PLAYER OPTIONS
        -- Edit boxes are funky and sometimes need a little extra prodding to get populated correctly. We'll set it to blank and then insert the text we want.
        AggroNotifier_OptionsAggroTextEditBox:SetText("");
        AggroNotifier_OptionsAggroTextEditBox:Insert(tostring(AggroNotifier_Config.desiredAggroText));
        AggroNotifier_OptionsGenericAggroTextEditBox:SetText("");
        AggroNotifier_OptionsGenericAggroTextEditBox:Insert(tostring(AggroNotifier_Config.desiredGenericAggroText));
        AggroNotifier_OptionsIncludePvpInEnemyNameCheckbox:SetChecked(AggroNotifier_Config.desiredIncludePvpTagInEnemyName);
        AggroNotifier_OptionsFadeTimeSlider:SetValue(AggroNotifier_Config.desiredFadeTimeMilliseconds);
        local r, g, b, a = unpack(AggroNotifier_Config.gainAggroColor);
        AggroNotifier_OptionsGainAggroColorButton.texture:SetVertexColor(r, g, b, a);
        r, g, b, a = unpack(AggroNotifier_Config.loseAggroColor);
        AggroNotifier_OptionsLoseAggroColorButton.texture:SetVertexColor(r, g, b, a);
        -- Normally when the font size slider has its value set it is supposed to refresh the aggro text, but we don't want it to do that when we're initially 
        -- populating the value (only when a user is fiddling with it), hence the use of the allowAggroTextRefreshForFontSizeSlider variable.
        allowAggroTextRefreshForFontSizeSlider = false;
        AggroNotifier_OptionsFontSizeSlider:SetValue(AggroNotifier_Config.desiredAggroTextFontSize);
        allowAggroTextRefreshForFontSizeSlider = true;
        
        AggroNotifier_OptionsRefreshAggroTextCheckbox:SetChecked(AggroNotifier_Config.desiredRefreshAggroTextOnEveryNewAggro);
        AggroNotifier_OptionsAlwaysSearchForAggroCheckbox:SetChecked(AggroNotifier_Config.desiredAlwaysSearchForAggro);
        AggroNotifier_OptionsExtraTargetSearchDepthSlider:SetValue(AggroNotifier_Config.desiredExtraTargetSearchDepth);
        AggroNotifier_OptionsTimeDelayBetweenAggroSearchesSlider:SetValue(AggroNotifier_Config.timeDelayBetweenAggroSearches);
        AggroNotifier_OptionsAddonEnabledCheckbox:SetChecked(AggroNotifier_Config.addonEnabled);
        AggroNotifier_OptionsSoloEnabledForMobsCheckbox:SetChecked(AggroNotifier_Config.soloEnabledForMobs);
        AggroNotifier_OptionsSoloEnabledForPvpCheckbox:SetChecked(AggroNotifier_Config.soloEnabledForPvp);
        AggroNotifier_OptionsDisableBuiltinVisuals:SetChecked(AggroNotifier_Config.disableBuiltinVisuals);
        AggroNotifier_OptionsDisableModIntegration:SetChecked(AggroNotifier_Config.disableModIntegrationPlayer);
        AggroNotifier_OptionsPlaySoundCheckbox:SetChecked(AggroNotifier_Config.playSoundOnAggroGain);
        AggroNotifier_OptionsPreventFadeoutCheckbox:SetChecked(AggroNotifier_Config.preventFadeoutOnAggroGain);
        
        -- Enable or disable the solo options depending on whether the addon as a whole is enabled.
        if (AggroNotifier_Config.addonEnabled) then
            AggroNotifier_OptionsSoloEnabledForMobsCheckbox:Enable();
            AggroNotifier_OptionsSoloEnabledForPvpCheckbox:Enable();
        else
            AggroNotifier_OptionsSoloEnabledForMobsCheckbox:Disable();
            AggroNotifier_OptionsSoloEnabledForPvpCheckbox:Disable();
        end
        
        -- PET OPTIONS
        -- Edit boxes are funky and sometimes need a little extra prodding to get populated correctly. We'll set it to blank and then insert the text we want.
        AggroNotifier_PetOptionsAggroTextEditBox:SetText("");
        AggroNotifier_PetOptionsAggroTextEditBox:Insert(tostring(AggroNotifier_Config.desiredAggroTextPet));
        AggroNotifier_PetOptionsGenericAggroTextEditBox:SetText("");
        AggroNotifier_PetOptionsGenericAggroTextEditBox:Insert(tostring(AggroNotifier_Config.desiredGenericAggroTextPet));
        AggroNotifier_PetOptionsIncludePvpInEnemyNameCheckbox:SetChecked(AggroNotifier_Config.desiredIncludePvpTagInEnemyNamePet);
        AggroNotifier_PetOptionsFadeTimeSlider:SetValue(AggroNotifier_Config.desiredFadeTimeMillisecondsPet);
        local r, g, b, a = unpack(AggroNotifier_Config.gainAggroColorPet);
        AggroNotifier_PetOptionsGainAggroColorButton.texture:SetVertexColor(r, g, b, a);
        r, g, b, a = unpack(AggroNotifier_Config.loseAggroColorPet);
        AggroNotifier_PetOptionsLoseAggroColorButton.texture:SetVertexColor(r, g, b, a);
        -- Normally when the font size slider has its value set it is supposed to refresh the aggro text, but we don't want it to do that when we're initially 
        -- populating the value (only when a user is fiddling with it), hence the use of the allowPetAggroTextRefreshForFontSizeSlider variable.
        allowPetAggroTextRefreshForFontSizeSlider = false;
        AggroNotifier_PetOptionsFontSizeSlider:SetValue(AggroNotifier_Config.desiredAggroTextFontSizePet);
        allowPetAggroTextRefreshForFontSizeSlider = true;
        
        AggroNotifier_PetOptionsRefreshAggroTextCheckbox:SetChecked(AggroNotifier_Config.desiredRefreshAggroTextOnEveryNewAggroPet);
        AggroNotifier_PetOptionsAlwaysSearchForAggroCheckbox:SetChecked(AggroNotifier_Config.desiredAlwaysSearchForAggroPet);
        AggroNotifier_PetOptionsExtraTargetSearchDepthSlider:SetValue(AggroNotifier_Config.desiredExtraTargetSearchDepthPet);
        AggroNotifier_PetOptionsTimeDelayBetweenAggroSearchesSlider:SetValue(AggroNotifier_Config.timeDelayBetweenAggroSearchesPet);
        AggroNotifier_PetOptionsAddonEnabledCheckbox:SetChecked(AggroNotifier_Config.addonEnabledPet);
        AggroNotifier_PetOptionsSoloEnabledForMobsCheckbox:SetChecked(AggroNotifier_Config.soloEnabledForMobsPet);
        AggroNotifier_PetOptionsSoloEnabledForPvpCheckbox:SetChecked(AggroNotifier_Config.soloEnabledForPvpPet);
        AggroNotifier_PetOptionsDisableBuiltinVisuals:SetChecked(AggroNotifier_Config.disableBuiltinVisualsPet);
        AggroNotifier_PetOptionsDisableModIntegration:SetChecked(AggroNotifier_Config.disableModIntegrationPet);
        AggroNotifier_PetOptionsPlaySoundCheckbox:SetChecked(AggroNotifier_Config.playSoundOnAggroGainPet);
        AggroNotifier_PetOptionsPreventFadeoutCheckbox:SetChecked(AggroNotifier_Config.preventFadeoutOnAggroGainPet);
        
        -- Enable or disable the solo options depending on whether the addon as a whole is enabled.
        if (AggroNotifier_Config.addonEnabledPet) then
            AggroNotifier_PetOptionsSoloEnabledForMobsCheckbox:Enable();
            AggroNotifier_PetOptionsSoloEnabledForPvpCheckbox:Enable();
        else
            AggroNotifier_PetOptionsSoloEnabledForMobsCheckbox:Disable();
            AggroNotifier_PetOptionsSoloEnabledForPvpCheckbox:Disable();
        end
        
        -- ADDON INTEGRATION OPTIONS
        -- SCT
        AggroNotifier_OtherModOptionsIntegrateWithSctCheckbox:SetChecked(AggroNotifier_Config.integrateWithSct);
        AggroNotifier_OtherModOptionsSctShowAsCritCheckbox:SetChecked(AggroNotifier_Config.sctShowAsCrit);
        UIDropDownMenu_SetSelectedValue(AggroNotifier_OtherModOptionsSctFrameToOutputToDropDown, AggroNotifier_Config.sctFrameToOutputTo, false);
        
        -- Enable or disable the SCT options depending on whether SCT integration is enabled and available.
        if (AggroNotifier_IsSctModAvailable()) then
            AggroNotifier_OtherModOptionsSctDisabledTitle:Hide();
            AggroNotifier_OtherModOptionsIntegrateWithSctCheckbox:Enable();
        else
            AggroNotifier_OtherModOptionsSctDisabledTitle:Show();
            AggroNotifier_OtherModOptionsIntegrateWithSctCheckbox:Disable();
        end
        
        if (AggroNotifier_Config.integrateWithSct and AggroNotifier_IsSctModAvailable()) then
            AggroNotifier_OtherModOptionsSctShowAsCritCheckbox:Enable();
            UIDropDownMenu_EnableDropDown(AggroNotifier_OtherModOptionsSctFrameToOutputToDropDown);
            AggroNotifier_OtherModOptionsSctTestButton:Enable();
        else
            AggroNotifier_OtherModOptionsSctShowAsCritCheckbox:Disable();
            UIDropDownMenu_DisableDropDown(AggroNotifier_OtherModOptionsSctFrameToOutputToDropDown);
            AggroNotifier_OtherModOptionsSctTestButton:Disable();
        end
        
        -- MikSBT
        AggroNotifier_OtherModOptionsIntegrateWithMikCheckbox:SetChecked(AggroNotifier_Config.integrateWithMik);
        AggroNotifier_OtherModOptionsMikShowAsStickyCheckbox:SetChecked(AggroNotifier_Config.mikShowAsSticky);
        AggroNotifier_OtherModOptionsMikUseAggroNotifierFontSizeCheckbox:SetChecked(AggroNotifier_Config.mikUseAggroNotifierFontSize);
        UIDropDownMenu_SetSelectedValue(AggroNotifier_OtherModOptionsMikFrameToOutputToDropDown, AggroNotifier_Config.mikFrameToOutputTo, false);
        
        -- Enable or disable the Mik options depending on whether Mik integration is enabled and available.
        if (AggroNotifier_IsMikModAvailable()) then
            AggroNotifier_OtherModOptionsMikDisabledTitle:Hide();
            AggroNotifier_OtherModOptionsIntegrateWithMikCheckbox:Enable();
        else
            AggroNotifier_OtherModOptionsMikDisabledTitle:Show();
            AggroNotifier_OtherModOptionsIntegrateWithMikCheckbox:Disable();
        end
        
        if (AggroNotifier_Config.integrateWithMik and AggroNotifier_IsMikModAvailable()) then
            AggroNotifier_OtherModOptionsMikShowAsStickyCheckbox:Enable();
            AggroNotifier_OtherModOptionsMikUseAggroNotifierFontSizeCheckbox:Enable();
            UIDropDownMenu_EnableDropDown(AggroNotifier_OtherModOptionsMikFrameToOutputToDropDown);
            AggroNotifier_OtherModOptionsMikTestButton:Enable();
        else
            AggroNotifier_OtherModOptionsMikShowAsStickyCheckbox:Disable();
            AggroNotifier_OtherModOptionsMikUseAggroNotifierFontSizeCheckbox:Disable();
            UIDropDownMenu_DisableDropDown(AggroNotifier_OtherModOptionsMikFrameToOutputToDropDown);
            AggroNotifier_OtherModOptionsMikTestButton:Disable();
        end
    end
end

-- This is called when a user is done editing options and clicks ok. This takes the values from the options frames' widgets and writes them to the config file so they will be stored properly.
function AggroNotifier_UpdateOptionsFrame()
    -- We only want to update our saved values if the options frame has been loaded. Otherwise we might blank out all our data if the user loads the interface menu
    -- and then closes it by clicking ok, but never actually opens the AggroNotifier options.
    if (optionsFrameActive) then
        -- Set the "options frame is active" value to false since we're done with the options frame.
        optionsFrameActive = false;
        
        -- Update our stored values with the current options frame values.
        
        -- PLAYER OPTIONS
        AggroNotifier_Config.desiredAggroText = AggroNotifier_OptionsAggroTextEditBox:GetText();
        AggroNotifier_Config.desiredGenericAggroText = AggroNotifier_OptionsGenericAggroTextEditBox:GetText();
        AggroNotifier_Config.desiredFadeTimeMilliseconds = AggroNotifier_OptionsFadeTimeSlider:GetValue();
        AggroNotifier_Config.desiredIncludePvpTagInEnemyName = AggroNotifier_ForceBoolean(AggroNotifier_OptionsIncludePvpInEnemyNameCheckbox:GetChecked());
        local r, g, b, a = AggroNotifier_OptionsGainAggroColorButton.texture:GetVertexColor();
        AggroNotifier_Config.gainAggroColor = {r, g, b, a};
        r, g, b, a = AggroNotifier_OptionsLoseAggroColorButton.texture:GetVertexColor();
        AggroNotifier_Config.loseAggroColor = {r, g, b, a};
        AggroNotifier_Config.desiredAggroTextFontSize = AggroNotifier_OptionsFontSizeSlider:GetValue();
        
        AggroNotifier_Config.addonEnabled = AggroNotifier_ForceBoolean(AggroNotifier_OptionsAddonEnabledCheckbox:GetChecked());
        AggroNotifier_Config.soloEnabledForMobs = AggroNotifier_ForceBoolean(AggroNotifier_OptionsSoloEnabledForMobsCheckbox:GetChecked());
        AggroNotifier_Config.soloEnabledForPvp = AggroNotifier_ForceBoolean(AggroNotifier_OptionsSoloEnabledForPvpCheckbox:GetChecked());
        AggroNotifier_Config.desiredRefreshAggroTextOnEveryNewAggro = AggroNotifier_ForceBoolean(AggroNotifier_OptionsRefreshAggroTextCheckbox:GetChecked());
        AggroNotifier_Config.desiredAlwaysSearchForAggro = AggroNotifier_ForceBoolean(AggroNotifier_OptionsAlwaysSearchForAggroCheckbox:GetChecked());
        AggroNotifier_Config.desiredExtraTargetSearchDepth = AggroNotifier_OptionsExtraTargetSearchDepthSlider:GetValue();
        AggroNotifier_Config.timeDelayBetweenAggroSearches = AggroNotifier_OptionsTimeDelayBetweenAggroSearchesSlider:GetValue();
        
        AggroNotifier_Config.disableBuiltinVisuals = AggroNotifier_ForceBoolean(AggroNotifier_OptionsDisableBuiltinVisuals:GetChecked());
        AggroNotifier_Config.disableModIntegrationPlayer = AggroNotifier_ForceBoolean(AggroNotifier_OptionsDisableModIntegration:GetChecked());
        AggroNotifier_Config.playSoundOnAggroGain = AggroNotifier_ForceBoolean(AggroNotifier_OptionsPlaySoundCheckbox:GetChecked());
        AggroNotifier_Config.preventFadeoutOnAggroGain = AggroNotifier_ForceBoolean(AggroNotifier_OptionsPreventFadeoutCheckbox:GetChecked());
        
        -- PET OPTIONS
        AggroNotifier_Config.desiredAggroTextPet = AggroNotifier_PetOptionsAggroTextEditBox:GetText();
        AggroNotifier_Config.desiredGenericAggroTextPet = AggroNotifier_PetOptionsGenericAggroTextEditBox:GetText();
        AggroNotifier_Config.desiredFadeTimeMillisecondsPet = AggroNotifier_PetOptionsFadeTimeSlider:GetValue();
        AggroNotifier_Config.desiredIncludePvpTagInEnemyNamePet = AggroNotifier_ForceBoolean(AggroNotifier_PetOptionsIncludePvpInEnemyNameCheckbox:GetChecked());
        local r, g, b, a = AggroNotifier_PetOptionsGainAggroColorButton.texture:GetVertexColor();
        AggroNotifier_Config.gainAggroColorPet = {r, g, b, a};
        r, g, b, a = AggroNotifier_PetOptionsLoseAggroColorButton.texture:GetVertexColor();
        AggroNotifier_Config.loseAggroColorPet = {r, g, b, a};
        AggroNotifier_Config.desiredAggroTextFontSizePet = AggroNotifier_PetOptionsFontSizeSlider:GetValue();
    
        AggroNotifier_Config.addonEnabledPet = AggroNotifier_ForceBoolean(AggroNotifier_PetOptionsAddonEnabledCheckbox:GetChecked());
        AggroNotifier_Config.soloEnabledForMobsPet = AggroNotifier_ForceBoolean(AggroNotifier_PetOptionsSoloEnabledForMobsCheckbox:GetChecked());
        AggroNotifier_Config.soloEnabledForPvpPet = AggroNotifier_ForceBoolean(AggroNotifier_PetOptionsSoloEnabledForPvpCheckbox:GetChecked());
        AggroNotifier_Config.desiredRefreshAggroTextOnEveryNewAggroPet = AggroNotifier_ForceBoolean(AggroNotifier_PetOptionsRefreshAggroTextCheckbox:GetChecked());
        AggroNotifier_Config.desiredAlwaysSearchForAggroPet = AggroNotifier_ForceBoolean(AggroNotifier_PetOptionsAlwaysSearchForAggroCheckbox:GetChecked());
        AggroNotifier_Config.desiredExtraTargetSearchDepthPet = AggroNotifier_PetOptionsExtraTargetSearchDepthSlider:GetValue();
        AggroNotifier_Config.timeDelayBetweenAggroSearchesPet = AggroNotifier_PetOptionsTimeDelayBetweenAggroSearchesSlider:GetValue();
        
        AggroNotifier_Config.disableBuiltinVisualsPet = AggroNotifier_ForceBoolean(AggroNotifier_PetOptionsDisableBuiltinVisuals:GetChecked());
        AggroNotifier_Config.disableModIntegrationPet = AggroNotifier_ForceBoolean(AggroNotifier_PetOptionsDisableModIntegration:GetChecked());
        AggroNotifier_Config.playSoundOnAggroGainPet = AggroNotifier_ForceBoolean(AggroNotifier_PetOptionsPlaySoundCheckbox:GetChecked());
        AggroNotifier_Config.preventFadeoutOnAggroGainPet = AggroNotifier_ForceBoolean(AggroNotifier_PetOptionsPreventFadeoutCheckbox:GetChecked());
        
        -- ADDON INTEGRATION OPTIONS
        AggroNotifier_Config.integrateWithSct = AggroNotifier_ForceBoolean(AggroNotifier_OtherModOptionsIntegrateWithSctCheckbox:GetChecked());
        AggroNotifier_Config.sctShowAsCrit = AggroNotifier_ForceBoolean(AggroNotifier_OtherModOptionsSctShowAsCritCheckbox:GetChecked());
        AggroNotifier_Config.sctFrameToOutputTo = UIDropDownMenu_GetSelectedValue(AggroNotifier_OtherModOptionsSctFrameToOutputToDropDown);
        AggroNotifier_Config.integrateWithMik = AggroNotifier_ForceBoolean(AggroNotifier_OtherModOptionsIntegrateWithMikCheckbox:GetChecked());
        AggroNotifier_Config.mikShowAsSticky = AggroNotifier_ForceBoolean(AggroNotifier_OtherModOptionsMikShowAsStickyCheckbox:GetChecked());
        AggroNotifier_Config.mikUseAggroNotifierFontSize = AggroNotifier_ForceBoolean(AggroNotifier_OtherModOptionsMikUseAggroNotifierFontSizeCheckbox:GetChecked());
        AggroNotifier_Config.mikFrameToOutputTo = UIDropDownMenu_GetSelectedValue(AggroNotifier_OtherModOptionsMikFrameToOutputToDropDown);
        
        -- We need to reinitialize the aggro text since desired text and/or appearance may have changed.
        AggroNotifier_InitializeAllAggroText();
        
        -- Force runtime variables to update to the latest config.
        AggroNotifier_ConfigWasModified();
        AggroNotifier_UpdateRuntimeVariablesToLatestFromConfig();
    end
end

-- This is called when a user is done editing options and clicks cancel. This simply marks us as being done with the options frame. 
-- We don't update any config file stored values since the user cancelled. The next time the options frames are loaded the widgets will be reset to whatever is stored in the config file.
function AggroNotifier_CancelOptionsFrame()
    -- Make sure the aggro texts are set to the correct font height.
    AggroNotifier_SetAggroFontHeight(AggroNotifier_AggroText, AggroNotifier_Config.desiredAggroTextFontSize);
    AggroNotifier_SetAggroFontHeight(AggroNotifier_AggroTextPet, AggroNotifier_Config.desiredAggroTextFontSizePet);
    
    -- Set the "options frame is active" value to false since we're done with the options frame.
    optionsFrameActive = false;
end

-- This is called when a user clicks the default button in the options pane. This just refreshes all AggroNotifier stored option values in the config file to their defaults.
function AggroNotifier_SetDefaultsOnOptionsFrame()
    for i, configKeyDefaultPair in ipairs(configDefaultsArray) do
        local key = configKeyDefaultPair[1];
        local default = configKeyDefaultPair[2];
        
        -- We can't set the aggro text location offsets here. It needs to be done later as part of resetting the frame draggers or everything goes wonky.
        if (key ~= "desiredAggroTextLocationOffsets" and key ~= "desiredAggroTextLocationOffsetsPet") then
            AggroNotifier_Config[key] = default;
        end
    end
    
    -- Make sure the aggro texts are set to the correct font height.
    AggroNotifier_SetAggroFontHeight(AggroNotifier_AggroText, AggroNotifier_Config.desiredAggroTextFontSize);
    AggroNotifier_SetAggroFontHeight(AggroNotifier_AggroTextPet, AggroNotifier_Config.desiredAggroTextFontSizePet);
    
    -- Reset the aggro frame draggers.
    AggroNotifier_SetAggroTextLocationConfigProperty(AggroNotifier_AggroFrameDragger, configDefaultAggroTextLocationOffsets[1], configDefaultAggroTextLocationOffsets[2], 
        configDefaultAggroTextLocationOffsets[3], configDefaultAggroTextLocationOffsets[4]);
    AggroNotifier_SetAggroFrameDraggerToDesiredLocation(AggroNotifier_AggroFrameDragger);
    AggroNotifier_SetAggroTextFrameToDraggerLocation(AggroNotifier_AggroFrameDragger);
    AggroNotifier_RefreshAggroText(AggroNotifier_AggroText, false, true);
               
    AggroNotifier_SetAggroTextLocationConfigProperty(AggroNotifier_AggroFrameDraggerPet, configDefaultAggroTextLocationOffsetsPet[1], configDefaultAggroTextLocationOffsetsPet[2], 
        configDefaultAggroTextLocationOffsetsPet[3], configDefaultAggroTextLocationOffsetsPet[4]);
    AggroNotifier_SetAggroFrameDraggerToDesiredLocation(AggroNotifier_AggroFrameDraggerPet);
    AggroNotifier_SetAggroTextFrameToDraggerLocation(AggroNotifier_AggroFrameDraggerPet);
    AggroNotifier_RefreshAggroText(AggroNotifier_AggroTextPet, false, true);
    
    local originalOptionsFrameActiveValue = optionsFrameActive;
    optionsFrameActive = false; -- We have to set this to false or else AggroNotifier_PopulateOptionsFrame() won't do anything.
    AggroNotifier_PopulateOptionsFrame();
    optionsFrameActive = originalOptionsFrameActiveValue;
    
    AggroNotifier_ConfigWasModified();
    
    DEFAULT_CHAT_FRAME:AddMessage(AGGRO_NOTIFIER_CONFIG_FILE_DEFAULTS_RESET_MESSAGE);
end

-- Sets the given aggro frame dragger to the location specified in its draggerFrame.locationOffsetsConfigPropertyName config property.
-- This is used to initialize the frame dragger to the location specified for it in the config file.
function AggroNotifier_SetAggroFrameDraggerToDesiredLocation(draggerFrame)
    local locationOffsetData = AggroNotifier_Config[draggerFrame.locationOffsetsConfigPropertyName];
    
    local xOffset = locationOffsetData[1];
    local yOffset = locationOffsetData[2];
    local anchorPoint = locationOffsetData[3];
    local relativeTo = locationOffsetData[4];
    draggerFrame:ClearAllPoints();
    draggerFrame:SetPoint(anchorPoint, UIParent, relativeTo, xOffset, yOffset);
end

-- Sets the aggro text frame associated with the given dragger frame to be at the same location as the dragger frame. This is used to link the text frame to the dragger frame so it appears
-- like the text frame is "attached" to the dragger frame.
function AggroNotifier_SetAggroTextFrameToDraggerLocation(draggerFrame)
    draggerFrame.textFrame:ClearAllPoints();
    draggerFrame.textFrame:SetPoint("CENTER", draggerFrame, "CENTER", 0, -DRAGGER_FRAME_Y_OFFSET);
end

-- Sets the config file data for aggro text associated with the given dragger frame to the specified argument values.
function AggroNotifier_SetAggroTextLocationConfigProperty(draggerFrame, xOffset, yOffset, anchorPoint, relativePoint)
    local configKey = draggerFrame.locationOffsetsConfigPropertyName;
    
    AggroNotifier_Config[configKey][1] = xOffset;
    AggroNotifier_Config[configKey][2] = yOffset;
    AggroNotifier_Config[configKey][3] = anchorPoint;
    AggroNotifier_Config[configKey][4] = relativePoint;
end

-- Returns true if the SCT mod was found, false otherwise.
function AggroNotifier_IsSctModAvailable()
    if (SCT ~= nil) then
        return true;
    end
    
    return false;
end

-- Returns true if the MikSBT mod was found and is enabled, false otherwise.
function AggroNotifier_IsMikModAvailable()
    if (MikSBT ~= nil and MikSBT.IsModDisabled ~= nil and (MikSBT.IsModDisabled() == nil or MikSBT.IsModDisabled == false)) then
        return true;
    end
    
    return false;
end

-- Returns true if AggroNotifier_IsSctModAvailable() is true and the AggroNotifier options are set to integrate with SCT, false otherwise.
function AggroNotifier_ShouldIntegrateWithSct()
    if (AggroNotifier_IsSctModAvailable() and AggroNotifier_Config.integrateWithSct) then
        return true;
    end
    
    return false;
end

-- Returns true if AggroNotifier_IsMikModAvailable() is true and the AggroNotifier options are set to integrate with MSBT, false otherwise.
function AggroNotifier_ShouldIntegrateWithMik()
    if (AggroNotifier_IsMikModAvailable() and AggroNotifier_Config.integrateWithMik) then
        return true;
    end
    
    return false;
end

-- =============================================================================================
-- Automatic execution stuff.
-- =============================================================================================
do
    AggroNotifier_Load();
end