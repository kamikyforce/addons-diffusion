-- This is the english localization file (also the default).

-- Generic stuff
AGGRO_NOTIFIER_ADDON_NAME = "AggroNotifier";
AGGRO_NOTIFIER_ENEMY_NAME_REPLACEMENT_TOKEN = "@enemy@";
AGGRO_NOTIFIER_PVP_ENEMY_NAME_TAG = "(PvP)";

AGGRO_NOTIFIER_OPTIONS_TITLE = AGGRO_NOTIFIER_ADDON_NAME.." Options";
AGGRO_NOTIFIER_OPTIONS_CONTAINER_FRAME_HELP = "Expand the "..AGGRO_NOTIFIER_ADDON_NAME.." list in the AddOns tab to the left and choose one of the options sub-panes.";

AGGRO_NOTIFIER_CONFIG_FILE_IS_CORRUPTED_MESSAGE = AGGRO_NOTIFIER_ADDON_NAME.."'s config file has been corrupted. Please exit World of Warcraft, go into your World of Warcraft/WTF/Account/[Account Name]/[Realm]/[Character]/SavedVariables folder, and delete the "..AGGRO_NOTIFIER_ADDON_NAME..".lua and "..AGGRO_NOTIFIER_ADDON_NAME..".lua.bak files.";
AGGRO_NOTIFIER_CONFIG_FILE_SETTING_DEFAULTS_MESSAGE = AGGRO_NOTIFIER_ADDON_NAME.." has detected a missing, empty, or corrupt config file. This is normal if you have never used "..AGGRO_NOTIFIER_ADDON_NAME.." before. Setting defaults...";
AGGRO_NOTIFIER_CONFIG_FILE_DEFAULTS_RESET_MESSAGE = AGGRO_NOTIFIER_ADDON_NAME.." has successfully reset all options to their defaults.";

-- Options panes titles
AGGRO_NOTIFIER_OPTIONS_FRAME_LABEL_APPEARANCE = "Appearance (Player)";
AGGRO_NOTIFIER_OPTIONS_FRAME_LABEL_BEHAVIOR = "Behavior (Player)";
AGGRO_NOTIFIER_OPTIONS_FRAME_LABEL_APPEARANCE_PET = "Appearance (Pet)";
AGGRO_NOTIFIER_OPTIONS_FRAME_LABEL_BEHAVIOR_PET = "Behavior (Pet)";
AGGRO_NOTIFIER_OPTIONS_FRAME_LABEL_OTHER_ADDON_INTEGRATION = "Other Addon Integration";

-- Player stuff
AGGRO_NOTIFIER_GENERIC_AGGRO_TEXT = "- AGGRO -";
AGGRO_NOTIFIER_NORMAL_AGGRO_TEXT = "- AGGRO FROM @enemy@ -";

AGGRO_NOTIFIER_OPTIONS_TITLE_APPEARANCE = AGGRO_NOTIFIER_ADDON_NAME.." Appearance Options (Player)";
AGGRO_NOTIFIER_OPTIONS_TITLE_BEHAVIOR = AGGRO_NOTIFIER_ADDON_NAME.." Behavior Options (Player)";
AGGRO_NOTIFIER_GAIN_AGGRO_COLOR_OPTION_TEXT = "Gain Aggro Text Color";
AGGRO_NOTIFIER_LOSE_AGGRO_COLOR_OPTION_TEXT = "Lose Aggro Text Color";
AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_OPTION_TITLE = "Desired Aggro Text";
AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_OPTION_DESCRIPTION = "This will be shown in the "..AGGRO_NOTIFIER_GAIN_AGGRO_COLOR_OPTION_TEXT.." when you gain aggro. It will also be shown in the "..AGGRO_NOTIFIER_LOSE_AGGRO_COLOR_OPTION_TEXT.." when all your aggro is lost. You can put "..AGGRO_NOTIFIER_ENEMY_NAME_REPLACEMENT_TOKEN.." in here and it will be replaced with the enemy's name.";
AGGRO_NOTIFIER_GENERIC_AGGRO_TEXT_OPTION_TITLE = "Default Aggro Text";
AGGRO_NOTIFIER_GENERIC_AGGRO_TEXT_OPTION_DESCRIPTION = "This is used as a fall-back when the "..AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_OPTION_TITLE.." includes "..AGGRO_NOTIFIER_ENEMY_NAME_REPLACEMENT_TOKEN..", but there's no enemy available (e.g. when you leave combat).";
AGGRO_NOTIFIER_FADE_TIME_OPTION_TEXT = "Aggro Text Fade Time (in seconds): ";
AGGRO_NOTIFIER_REFRESH_AGGRO_TEXT_ON_EVERY_NEW_AGGRO_OPTION_TEXT = "Refresh Aggro Text Every New Aggro";
AGGRO_NOTIFIER_ALWAYS_SEARCH_FOR_AGGRO_OPTION_TEXT = "Search for Aggro When Out of Combat (useful for PvP)";
AGGRO_NOTIFIER_ADDON_ENABLED_OPTION_TEXT = "Enable AggroNotifier for Player";
AGGRO_NOTIFIER_ENABLED_SOLO_MOB_OPTION_TEXT = "Enable While Soloing (Mobs)";
AGGRO_NOTIFIER_ENABLED_SOLO_PVP_OPTION_TEXT = "Enable While Soloing (PvP)";
AGGRO_NOTIFIER_INCLUDE_PVP_TAG_OPTION_TEXT = "Include '"..AGGRO_NOTIFIER_PVP_ENEMY_NAME_TAG.."' Tag in "..AGGRO_NOTIFIER_ENEMY_NAME_REPLACEMENT_TOKEN.." if Enemy is PvP";
AGGRO_NOTIFIER_EXTRA_TARGET_SEARCH_DEPTH_OPTION_TEXT = "Extra Target-of-Target Search Depth: ";
AGGRO_NOTIFIER_TIME_DELAY_BETWEEN_AGGRO_SEARCHES_OPTION_TEXT = "Time Delay Between Aggro Searches: ";
AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_FONT_SIZE_OPTION_TITLE = "Desired Aggro Text Font Size: ";
AGGRO_NOTIFIER_SHOW_ANCHOR_BUTTON_OPTION_TEXT = "Show Anchor";
AGGRO_NOTIFIER_RESET_ANCHOR_BUTTON_OPTION_TEXT = "Reset Anchor to Default";
AGGRO_NOTIFIER_PREVENT_FADEOUT_ON_AGGRO_GAIN_OPTION_TEXT = "Prevent Aggro Fadeout When You Have Aggro";
AGGRO_NOTIFIER_DISABLE_BUILTIN_VISUALS_OPTION_TEXT = "Disable Builtin Visual Notifier for Player";
AGGRO_NOTIFIER_DISABLE_MOD_INTEGRATION_PLAYER_OPTION_TEXT = "Disable Other Addon Integration for Player Notifications";
AGGRO_NOTIFIER_PLAY_SOUND_ON_AGGRO_GAIN_OPTION_TEXT = "Play Sound When You Gain Aggro";

AGGRO_NOTIFIER_DRAG_AGGRO_TEXT = "Left Click to Drag Aggro Text";

-- Player config tooltips
AGGRO_NOTIFIER_PLAYER_TOOLTIP_INCLUDE_PVP_IN_ENEMY_NAME = "If you check this and include "..AGGRO_NOTIFIER_ENEMY_NAME_REPLACEMENT_TOKEN.." in your aggro text, then "..AGGRO_NOTIFIER_PVP_ENEMY_NAME_TAG.." will be prepended before the enemy's name in the aggro text when the enemy is player controlled. This will give you immediate knowledge of whether you've aggro'd a PvE mob or PvP player.";
AGGRO_NOTIFIER_PLAYER_TOOLTIP_AGGRO_TEXT_FADE_TIME = "This controls the amount of time (in seconds) it will take for the aggro text to fade away once it's been shown.";
AGGRO_NOTIFIER_PLAYER_TOOLTIP_GAIN_AGGRO_COLOR = "This determines the color of the aggro text that appears when you gain aggro.";
AGGRO_NOTIFIER_PLAYER_TOOLTIP_LOSE_AGGRO_COLOR = "This determines the color of the aggro text that appears when you lose aggro.";
AGGRO_NOTIFIER_PLAYER_TOOLTIP_AGGRO_TEXT_FONT_SIZE = "This determines the font size of the aggro text. If this is above 28 then the text may appear blocky.";
AGGRO_NOTIFIER_PLAYER_TOOLTIP_ENABLE_ADDON = "Uncheck this if you want to completely disable aggro detection for yourself.";
AGGRO_NOTIFIER_PLAYER_TOOLTIP_ENABLE_PVE_WHILE_SOLO = "Uncheck this if you want to disable detecting aggro from PvE controlled mobs for yourself when you are soloing.";
AGGRO_NOTIFIER_PLAYER_TOOLTIP_ENABLE_PVP_WHILE_SOLO = "Uncheck this if you want to disable detecting aggro from PvP (player controlled) enemies for yourself when you are soloing.";
AGGRO_NOTIFIER_PLAYER_TOOLTIP_REFRESH_AGGRO_TEXT_EVERY_NEW_AGGRO = "If you leave this checked then aggro text refreshing (switching to a different enemy) will be allowed as soon as your original aggro enemy is no longer detectable.";
AGGRO_NOTIFIER_PLAYER_TOOLTIP_SEARCH_FOR_AGGRO_OUT_OF_COMBAT = "If this is checked then "..AGGRO_NOTIFIER_ADDON_NAME.." will continue to look for aggro even when you are not in combat. This can be useful to let you know when an enemy player (PvP) is targeting you, even if you are not in combat.";
AGGRO_NOTIFIER_PLAYER_TOOLTIP_TARGET_OF_TARGET_SEARCH_DEPTH = "Aggro is detected by looking at all friendly units (player, pet, party, raid, etc) and seeing if any of their targets are targeting you. You can determine how many extra target-of-target-of-target levels "..AGGRO_NOTIFIER_ADDON_NAME.." will search by changing this slider value. Most of the time any extra levels greater than 0 will do nothing but increase processing time, but there are situations where extra target-of-target search depth can reveal an aggro that wouldn't have otherwise been detectable.";
AGGRO_NOTIFIER_PLAYER_TOOLTIP_TIME_DELAY_BETWEEN_AGGRO_SEARCHES = "This determines how much time passes (in seconds) between seaches for player aggro. Set this to 0 if you want aggro searching to be done at every update tick. Since aggro detection can be expensive, setting this to 0 is not recommended unless you need instant aggro notification and your computer can handle the processing power.";
AGGRO_NOTIFIER_PLAYER_TOOLTIP_PREVENT_FADEOUT = "Check this if you want player aggro notification to stay on the screen without any fadeout until you lose aggro.";
AGGRO_NOTIFIER_PLAYER_TOOLTIP_DISABLE_BUILTIN_VISUALS = "Check this if you want to disable "..AGGRO_NOTIFIER_ADDON_NAME.." builtin visuals for the player. This is useful if you only want sound notification or if you want to use other addon integration (e.g SCT or MSBT) for notification visuals rather than the builtin.";
AGGRO_NOTIFIER_PLAYER_TOOLTIP_DISABLE_MOD_INTEGRATION = "Check this if you want to disable "..AGGRO_NOTIFIER_ADDON_NAME.." player notifications to other mods (e.g. SCT or MSBT), even if you've enabled integration on the '"..AGGRO_NOTIFIER_OPTIONS_FRAME_LABEL_OTHER_ADDON_INTEGRATION.."' options pane. This is useful if you want to disable player notifications for other mods but keep pet notifications enabled, or vice versa.";
AGGRO_NOTIFIER_PLAYER_TOOLTIP_PLAY_SOUND = "If this is checked then a sound will play when you gain aggro. Uncheck it to prevent that sound from playing.";

-- Pet stuff
AGGRO_NOTIFIER_GENERIC_PET_AGGRO_TEXT = "- PET AGGRO -";
AGGRO_NOTIFIER_NORMAL_PET_AGGRO_TEXT = "- PET AGGRO FROM @enemy@ -";

AGGRO_NOTIFIER_OPTIONS_TITLE_APPEARANCE_PET = AGGRO_NOTIFIER_ADDON_NAME.." Appearance Options (Pet)";
AGGRO_NOTIFIER_OPTIONS_TITLE_BEHAVIOR_PET = AGGRO_NOTIFIER_ADDON_NAME.." Behavior Options (Pet)";
AGGRO_NOTIFIER_GAIN_AGGRO_COLOR_OPTION_TEXT_PET = "Gain Pet Aggro Text Color";
AGGRO_NOTIFIER_LOSE_AGGRO_COLOR_OPTION_TEXT_PET = "Lose Pet Aggro Text Color";
AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_OPTION_TITLE_PET = "Desired Pet Aggro Text";
AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_OPTION_DESCRIPTION_PET = "This will be shown in the "..AGGRO_NOTIFIER_GAIN_AGGRO_COLOR_OPTION_TEXT_PET.." when you gain aggro. It will also be shown in the "..AGGRO_NOTIFIER_LOSE_AGGRO_COLOR_OPTION_TEXT_PET.." when all your aggro is lost. You can put "..AGGRO_NOTIFIER_ENEMY_NAME_REPLACEMENT_TOKEN.." in here and it will be replaced with the enemy's name.";
AGGRO_NOTIFIER_GENERIC_AGGRO_TEXT_OPTION_TITLE_PET = "Default Pet Aggro Text";
AGGRO_NOTIFIER_GENERIC_AGGRO_TEXT_OPTION_DESCRIPTION_PET = "This is used as a fall-back when the "..AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_OPTION_TITLE_PET.." includes "..AGGRO_NOTIFIER_ENEMY_NAME_REPLACEMENT_TOKEN..", but there's no enemy available (e.g. when you leave combat).";
AGGRO_NOTIFIER_FADE_TIME_OPTION_TEXT_PET = "Pet Aggro Text Fade Time (in seconds): ";
AGGRO_NOTIFIER_REFRESH_AGGRO_TEXT_ON_EVERY_NEW_AGGRO_OPTION_TEXT_PET = "Refresh Pet Aggro Text Every New Pet Aggro";
AGGRO_NOTIFIER_ALWAYS_SEARCH_FOR_AGGRO_OPTION_TEXT_PET = "Search for Pet Aggro When Out of Combat (useful for PvP)";
AGGRO_NOTIFIER_ADDON_ENABLED_OPTION_TEXT_PET = "Enable AggroNotifier for Pets";
AGGRO_NOTIFIER_ENABLED_SOLO_MOB_OPTION_TEXT_PET = "Enable for Pets While Soloing (Mobs)";
AGGRO_NOTIFIER_ENABLED_SOLO_PVP_OPTION_TEXT_PET = "Enable for Pets While Soloing (PvP)";
AGGRO_NOTIFIER_INCLUDE_PVP_TAG_OPTION_TEXT_PET = "Include '"..AGGRO_NOTIFIER_PVP_ENEMY_NAME_TAG.."' Tag in "..AGGRO_NOTIFIER_ENEMY_NAME_REPLACEMENT_TOKEN.." if Pet Enemy is PvP";
AGGRO_NOTIFIER_EXTRA_TARGET_SEARCH_DEPTH_OPTION_TEXT_PET = "Extra Target-of-Target Search Depth for Pet Aggro: ";
AGGRO_NOTIFIER_TIME_DELAY_BETWEEN_AGGRO_SEARCHES_OPTION_TEXT_PET = "Time Delay Between Pet Aggro Searches: ";
AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_FONT_SIZE_OPTION_TITLE_PET = "Desired Pet Aggro Text Font Size: ";
AGGRO_NOTIFIER_SHOW_ANCHOR_BUTTON_OPTION_TEXT_PET = "Show Pet Anchor";
AGGRO_NOTIFIER_RESET_ANCHOR_BUTTON_OPTION_TEXT_PET = "Reset Pet Anchor to Default";
AGGRO_NOTIFIER_PREVENT_FADEOUT_ON_AGGRO_GAIN_OPTION_TEXT_PET = "Prevent Pet Aggro Fadeout When Pet Has Aggro";
AGGRO_NOTIFIER_DISABLE_BUILTIN_VISUALS_OPTION_TEXT_PET = "Disable Builtin Visual Notifier for Pet";
AGGRO_NOTIFIER_DISABLE_MOD_INTEGRATION_PET_OPTION_TEXT = "Disable Other Addon Integration for Pet Notifications";
AGGRO_NOTIFIER_PLAY_SOUND_ON_AGGRO_GAIN_OPTION_TEXT_PET = "Play Sound When Pet Gains Aggro";

AGGRO_NOTIFIER_DRAG_AGGRO_TEXT_PET = "Left Click to Drag Pet Aggro Text";

-- Pet config tooltips
AGGRO_NOTIFIER_PET_TOOLTIP_INCLUDE_PVP_IN_ENEMY_NAME = "If you check this and include "..AGGRO_NOTIFIER_ENEMY_NAME_REPLACEMENT_TOKEN.." in your pet's aggro text, then "..AGGRO_NOTIFIER_PVP_ENEMY_NAME_TAG.." will be prepended before the enemy's name in the pet aggro text when the enemy is player controlled. This will give you immediate knowledge of whether your pet has aggro'd a PvE mob or PvP player.";
AGGRO_NOTIFIER_PET_TOOLTIP_AGGRO_TEXT_FADE_TIME = "This controls the amount of time (in seconds) it will take for the aggro text to fade away once it's been shown.";
AGGRO_NOTIFIER_PET_TOOLTIP_GAIN_AGGRO_COLOR = "This determines the color of the pet aggro text that appears when your pet gains aggro.";
AGGRO_NOTIFIER_PET_TOOLTIP_LOSE_AGGRO_COLOR = "This determines the color of the pet aggro text that appears when your pet loses aggro.";
AGGRO_NOTIFIER_PET_TOOLTIP_AGGRO_TEXT_FONT_SIZE = "This determines the font size of the pet aggro text. If this is above 28 then the text may appear blocky.";
AGGRO_NOTIFIER_PET_TOOLTIP_ENABLE_ADDON = "Uncheck this if you want to completely disable aggro detection for your pet.";
AGGRO_NOTIFIER_PET_TOOLTIP_ENABLE_PVE_WHILE_SOLO = "Uncheck this if you want to disable detecting aggro from PvE controlled mobs for your pet when you are soloing.";
AGGRO_NOTIFIER_PET_TOOLTIP_ENABLE_PVP_WHILE_SOLO = "Uncheck this if you want to disable detecting aggro from PvP (player controlled) enemies for your pet when you are soloing.";
AGGRO_NOTIFIER_PET_TOOLTIP_REFRESH_AGGRO_TEXT_EVERY_NEW_AGGRO = "If you leave this checked then pet aggro text refreshing (switching to a different enemy) will be allowed as soon as your pet's original aggro enemy is no longer detectable.";
AGGRO_NOTIFIER_PET_TOOLTIP_SEARCH_FOR_AGGRO_OUT_OF_COMBAT = "If this is checked then "..AGGRO_NOTIFIER_ADDON_NAME.." will continue to look for pet aggro even when you are not in combat. This can be useful to let you know when an enemy player (PvP) is targeting your pet, even if you are not in combat.";
AGGRO_NOTIFIER_PET_TOOLTIP_TARGET_OF_TARGET_SEARCH_DEPTH = "Pet aggro is detected by looking at all friendly units (player, pet, party, raid, etc) and seeing if any of their targets are targeting your pet. You can determine how many extra target-of-target-of-target levels "..AGGRO_NOTIFIER_ADDON_NAME.." will search by changing this slider value. Most of the time any extra levels greater than 0 will do nothing but increase processing time, but there are situations where extra target-of-target search depth can reveal a pet aggro that wouldn't have otherwise been detectable.";
AGGRO_NOTIFIER_PET_TOOLTIP_TIME_DELAY_BETWEEN_AGGRO_SEARCHES = "This determines how much time passes (in seconds) between seaches for pet aggro. Set this to 0 if you want aggro searching to be done at every update tick. Since aggro detection can be expensive, setting this to 0 is not recommended unless you need instant aggro notification and your computer can handle the processing power.";
AGGRO_NOTIFIER_PET_TOOLTIP_PREVENT_FADEOUT = "Check this if you want pet aggro notification to stay on the screen without any fadeout until your pet loses aggro.";
AGGRO_NOTIFIER_PET_TOOLTIP_DISABLE_BUILTIN_VISUALS = "Check this if you want to disable "..AGGRO_NOTIFIER_ADDON_NAME.." builtin visuals for the pet. This is useful if you only want sound notification or if you want to use other addon integration (e.g SCT or MSBT) for notification visuals rather than the builtin.";
AGGRO_NOTIFIER_PET_TOOLTIP_DISABLE_MOD_INTEGRATION = "Check this if you want to disable "..AGGRO_NOTIFIER_ADDON_NAME.." pet notifications to other mods (e.g. SCT or MSBT), even if you've enabled integration on the '"..AGGRO_NOTIFIER_OPTIONS_FRAME_LABEL_OTHER_ADDON_INTEGRATION.."' options pane. This is useful if you want to disable pet notifications for other mods but keep player notifications enabled, or vice versa.";
AGGRO_NOTIFIER_PET_TOOLTIP_PLAY_SOUND = "If this is checked then a sound will play when your pet gains aggro. Uncheck it to prevent that sound from playing.";

-- Addon integration stuff
AGGRO_NOTIFIER_OPTIONS_TITLE_INTEGRATE_WITH_SCT = "Integration - Scrolling Combat Text (SCT)";
AGGRO_NOTIFIER_OPTIONS_SUBTITLE_CANNOT_FIND_SCT = "Disabled - SCT could not be found.";
AGGRO_NOTIFIER_INTEGRATE_WITH_SCT_OPTION_TEXT = "Integrate with SCT";
AGGRO_NOTIFIER_SHOW_SCT_AS_CRIT_OPTION_TEXT = "Send notifications to SCT as crits";
AGGRO_NOTIFIER_SCT_FRAME_TO_USE_OPTION_TEXT = "Send notifications to SCT frame:";
AGGRO_NOTIFIER_SCT_TEST_BUTTON_TEXT = "Test SCT Integration";

AGGRO_NOTIFIER_OPTIONS_TITLE_INTEGRATE_WITH_MIK = "Integration - Mik's Scrolling Battle Text (MSBT)";
AGGRO_NOTIFIER_OPTIONS_SUBTITLE_CANNOT_FIND_MIK = "Disabled - MSBT could not be found or is disabled in MSBT's options.";
AGGRO_NOTIFIER_INTEGRATE_WITH_MIK_OPTION_TEXT = "Integrate with MSBT";
AGGRO_NOTIFIER_SHOW_MIK_AS_STICKY_OPTION_TEXT = "Send notifications to MSBT as sticky";
AGGRO_NOTIFIER_USE_AGGRO_NOTIFIER_FONT_SIZE_MIK = "Use "..AGGRO_NOTIFIER_ADDON_NAME.." font sizes";
AGGRO_NOTIFIER_MIK_FRAME_TO_USE_OPTION_TEXT = "Send notifications to MSBT frame:";
AGGRO_NOTIFIER_MIK_TEST_BUTTON_TEXT = "Test MSBT Integration";

-- Addon integration tooltips
AGGRO_NOTIFIER_TOOLTIP_INTEGRATE_WITH_SCT = "Check this if you want "..AGGRO_NOTIFIER_ADDON_NAME.." to integrate with SCT and send SCT aggro notification messages. NOTE: If you have disabled "..AGGRO_NOTIFIER_ADDON_NAME.." in the behavior options for player or pet, then notifications for that unit will not be sent to SCT even if you have this checked.";
AGGRO_NOTIFIER_TOOLTIP_SHOW_SCT_AS_CRIT = "Check this if you want all notification messages sent to SCT to be sent as 'crit' messages. This will change the way SCT displays the message. See SCT's documentation for more information on what a crit message does.";
AGGRO_NOTIFIER_TOOLTIP_SCT_FRAME_TO_USE = "Select the SCT frame you want "..AGGRO_NOTIFIER_ADDON_NAME.." notifications to be sent to. See SCT's documentation for more info on what each of these frames is for.";

AGGRO_NOTIFIER_TOOLTIP_INTEGRATE_WITH_MIK = "Check this if you want "..AGGRO_NOTIFIER_ADDON_NAME.." to integrate with MSBT and send MSBT aggro notification messages. NOTE: If you have disabled "..AGGRO_NOTIFIER_ADDON_NAME.." in the behavior options for player or pet, then notifications for that unit will not be sent to MSBT even if you have this checked.";
AGGRO_NOTIFIER_TOOLTIP_SHOW_MIK_AS_STICKY = "Check this if you want all notification messages sent to MSBT to be sent as 'sticky' messages. This will change the way MSBT displays the message. See MSBT's documentation for more information on what a sticky message does.";
AGGRO_NOTIFIER_TOOLTIP_USE_AGGRO_NOTIFIER_FONT_SIZE_MIK = "Check this to use the font sizes from the "..AGGRO_NOTIFIER_ADDON_NAME.." behavior options panes. Uncheck this to use the normal MSBT size instead.";
AGGRO_NOTIFIER_TOOLTIP_MIK_FRAME_TO_USE = "Select the MSBT frame you want "..AGGRO_NOTIFIER_ADDON_NAME.." notifications to be sent to. See MSBT's documentation for more info on what each of these frames is for. NOTE: If you add a custom frame to MSBT, you will need to log out and log back in before "..AGGRO_NOTIFIER_ADDON_NAME.." will be able to see and use it here.";