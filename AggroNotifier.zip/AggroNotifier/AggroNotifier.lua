-- General purpose runtime-only properties.
local playerIsInCombat = false;
local addonLoadedEventFired = false;
local variablesLoadedEventFired = false;
local warnedAboutCorruptConfigCount = 0;
local addonHasBeenSetup = false;
local shouldUpdateRuntimePropertiesToLatestConfig = true;
AggroNotifier_MAX_NON_DISTORTED_FONT_SIZE = 28;

-- Runtime-only properties for player aggro.
local playerRuntimeInfo = {
    ["hasAggroStored"] = false,
    ["originalAggroEnemyGuid"] = nil,
    ["originalAggroEnemyIsTargetingMe"] = false,
    ["fadeStartTime"] = nil,
    ["includeEnemyNameInAggroText"] = false,
    ["aggroGainSoundFile"] = "Sound\\Doodad\\BellTollHorde.wav";
};

-- Runtime-only properties for pet aggro.
local petRuntimeInfo = {
    ["hasAggroStored"] = false,
    ["originalAggroEnemyGuid"] = nil,
    ["originalAggroEnemyIsTargetingMe"] = false,
    ["fadeStartTime"] = nil,
    ["includeEnemyNameInAggroText"] = false,
    ["aggroGainSoundFile"] = "Sound\\interface\\RaidWarning.wav";
};

-- Although it would make sense to put these runtime variables in the unitRuntimeInfo objects themselves, doing the table lookup is expensive. Since these variables have
-- to be looked at each update tick we'll make them local cheap-to-access variables instead.
timePassedSinceLastAggroSearchPlayer = 0;
timePassedSinceLastAggroSearchPet = 0;
minTimeDelayBetweenAggroSearchesPlayer = AggroNotifier_configDefaultTimeDelayBetweenAggroSearches;
minTimeDelayBetweenAggroSearchesPet = AggroNotifier_configDefaultTimeDelayBetweenAggroSearches;

timePassedSinceLastTextFadeUpdatePlayer = 0;
timePassedSinceLastTextFadeUpdatePet = 0;
minTimeDelayBetweenTextFadeUpdatesPlayer = AggroNotifier_configDefaultTimeDelayBetweenTextFadeUpdates;
minTimeDelayBetweenTextFadeUpdatesPet = AggroNotifier_configDefaultTimeDelayBetweenTextFadeUpdates;


-- Helper function for determining whether the given value is true or not. If the given value is nil this returns false.
function AggroNotifier_ForceBoolean(forceBoolean)
    if (forceBoolean == nil) then
        return false;
    elseif (forceBoolean == 1 or forceBoolean == "1" or string.lower(tostring(forceBoolean)) == "true") then
        return true;
    end
    
    return false;
end

-- Function for handling events that AggroNotifier cares about.
function AggroNotifier_GeneralEventHandler()
    if (event == "ADDON_LOADED" and arg1 == "AggroNotifier") then
        addonLoadedEventFired = true;
    elseif (event == "VARIABLES_LOADED") then
        variablesLoadedEventFired = true;
    elseif (event == "PLAYER_REGEN_DISABLED") then
        -- The player just went into combat.
        playerIsInCombat = true;
    elseif (event == "PLAYER_REGEN_ENABLED") then
        -- The player has dropped out of combat.
        playerIsInCombat = false;
        -- The player definitely no longer has aggro, so we can clear out the original aggro enemy variables for both player and pet.
        playerRuntimeInfo.originalAggroEnemyGuid = nil;
        playerRuntimeInfo.originalAggroEnemyIsTargetingMe = false;
        petRuntimeInfo.originalAggroEnemyGuid = nil;
        petRuntimeInfo.originalAggroEnemyIsTargetingMe = false;
        
        if (playerRuntimeInfo.hasAggroStored) then
            playerRuntimeInfo.hasAggroStored = false;
            -- The player previously had aggro before combat ended though, so pop the aggro text back up 
            -- (now that we're out of combat there will be no aggro and the text will pop up the "all clear" green).
            AggroNotifier_ShowAggroText(AggroNotifier_AggroText);
        end
        
        if (petRuntimeInfo.hasAggroStored) then
            petRuntimeInfo.hasAggroStored = false;
            -- The pet previously had aggro before combat ended though, so pop the aggro text back up 
            -- (now that we're out of combat there will be no aggro and the text will pop up the "all clear" green).
            AggroNotifier_ShowAggroText(AggroNotifier_AggroTextPet);
        end
    end
    
    if (addonLoadedEventFired and variablesLoadedEventFired and (not addonHasBeenSetup)) then
        addonHasBeenSetup = true;
        -- Set up a bidirectional link between the aggro text objects and the runtime variable arrays they are associated with.
        AggroNotifier_AggroText.runtimeInfo = playerRuntimeInfo;
        playerRuntimeInfo.aggroTextObject = AggroNotifier_AggroText;
        AggroNotifier_AggroTextPet.runtimeInfo = petRuntimeInfo;
        petRuntimeInfo.aggroTextObject = AggroNotifier_AggroTextPet;
        
        -- Load all our config stuff.
        AggroNotifier_LoadConfig();
    end
end

-- Sets the aggro text font height for the given aggro text object. 
function AggroNotifier_SetAggroFontHeight(aggroTextObject, height)
    if (height <= 0) then
        if (warnedAboutCorruptConfigCount % 2 == 0) then
            DEFAULT_CHAT_FRAME:AddMessage(AGGRO_NOTIFIER_CONFIG_FILE_IS_CORRUPTED_MESSAGE);
        end
        height = 4;
        warnedAboutCorruptConfigCount = warnedAboutCorruptConfigCount + 1;
    end

    if (height <= AggroNotifier_MAX_NON_DISTORTED_FONT_SIZE) then
        -- If the height is AggroNotifier_MAX_NON_DISTORTED_FONT_SIZE or below we can directly set the font size. This provides clear text.
        aggroTextObject:SetFont(GameFontNormal:GetFont(), height, "OUTLINE, THICKOUTLINE");
    else
        -- If the height is above AggroNotifier_MAX_NON_DISTORTED_FONT_SIZE then we have to scale it using SetTextHeight(...). This provides blocky text, but at least it will be the desired size.
        local amountAboveNormalMaxHeight = height - AggroNotifier_MAX_NON_DISTORTED_FONT_SIZE;
        height = height + (amountAboveNormalMaxHeight * 2);
        aggroTextObject:SetFont(GameFontNormal:GetFont(), AggroNotifier_MAX_NON_DISTORTED_FONT_SIZE, "OUTLINE, THICKOUTLINE");
        aggroTextObject:SetTextHeight(height);
    end
end

-- This function indicates that the config was modified and therefore the runtime properties should look at the config again and update to the latest values.
function AggroNotifier_ConfigWasModified()
    shouldUpdateRuntimePropertiesToLatestConfig = true;
end

-- Updates all the runtime behavior variables from the saved config values. If the config hasn't changed since the last time this was called then it does nothing.
function AggroNotifier_UpdateRuntimeVariablesToLatestFromConfig()
    if (shouldUpdateRuntimePropertiesToLatestConfig) then
        shouldUpdateRuntimePropertiesToLatestConfig = false;
        
        -- Set runtime variables on the aggro text objects to be the current values of the config file.
        AggroNotifier_AggroText.runtimeInfo.includePvpTagInEnemyName = AggroNotifier_Config.desiredIncludePvpTagInEnemyName;
        AggroNotifier_AggroTextPet.runtimeInfo.includePvpTagInEnemyName = AggroNotifier_Config.desiredIncludePvpTagInEnemyNamePet;
        
        AggroNotifier_AggroText.runtimeInfo.desiredAggroText = AggroNotifier_Config.desiredAggroText;
        AggroNotifier_AggroTextPet.runtimeInfo.desiredAggroText = AggroNotifier_Config.desiredAggroTextPet;
        
        AggroNotifier_AggroText.runtimeInfo.genericAggroText = AggroNotifier_Config.desiredGenericAggroText;
        AggroNotifier_AggroTextPet.runtimeInfo.genericAggroText = AggroNotifier_Config.desiredGenericAggroTextPet;
        
        AggroNotifier_AggroText.runtimeInfo.fadeTimeMilliseconds = AggroNotifier_Config.desiredFadeTimeMilliseconds;
        AggroNotifier_AggroTextPet.runtimeInfo.fadeTimeMilliseconds = AggroNotifier_Config.desiredFadeTimeMillisecondsPet;
        
        AggroNotifier_AggroText.runtimeInfo.gainAggroColor = AggroNotifier_Config.gainAggroColor;
        AggroNotifier_AggroTextPet.runtimeInfo.gainAggroColor = AggroNotifier_Config.gainAggroColorPet;
        
        AggroNotifier_AggroText.runtimeInfo.loseAggroColor = AggroNotifier_Config.loseAggroColor;
        AggroNotifier_AggroTextPet.runtimeInfo.loseAggroColor = AggroNotifier_Config.loseAggroColorPet;
        
        AggroNotifier_AggroText.runtimeInfo.preventFadeoutOnAggroGain = AggroNotifier_Config.preventFadeoutOnAggroGain;
        AggroNotifier_AggroTextPet.runtimeInfo.preventFadeoutOnAggroGain = AggroNotifier_Config.preventFadeoutOnAggroGainPet;
        
        AggroNotifier_AggroText.runtimeInfo.disableBuiltinVisuals = AggroNotifier_Config.disableBuiltinVisuals;
        AggroNotifier_AggroTextPet.runtimeInfo.disableBuiltinVisuals = AggroNotifier_Config.disableBuiltinVisualsPet;
        
        AggroNotifier_AggroText.runtimeInfo.disableModIntegration = AggroNotifier_Config.disableModIntegrationPlayer;
        AggroNotifier_AggroTextPet.runtimeInfo.disableModIntegration = AggroNotifier_Config.disableModIntegrationPet;
        
        AggroNotifier_AggroText.runtimeInfo.playSoundOnAggroGain = AggroNotifier_Config.playSoundOnAggroGain;
        AggroNotifier_AggroTextPet.runtimeInfo.playSoundOnAggroGain = AggroNotifier_Config.playSoundOnAggroGainPet;
        
        AggroNotifier_AggroText.runtimeInfo.fontSize = AggroNotifier_Config.desiredAggroTextFontSize;
        AggroNotifier_AggroTextPet.runtimeInfo.fontSize = AggroNotifier_Config.desiredAggroTextFontSizePet;
        
        AggroNotifier_AggroText.runtimeInfo.addonEnabled = AggroNotifier_Config.addonEnabled;
        AggroNotifier_AggroTextPet.runtimeInfo.addonEnabled = AggroNotifier_Config.addonEnabledPet;
        
        AggroNotifier_AggroText.runtimeInfo.soloEnabledForMobs = AggroNotifier_Config.soloEnabledForMobs;
        AggroNotifier_AggroTextPet.runtimeInfo.soloEnabledForMobs = AggroNotifier_Config.soloEnabledForMobsPet;
        
        AggroNotifier_AggroText.runtimeInfo.soloEnabledForPvp = AggroNotifier_Config.soloEnabledForPvp;
        AggroNotifier_AggroTextPet.runtimeInfo.soloEnabledForPvp = AggroNotifier_Config.soloEnabledForPvpPet;
        
        AggroNotifier_AggroText.runtimeInfo.alwaysSearchForAggro = AggroNotifier_Config.desiredAlwaysSearchForAggro;
        AggroNotifier_AggroTextPet.runtimeInfo.alwaysSearchForAggro = AggroNotifier_Config.desiredAlwaysSearchForAggroPet;
        
        AggroNotifier_AggroText.runtimeInfo.extraTargetSearchDepth = AggroNotifier_Config.desiredExtraTargetSearchDepth;
        AggroNotifier_AggroTextPet.runtimeInfo.extraTargetSearchDepth = AggroNotifier_Config.desiredExtraTargetSearchDepthPet;
        
        AggroNotifier_AggroText.runtimeInfo.refreshAggroTextOnEveryNewAggro = AggroNotifier_Config.desiredRefreshAggroTextOnEveryNewAggro;
        AggroNotifier_AggroTextPet.runtimeInfo.refreshAggroTextOnEveryNewAggro = AggroNotifier_Config.desiredRefreshAggroTextOnEveryNewAggroPet;
        
        minTimeDelayBetweenAggroSearchesPlayer = AggroNotifier_Config.timeDelayBetweenAggroSearches;
        minTimeDelayBetweenAggroSearchesPet = AggroNotifier_Config.timeDelayBetweenAggroSearchesPet;
    end
end

-- Helper function for calling AggroNotifier_InitializeAggroText(aggroTextObject, desiredAggroTextFontSize, desiredAggroText) on all the aggro text objects (Player and Pet).
function AggroNotifier_InitializeAllAggroText()
    -- Force runtime variables to update to the latest config.
    AggroNotifier_ConfigWasModified();
    AggroNotifier_UpdateRuntimeVariablesToLatestFromConfig();
    
    AggroNotifier_InitializeAggroText(AggroNotifier_AggroText, AggroNotifier_Config.desiredAggroTextFontSize, AggroNotifier_Config.desiredAggroText);
    AggroNotifier_InitializeAggroText(AggroNotifier_AggroTextPet, AggroNotifier_Config.desiredAggroTextFontSizePet, AggroNotifier_Config.desiredAggroTextPet);
end

-- Initializes the given aggro text object with the given font size and aggro text. 
-- This function does some extra checking to set the runtime value for whether the enemy name should be included in the aggro text.
function AggroNotifier_InitializeAggroText(aggroTextObject, desiredAggroTextFontSize, desiredAggroText)
    -- Set the font size.
    AggroNotifier_SetAggroFontHeight(aggroTextObject, desiredAggroTextFontSize);

    -- Set up the aggro text box with the user's desired aggro text, and figure out if we'll need to include the enemy name in the aggro text.
    AggroNotifier_SetAggroText(aggroTextObject, desiredAggroText, nil, nil);
    if (string.find(desiredAggroText, AGGRO_NOTIFIER_ENEMY_NAME_REPLACEMENT_TOKEN)) then
        aggroTextObject.runtimeInfo.includeEnemyNameInAggroText = true;
    else
        aggroTextObject.runtimeInfo.includeEnemyNameInAggroText = false;
    end
end

-- Sets the given text on the given aggro text object. You can pass in an enemy name and whether the enemy is PvP if relevant.
-- If there's a problem with the text (such as an enemy name replacement token not being replaced with the enemy name), 
-- then the generic aggro text for the given aggro text object will be used.
function AggroNotifier_SetAggroText(aggroTextObject, newText, enemyName, enemyIsPvp)
    -- If the enemy name was passed in then we'll try to replace any enemy-name-replacement-token with the passed in name.
    if (enemyName ~= nil) then
        if ((enemyIsPvp ~= nil) and enemyIsPvp and aggroTextObject.runtimeInfo.includePvpTagInEnemyName) then
            enemyName = AGGRO_NOTIFIER_PVP_ENEMY_NAME_TAG.." "..enemyName;
        end
        newText = string.gsub(newText, AGGRO_NOTIFIER_ENEMY_NAME_REPLACEMENT_TOKEN, enemyName);
    end
    
    -- If for some reason the enemy name replacement token is still in the string we're supposed to set, 
    -- then something went wrong and we should use the generic aggro text instead.
    if (string.find(newText, AGGRO_NOTIFIER_ENEMY_NAME_REPLACEMENT_TOKEN)) then
        aggroTextObject:SetText(aggroTextObject.runtimeInfo.genericAggroText);
    else
        aggroTextObject:SetText(newText);
    end
end

-- Shows the aggro text, but does a little bit of checking to make sure we haven't lost the enemy (for enemy name inclusion in the aggro text).
-- If there's no longer any enemy then the generic aggro text for the given aggro text object will be used instead of the regular aggro text.
function AggroNotifier_ShowAggroText(aggroTextObject)
    if ((not aggroTextObject.runtimeInfo.hasAggroStored) and aggroTextObject.runtimeInfo.includeEnemyNameInAggroText) then
        -- We do not having aggro, but the normal aggro text has an enemy name token in it. Since there's no longer
        -- an enemy to put in that token slot, we should just use the generic aggro text.
        AggroNotifier_SetAggroText(aggroTextObject, aggroTextObject.runtimeInfo.genericAggroText, nil, nil);
    end
    
    AggroNotifier_RefreshAggroText(aggroTextObject, true, false);
end

-- Simply resets the fade start time for the given aggro text object so that it will pop up on the screen again, and unhides the given aggro text object so it can be seen.
-- If triggerModIntegrationMessage is true then any other mod we've registered with (e.g. SCT or MikScrollingBattleText) will be told to show it's message 
--    as long as the aggroTextObject doesn't have integration disabled.
-- If forceShowAggroNotifierVisuals is true, then aggroTextObject:Show() will be called (and therefore the text object will be shown on the screen) regardless of 
--    whether or not the user has chosen the "hide AggroNotifier builtin visuals" option for the unit represented by this aggroTextObject. Otherwise this function will honor that user choice.
function AggroNotifier_RefreshAggroText(aggroTextObject, triggerModIntegrationMessage, forceShowAggroNotifierVisuals)
    -- Update the fade start time on the aggroTextObject.
    aggroTextObject.runtimeInfo.fadeStartTime = GetTime();
    
    -- Show the aggro text object if we're forced to, or if the aggroTextObject is *not* disabled visually.
    if (forceShowAggroNotifierVisuals) then
        aggroTextObject:Show();
    elseif (not aggroTextObject.runtimeInfo.disableBuiltinVisuals) then
        aggroTextObject:Show();
    end
    
    -- Send a notification message to integrated addons if desired.
    if (triggerModIntegrationMessage) then
        -- Check the aggro text object's preference.
        if (not aggroTextObject.runtimeInfo.disableModIntegration) then
            AggroNotifier_SendMessageToSct(aggroTextObject, AggroNotifier_Config.sctShowAsCrit, AggroNotifier_Config.sctFrameToOutputTo, false);
            AggroNotifier_SendMessageToMik(aggroTextObject, AggroNotifier_Config.mikShowAsSticky, AggroNotifier_Config.mikUseAggroNotifierFontSize, AggroNotifier_Config.mikFrameToOutputTo, false);
        end
    end
end

-- Forcibly hides the given aggro text object, even if it was being shown or in the middle of a fade.
function AggroNotifier_HideAggroText(aggroTextObject)
    aggroTextObject.runtimeInfo.fadeStartTime = nil;
    aggroTextObject.runtimeInfo.temporaryColorOverride = nil;
    aggroTextObject:SetVertexColor(0.00, 0.00, 0.00, 0.00);
    aggroTextObject:Hide();
end

-- Helper function for sending a message to SCT. This function makes sure we *should* be sending messages to SCT before doing anything unless forceShowAttempt is true, 
--    in which case it will make the attempt no matter what.
function AggroNotifier_SendMessageToSct(aggroTextObject, showAsCrit, sctFrameToOutputTo, forceShowAttempt)
    -- See if we should send a message to SCT
    if (forceShowAttempt or AggroNotifier_ShouldIntegrateWithSct()) then
        -- Get the notification color and put it in an array object that SCT can recognize.
        local red, green, blue, alpha = AggroNotifier_GetAggroTextObjectColor(aggroTextObject, 0.00, nil);
        local sctColor =  {r = red, g = green, b = blue};
        
        -- Pass the notification on to SCT
        if (sctFrameToOutputTo < 0 or sctFrameToOutputTo > 2) then
            -- Protect against invalid options.
            sctFrameToOutputTo = 1;
        end
        
        -- If we're outputting to the message frame then we have to treat it a little differently than otherwise.
        if (sctFrameToOutputTo == 0) then
            SCT:DisplayMessage(aggroTextObject:GetText(), sctColor);
        else
            SCT:DisplayText(aggroTextObject:GetText(), sctColor, showAsCrit, "event", sctFrameToOutputTo);
        end
    end
end

-- Helper function for sending a message to Mik SBT. This function makes sure we *should* be sending messages to Mik before doing anything unless forceShowAttempt is true, 
--    in which case it will make the attempt no matter what.
function AggroNotifier_SendMessageToMik(aggroTextObject, showAsSticky, shouldUseAggroNotifierFontSize, mikFrameToOutputTo, forceShowAttempt)
    -- See if we should send a message to MikSBT
    if (forceShowAttempt or AggroNotifier_ShouldIntegrateWithMik()) then
        local redOneBased, greenOneBased, blueOneBased, alpha = AggroNotifier_GetAggroTextObjectColor(aggroTextObject, 0.00, nil);
        -- Mik uses colors on the 0-255 (integer) scale, not 0.00-1.00 (float) scale, so we have to convert our color values before passing them on.
        local red = redOneBased * 255;
        local green = greenOneBased * 255;
        local blue = blueOneBased * 255;
        -- Figure out the font size to pass in based on user preference.
        local fontSize = nil; -- Mik will change this to its default if it stays nil.
        if (shouldUseAggroNotifierFontSize) then
            fontSize = aggroTextObject.runtimeInfo.fontSize;
            -- Mik only supports a font size in range of 4-38.
            if (fontSize < 4) then
                fontSize = 4;
            elseif (fontSize > 38) then
                fontSize = 38; 
            end
        end
        
        -- Pass the notification on to MikSBT
        MikSBT.DisplayMessage(aggroTextObject:GetText(), mikFrameToOutputTo, showAsSticky, red, green, blue, fontSize);
    end
end

-- Helper function for determining whether the player is solo or in a party/raid.
function AggroNotifier_IsSolo()
    local numPartyMembers = GetNumPartyMembers();
    local numRaidMembers = GetNumRaidMembers();
    return ((numPartyMembers == 0) and (numRaidMembers == 0));
end

-- Process an update tick.
function AggroNotifier_ProcessUpdate(self, elapsed)
    if (addonHasBeenSetup) then
        -- Make sure our runtime variables are up-to-date.
        AggroNotifier_UpdateRuntimeVariablesToLatestFromConfig();
        
        -- We should only update every so often.
        -- Increment our "time since last aggro search" counter for the player by the given elapsed time value.
        timePassedSinceLastAggroSearchPlayer = timePassedSinceLastAggroSearchPlayer + elapsed;
        if (timePassedSinceLastAggroSearchPlayer >= minTimeDelayBetweenAggroSearchesPlayer) then
            -- Process the update for player.
            AggroNotifier_UpdateSpecifiedUnit("player", AggroNotifier_AggroText, elapsed);
            -- Update our "time passed" counter since we just did an update.
            timePassedSinceLastAggroSearchPlayer = 0;
        end
        
        -- Do the same for pet aggro update.
        timePassedSinceLastAggroSearchPet = timePassedSinceLastAggroSearchPet + elapsed;
        if (timePassedSinceLastAggroSearchPet >= minTimeDelayBetweenAggroSearchesPet) then
            AggroNotifier_UpdateSpecifiedUnit("pet", AggroNotifier_AggroTextPet, elapsed);
            timePassedSinceLastAggroSearchPet = 0;
        end
        
        -- Call the aggro text fade handlers, which will fade (or hide) the text appropriately. These are also on an "only update every so often" schedule.
        -- Process player text fade handler.
        timePassedSinceLastTextFadeUpdatePlayer = timePassedSinceLastTextFadeUpdatePlayer + elapsed;
        if (timePassedSinceLastTextFadeUpdatePlayer >= minTimeDelayBetweenTextFadeUpdatesPlayer) then
            AggroNotifier_HandleTextFade(AggroNotifier_AggroText);
            timePassedSinceLastTextFadeUpdatePlayer = 0;
        end
        
        -- Process pet text fade handler.
        timePassedSinceLastTextFadeUpdatePet = timePassedSinceLastTextFadeUpdatePet + elapsed;
        if (timePassedSinceLastTextFadeUpdatePet >= minTimeDelayBetweenTextFadeUpdatesPet) then
            AggroNotifier_HandleTextFade(AggroNotifier_AggroTextPet);
            timePassedSinceLastTextFadeUpdatePet = 0;
        end
    end
end

-- Helper function for determining whether the specified unit's aggro text object should be shown.
function AggroNotifier_UpdateSpecifiedUnit(specifiedUnitId, aggroTextObject)
    local runtimeInfo = aggroTextObject.runtimeInfo;
    local addonEnabled = runtimeInfo.addonEnabled;
    local soloEnabledForMobs = runtimeInfo.soloEnabledForMobs;
    local soloEnabledForPvp = runtimeInfo.soloEnabledForPvp;
    local alwaysSearchForAggro = runtimeInfo.alwaysSearchForAggro;

    -- See if we should bail without doing anything (depending on the user's option choices).
    if (not addonEnabled) then
        return;
    elseif (AggroNotifier_IsSolo() and (not soloEnabledForMobs) and (not soloEnabledForPvp)) then
        return;
    end
    
    -- We only want to worry about the aggro text at all (and incur the associated processing time) if we're in combat or the fader is still going.
    -- However the specified unit can choose to always search for aggro if they want.
    if (playerIsInCombat or (runtimeInfo.fadeStartTime ~= nil) or alwaysSearchForAggro) then
    
        -- Find out if we have aggro right now.
        local specifiedUnitHasAggroThisTick = AggroNotifier_SpecifiedUnitHasAggro(specifiedUnitId, aggroTextObject);
    
        -- If the aggro status has changed then we want to pop up the aggro text box with a brand new fade timer.
        if (specifiedUnitHasAggroThisTick ~= runtimeInfo.hasAggroStored) then
            runtimeInfo.hasAggroStored = specifiedUnitHasAggroThisTick;
            AggroNotifier_ShowAggroText(aggroTextObject);
            
            -- Play a sound if desired and appropriate.
            if (runtimeInfo.playSoundOnAggroGain and specifiedUnitHasAggroThisTick) then
                PlaySoundFile(runtimeInfo.aggroGainSoundFile);            
            end
        end
    end
end

-- Table used by the AggroNotifier_SpecifiedUnitHasAggro(...) function. It is declared here so that we 
-- don't create a bunch of extra memory every time the function is called. Table creation and filling is expensive.
local unitIdsToCheckArray = {};

-- The guts of AggroNotifier. This function determines whether the specified unit has aggro right now.
function AggroNotifier_SpecifiedUnitHasAggro(specifiedUnitId, aggroTextObject)
    -- NOTE: In comments in this function, the specifiedUnitId variable passed into this function as an argument will always be referred to as the "specified unit".
    if (UnitExists(specifiedUnitId) ~= 1) then
        return false;
    end
    
    --[[ 
        There's no easy way to find out if any particular unit (player, pet, etc) has a hostile targeting him due to Blizzard's scripting restrictions. Therefore we have to do it the hard way:
        Generate a list of unit IDs that we need to check. These unit IDs will be all the targets of of all known friendlies.
        For each of these units, we see if it is hostile and targeting the specified unit. If any are hostile and targeting the specified unit then the specified unit has aggro.
    ]]
    local arrayNextOpenIndex = 1;
    
    -- Add the static targets (the player's target, the player's focus, the player's focus target, the player's pet target, the mouseover unit, and the mouseover unit's target).
    if (UnitExists("focus") == 1) then
        unitIdsToCheckArray[arrayNextOpenIndex] = "focus";
        arrayNextOpenIndex = arrayNextOpenIndex + 1;
    end
    if (UnitExists("focustarget") == 1) then
        unitIdsToCheckArray[arrayNextOpenIndex] = "focustarget";
        arrayNextOpenIndex = arrayNextOpenIndex + 1;
    end
    if (UnitExists("playertarget") == 1) then
        unitIdsToCheckArray[arrayNextOpenIndex] = "playertarget";
        arrayNextOpenIndex = arrayNextOpenIndex + 1;
    end
    if (UnitExists("pettarget") == 1) then
        unitIdsToCheckArray[arrayNextOpenIndex] = "pettarget";
        arrayNextOpenIndex = arrayNextOpenIndex + 1;
    end
    if (UnitExists("mouseover") == 1) then
        unitIdsToCheckArray[arrayNextOpenIndex] = "mouseover";
        arrayNextOpenIndex = arrayNextOpenIndex + 1;
    end
    if (UnitExists("mouseovertarget") == 1) then
        unitIdsToCheckArray[arrayNextOpenIndex] = "mouseovertarget";
        arrayNextOpenIndex = arrayNextOpenIndex + 1;
    end
    
    -- Add all party members' targets (including party members' pets).
    local numPartyMembers = GetNumPartyMembers();
    if (numPartyMembers > 0) then
        for i = 1, numPartyMembers do
            if (UnitExists("party"..i.."target") == 1) then
                unitIdsToCheckArray[arrayNextOpenIndex] = "party"..i.."target";
                arrayNextOpenIndex = arrayNextOpenIndex + 1;
            end
            if (UnitExists("partypet"..i.."target") == 1) then
                unitIdsToCheckArray[arrayNextOpenIndex] = "partypet"..i.."target";
                arrayNextOpenIndex = arrayNextOpenIndex + 1;
            end
        end
    end
    
    -- Add all raid members' targets (including raid members' pets).
    local numRaidMembers = GetNumRaidMembers();
    if (numRaidMembers > 0) then
        for i = 1, numRaidMembers do
            if (UnitExists("raid"..i.."target") == 1) then
                unitIdsToCheckArray[arrayNextOpenIndex] = "raid"..i.."target";
                arrayNextOpenIndex = arrayNextOpenIndex + 1;
            end
            if (UnitExists("raidpet"..i.."target") == 1) then
                unitIdsToCheckArray[arrayNextOpenIndex] = "raidpet"..i.."target";
                arrayNextOpenIndex = arrayNextOpenIndex + 1;
            end
        end
    end
    
    local runtimeInfo = aggroTextObject.runtimeInfo;
    local soloEnabledForMobs = runtimeInfo.soloEnabledForMobs;
    local soloEnabledForPvp = runtimeInfo.soloEnabledForPvp;
    local desiredExtraTargetSearchDepth = runtimeInfo.extraTargetSearchDepth;
    local shouldRefreshAggroTextOnEveryNewAggro = runtimeInfo.refreshAggroTextOnEveryNewAggro;
    
    local isSolo = AggroNotifier_IsSolo();
    
    -- Now we want to dig through our list of friendly unit IDs and look at each one's target. 
    -- If the friendly unit's target is not friendly, is alive, and is targeting the specified unit, then the specified unit has aggro.
    local specifiedUnitHasAggroThisTick = false;
    local enemyUnitGuidOfThisTickAggro = nil;
    local originalAggroEnemyFoundThisTick = false;
    -- Addon users have the option of digging down multiple levels of "target of target of target" etc, 
    -- so run a loop depending on how many levels deep they want to go.
    local currentExtraTargetDepthLevel = 0;
    
    while ((not specifiedUnitHasAggroThisTick) and (currentExtraTargetDepthLevel <= desiredExtraTargetSearchDepth)) do
    
        -- At each target depth level we want to run through our entire list of possible enemy unit IDs.
        local indexToProcess = 1;
        while ((not specifiedUnitHasAggroThisTick) and (indexToProcess < arrayNextOpenIndex)) do
        
            -- Grab the potential enemy unit ID from our list.
            local enemyUnitId = unitIdsToCheckArray[indexToProcess];
            -- Add any extra target levels to the unit ID if necessary.
            for i = 1, currentExtraTargetDepthLevel do
                enemyUnitId = enemyUnitId.."target";
            end
            
            -- If the unit we're checking is *not* friendly to the specified unit then they may be aggro'd on the specified unit and we should check further.
            -- NOTE: We can't use the UnitIsEnemy(...) function because that returns false when the other unit is neutral, even if it's aggro'd on the specified unit.
            if (not UnitIsFriend(specifiedUnitId, enemyUnitId)) then
            
                -- Remember the enemy GUID for later in case we need it.
                local enemyGuid = UnitGUID(enemyUnitId);
                if (runtimeInfo.originalAggroEnemyGuid ~= nil and runtimeInfo.originalAggroEnemyGuid == enemyGuid) then
                    -- We found the original aggro enemy. See if it's still targeting the specified unit.
                    originalAggroEnemyFoundThisTick = true;
                    
                    if (not AggroNotifier_UnitHasAggroFromEnemy(specifiedUnitId, enemyUnitId)) then
                        -- The original aggro enemy is dead or no longer aggro'd on the specified unit. This info may be used later to indicate "all clear" for the specified unit.
                        runtimeInfo.originalAggroEnemyIsTargetingMe = false;
                    end
                end
                
                -- See if this enemy is alive and aggro'd on the specified unit.
                if (AggroNotifier_UnitHasAggroFromEnemy(specifiedUnitId, enemyUnitId)) then
                    -- We may want to ignore this if we're solo and the function arguments want us to ignore it.
                    local enemyIsPvp = UnitPlayerControlled(enemyUnitId);
                    local enemyIsMob = (not enemyIsPvp);
                    local ignoreEnemy = false;
                    if (isSolo and enemyIsPvp and (not soloEnabledForPvp)) then
                        ignoreEnemy = true;
                    elseif (isSolo and enemyIsMob and (not soloEnabledForMobs)) then
                        ignoreEnemy = true;
                    end
                
                    if (not ignoreEnemy) then
                        -- The enemy is alive and targeting the specified unit, so the specified unit has aggro this tick. We should keep track of the enemy's GUID.
                        specifiedUnitHasAggroThisTick = true;
                        enemyUnitGuidOfThisTickAggro = enemyGuid;
                        -- If the specified unit desires, stuff the enemy name into the aggro text.
                        if (runtimeInfo.includeEnemyNameInAggroText) then
                            AggroNotifier_SetAggroText(aggroTextObject, aggroTextObject.runtimeInfo.desiredAggroText, UnitName(enemyUnitId), enemyIsPvp);
                        end
                    end
                 end
            end
            
            indexToProcess = indexToProcess + 1;
        end
        
        currentExtraTargetDepthLevel = currentExtraTargetDepthLevel + 1;
    end
    
    -- See if aggro refreshing is allowed. It's allowed if we had an original aggro enemy but that enemy wasn't found this tick, and the specified unit has aggro this tick.
    local aggroRefreshAllowedIfDesiredThisTick = false;
    if (runtimeInfo.originalAggroEnemyGuid ~= nil and (not originalAggroEnemyFoundThisTick) and specifiedUnitHasAggroThisTick) then
        aggroRefreshAllowedIfDesiredThisTick = true;
    end
    
    -- Make sure the aggro text refreshes if the specified unit desired it, it's allowed, and we have aggro this tick.
    if (shouldRefreshAggroTextOnEveryNewAggro and aggroRefreshAllowedIfDesiredThisTick and specifiedUnitHasAggroThisTick) then
        -- Set the original aggro enemy to be whatever we found this tick.
        runtimeInfo.originalAggroEnemyGuid = enemyUnitGuidOfThisTickAggro;
        runtimeInfo.originalAggroEnemyIsTargetingMe = true;
        -- Refresh the aggro text.
        AggroNotifier_RefreshAggroText(aggroTextObject, true, false);
    end
                
    -- See if we have an original aggro enemy.
    if (runtimeInfo.originalAggroEnemyGuid ~= nil) then
        --[[ 
            If we have an original aggro enemy and we haven't definitively identified that it has switched aggro to something else, then we should assume that the specified unit still has aggro
            and short circuit by returning true.
            NOTE: We have to make this assumption because Blizzard doesn't allow us to look up a unit by GUID, so if nobody's targeting the original aggro enemy it won't show up
                 as an enemy this tick, even though it might still be aggro'd on the specified unit. Therefore it's safer to assume the specified unit still has aggro than to give them a false
                 sense of security by giving the "all clear" when it may not be all clear.
        ]]
        if (runtimeInfo.originalAggroEnemyIsTargetingMe) then
            return true;
        else
            -- The original aggro enemy has definitely switched aggro to something else if we reach here. 
            -- Therefore if there's aggro this tick we should update the original aggro enemy variables to the new values we just found.
            -- Otherwise we're "all clear" and can clear the original aggro enemy variables entirely.
            if (specifiedUnitHasAggroThisTick) then
                runtimeInfo.originalAggroEnemyGuid = enemyUnitGuidOfThisTickAggro;
                runtimeInfo.originalAggroEnemyIsTargetingMe = true;
            else
                runtimeInfo.originalAggroEnemyGuid = nil;
                runtimeInfo.originalAggroEnemyIsTargetingMe = false;
            end
        end
    else
        -- There was no original aggro enemy when we checked for aggro at the start of this tick, but we might have found a new one!
        if (specifiedUnitHasAggroThisTick) then
            runtimeInfo.originalAggroEnemyGuid = enemyUnitGuidOfThisTickAggro;
            runtimeInfo.originalAggroEnemyIsTargetingMe = true;
        end
    end
    
    return specifiedUnitHasAggroThisTick;
end

-- This function returns true if (1) the given enemy unit is alive, and (2) the enemy is targeting the given unit to check *or* the unit to check's threat percentage for the enemy is 100.
-- If the above situation does not appy (e.g. the enemy is dead, or not targeting the unit to check *and* the threat percentage is below 100) then this function will return false.
function AggroNotifier_UnitHasAggroFromEnemy(unitIdToCheck, enemyUnitId)
    -- Return false if the enemy is dead.
    if (UnitIsDeadOrGhost(enemyUnitId)) then
        return false;
    end
    
    -- The enemy is not dead, so in this case we consider the unit represented by unitIdToCheck to have aggro if either
    -- (1) The enemy is targeting the unit, or (2) the thread percentage of the enemy on the unit is 100.
    isTanking, status, threatPct, rawThreatPct, threatValue = UnitDetailedThreatSituation(unitIdToCheck, enemyUnitId);
    if (UnitIsUnit(enemyUnitId.."target", unitIdToCheck) or (threatPct == 100)) then
        return true;
    end
    
    -- The enemy was not targeting the unit, and the unit's thread percentage for the enemy was below 100, therefore the unit does not have aggro
    -- from this enemy. Return false.
    return false;
end

-- This function determines and returns the r, g, b, and new alpha values for the given aggro text object based on the given alpha subtraction value and (optional) color override.
-- Pass in nil for the color override if you want the color determined by whether the unit represented by the aggro text object currently has aggro. If the color override is *not* nil
--     then it will be used as the color to unpack regardless of the unit's aggro status.
-- The new alpha is determined by the following equation (1.00 - alphaSubtractionValue) * alphaFactor, so if you want completely invisible pass in 1, and if you want opaque as possible
--     pass in 0 (i.e. if you pass in 0 the returned alpha will be the same as the color's alpha factor).
function AggroNotifier_GetAggroTextObjectColor(aggroTextObject, alphaSubtractionValue, colorOverride)
    -- Figure out what color to use. Default to the override color.
    local colorToReturn = colorOverride;
    
    -- If colorOverride was *not* nil, then we use that. Otherwise we have to do more digging.
    if (colorToReturn == nil) then
        -- colorOverride was nil, so the color we use depends on whether or not we have aggro.
        if (aggroTextObject.runtimeInfo.hasAggroStored) then
            -- We have aggro. Use the gain aggro color.
            colorToReturn = aggroTextObject.runtimeInfo.gainAggroColor;
        else
            -- We do not have aggro. Use the lose aggro color.
            colorToReturn = aggroTextObject.runtimeInfo.loseAggroColor;
        end
    end
    
    -- Unpack the color we're supposed to use.
    local r, g, b, alphaFactor = unpack(colorToReturn);
    -- The alpha is determined by the passed in alpha subtraction value and the alpha factor.
    local newAlpha = (1.00 - alphaSubtractionValue) * alphaFactor;
    
    return r, g, b, newAlpha, alphaFactor;
end

-- This function sets the proper color and transparency values for the given aggro text object, based on how long it's been since the fade-time-start (thus allowing for text fade).
-- If it's been too long since the fade was started, then this function will hide the given aggro text object completely.
function AggroNotifier_HandleTextFade(aggroTextObject)
    -- If fadeStartTime is nil then there's nothing for us to do!
    if (aggroTextObject.runtimeInfo.fadeStartTime ~= nil) then
        local hasAggroAndAlwaysOn = aggroTextObject.runtimeInfo.preventFadeoutOnAggroGain and aggroTextObject.runtimeInfo.hasAggroStored;
        
        -- Figure out how long it's been since we started the fadeout.
        local totalElapsedSinceFadeStartTimeMilliseconds = (GetTime() - aggroTextObject.runtimeInfo.fadeStartTime) * 1000;
        -- If the elapsed time since we started fadeout is shorter than the desired fadeout time, then we need to update the aggro text with a new fadeout value.
        -- We also continue here if we have aggro and the always-on option is true.
        if (hasAggroAndAlwaysOn or totalElapsedSinceFadeStartTimeMilliseconds < aggroTextObject.runtimeInfo.fadeTimeMilliseconds) then
            -- Figure out the alpha value the aggro text should be at so that it will be fully opaque at the start of the fadeout 
            -- and smoothly fade to fully transparent when the desired fadeout time has been reached.
            local alphaSubtractionValue = totalElapsedSinceFadeStartTimeMilliseconds / aggroTextObject.runtimeInfo.fadeTimeMilliseconds;
            
            -- Determine the color we should use.
            local r, g, b, newAlpha, alphaFactor = AggroNotifier_GetAggroTextObjectColor(aggroTextObject, alphaSubtractionValue, aggroTextObject.runtimeInfo.temporaryColorOverride);
            
            -- Force the alpha value to be max allowed if we're always-on.
            if (hasAggroAndAlwaysOn) then
                newAlpha = 1.00 * alphaFactor;
            end
            
            -- Update the aggro text to the new color and alpha value.
            aggroTextObject:SetVertexColor(r, g, b, newAlpha);
        else
            -- We've gone past the desired fadeout time, so we need to nullify the fadeStartTime variable and hide the aggro text.
            AggroNotifier_HideAggroText(aggroTextObject);
        end
    end
end
    